//
//  CLUB_ANALYTICSsApp.swift
//  CLUB ANALYTICSs
//
//  Created by SAIL on 06/03/26.
//

import SwiftUI

@main
struct CLUB_ANALYTICSsApp: App {
    @StateObject private var store       = AttendanceNotificationStore()
    @StateObject private var authManager = AuthManager.shared

    var body: some Scene {
        WindowGroup {
            SplashScreenView()
                .environmentObject(store)
                .environmentObject(authManager)
        }
    }
}
