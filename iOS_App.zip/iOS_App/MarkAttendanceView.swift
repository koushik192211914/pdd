import SwiftUI

// MARK: - Attendance Status
enum AttendanceChoice: String, CaseIterable {
    case present    = "Present"
    case absent     = "Absent"

    var color: Color {
        switch self {
        case .present:    return .green
        case .absent:     return .red
        }
    }
    var icon: String {
        switch self {
        case .present:    return "checkmark.circle.fill"
        case .absent:     return "xmark.circle.fill"
        }
    }
}

// MARK: - Main View
struct MarkAttendanceView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var authManager: AuthManager
    @EnvironmentObject var store: AttendanceNotificationStore

    let eventId: String  // empty = club session attendance

    // State
    @State private var participants: [EventParticipant] = []
    @State private var isLoading = true
    @State private var errorMessage: String?

    @State private var choices: [Int: AttendanceChoice] = [:]
    // Chosen substitute: originalStudentId → substitute participant
    @State private var substitutes: [Int: EventParticipant] = [:]
    // When substitute is tapped but no one available, mark this id
    @State private var noSubAvailable: Set<Int> = []

    @State private var pickingSubstituteFor: EventParticipant? = nil
    @State private var availableSubstitutes: [EventParticipant] = []
    @State private var isLoadingSubs = false

    @State private var isSubmitting = false
    @State private var submitMessage: String?
    @State private var isAttendanceSubmitted = false

    private var allMarked: Bool {
        participants.allSatisfy { p in
            return choices[p.id] != nil
        }
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            Color(UIColor.systemGroupedBackground).ignoresSafeArea()

            VStack(spacing: 0) {
                // Header
                EventAttendanceHeader(
                    title: eventId.isEmpty ? "Club Attendance" : "Event Attendance",
                    subtitle: eventId.isEmpty ? "Mark today's session" : "Event #\(eventId)"
                )

                if isLoading {
                    Spacer()
                    ProgressView("Loading participants...")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Spacer()
                } else if let err = errorMessage {
                    Spacer()
                    ErrorStateView(message: err)
                    Spacer()
                } else if participants.isEmpty {
                    Spacer()
                    EmptyParticipantsView()
                    Spacer()
                } else {
                    ScrollView {
                        VStack(spacing: 12) {
                            // Summary banner
                            AttendanceSummaryBanner(
                                total: participants.count,
                                present: choices.values.filter { $0 == .present }.count,
                                absent: choices.values.filter { $0 == .absent }.count - substitutes.count,
                                substitute: substitutes.count
                            )
                            .padding(.horizontal)

                            ForEach(participants) { participant in
                                ParticipantAttendanceRow(
                                    participant: participant,
                                    choice: Binding(
                                        get: { choices[participant.id] },
                                        set: { newVal in
                                            choices[participant.id] = newVal
                                            // Clear substitute if switched back to present
                                            if newVal == .present {
                                                substitutes.removeValue(forKey: participant.id)
                                                noSubAvailable.remove(participant.id)
                                            }
                                        }
                                    ),
                                    substitute: substitutes[participant.id],
                                    noSubAvailable: noSubAvailable.contains(participant.id),
                                    onPickSubstitute: {
                                        loadAndShowSubstitutePicker(for: participant)
                                    }
                                )
                                .padding(.horizontal)
                            }
                        }
                        .padding(.top, 16)
                        .padding(.bottom, 110)
                    }
                }
            }

            // Sticky bottom submit
            VStack(spacing: 0) {
                Divider()
                VStack(spacing: 8) {
                    if let msg = submitMessage {
                        HStack(spacing: 6) {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                            Text(msg)
                                .font(.subheadline)
                                .foregroundColor(.green)
                        }
                        .transition(.opacity.combined(with: .move(edge: .bottom)))
                    }
                    Button(action: submitAttendance) {
                        HStack(spacing: 10) {
                            if isSubmitting {
                                ProgressView().tint(.white)
                            } else if isAttendanceSubmitted {
                                Image(systemName: "checkmark.seal.fill")
                                    .font(.system(size: 16, weight: .semibold))
                                Text("Attendance Submitted")
                                    .font(.headline)
                            } else {
                                Image(systemName: "checkmark.seal.fill")
                                    .font(.system(size: 16, weight: .semibold))
                                Text("Submit Attendance")
                                    .font(.headline)
                            }
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(
                            isAttendanceSubmitted ? LinearGradient(colors: [.green, .green.opacity(0.8)], startPoint: .leading, endPoint: .trailing) :
                            (allMarked
                            ? LinearGradient(colors: [.blue, .purple], startPoint: .leading, endPoint: .trailing)
                            : LinearGradient(colors: [.gray.opacity(0.5), .gray.opacity(0.4)], startPoint: .leading, endPoint: .trailing))
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .shadow(color: (allMarked && !isAttendanceSubmitted) ? .blue.opacity(0.3) : .clear, radius: 8, y: 4)
                    }
                    .disabled(!allMarked || isSubmitting || isAttendanceSubmitted)
                    .animation(.easeInOut(duration: 0.2), value: allMarked)
                }
                .padding(.horizontal)
                .padding(.vertical, 12)
                .background(Color(UIColor.systemGroupedBackground))
            }
        }
        .navigationBarHidden(true)
        .task { await loadParticipants() }
        .sheet(item: $pickingSubstituteFor) { target in
            SubstitutePickerSheet(
                target: target,
                candidates: availableSubstitutes,
                isLoading: isLoadingSubs,
                onSelect: { chosen in
                    substitutes[target.id] = chosen
                    noSubAvailable.remove(target.id)
                    pickingSubstituteFor = nil
                },
                onDismiss: {
                    // User cancelled — revert to absent if no sub chosen
                    if substitutes[target.id] == nil {
                        choices[target.id] = .absent
                    }
                    pickingSubstituteFor = nil
                }
            )
        }
    }

    // MARK: - Load Participants
    private func loadParticipants() async {
        isLoading = true
        defer { isLoading = false }
        guard !eventId.isEmpty, let eId = Int(eventId) else {
            // Club session — fall back to club members
            guard let clubId = authManager.clubId else {
                errorMessage = "No club assigned."; return
            }
            do {
                let members = try await ClubService.shared.getMembers(clubId: clubId)
                participants = members.map {
                    EventParticipant(student_id: $0.id, name: $0.name, email: "", status: nil)
                }
            } catch {
                errorMessage = "Failed to load club members."
            }
            return
        }
        do {
            participants = try await EventAttendanceService.shared.getEventParticipants(eventId: eId)
            if participants.isEmpty {
                // Intentionally empty — show empty state
            } else {
                if let submitted = try? await EventAttendanceService.shared.hasSubmittedAttendance(eventId: eId) {
                    isAttendanceSubmitted = submitted
                }
            }
        } catch {
            errorMessage = "Failed to load participants. Check your connection."
        }
    }

    // MARK: - Load substitutes then show picker
    private func loadAndShowSubstitutePicker(for participant: EventParticipant) {
        guard let eId = Int(eventId), let clubId = authManager.clubId else {
            noSubAvailable.insert(participant.id)
            return
        }
        isLoadingSubs = true
        Task {
            do {
                let subs = try await EventAttendanceService.shared.getAvailableSubstitutes(eventId: eId, clubId: clubId)
                await MainActor.run {
                    availableSubstitutes = subs
                    isLoadingSubs = false
                    if subs.isEmpty {
                        noSubAvailable.insert(participant.id)
                    } else {
                        pickingSubstituteFor = participant
                    }
                }
            } catch {
                await MainActor.run {
                    isLoadingSubs = false
                    noSubAvailable.insert(participant.id)
                }
            }
        }
    }

    // MARK: - Submit
    private func submitAttendance() {
        isSubmitting = true
        Task {
            guard let eId = Int(eventId) else {
                // Handle club session submit (legacy path)
                await submitClubAttendance()
                return
            }

            var records: [EventAttendanceRequest] = []
            for p in participants {
                let choice = choices[p.id] ?? .absent
                let statusStr = choice == .present ? "Present" : "Absent"
                
                var rec = EventAttendanceRequest(
                    event_id: eId,
                    student_id: p.student_id,
                    status: statusStr
                )
                if let sub = substitutes[p.id] {
                    rec.substitute_id = sub.student_id
                }
                records.append(rec)
            }

            do {
                _ = try await EventAttendanceService.shared.markAttendance(records: records)

                // Assign substitutions
                for p in participants {
                    if let sub = substitutes[p.id] {
                        try? await EventAttendanceService.shared.assignSubstitute(
                            eventId: eId,
                            originalStudentId: p.student_id,
                            substituteStudentId: sub.student_id
                        )
                    }
                }

                await MainActor.run {
                    withAnimation { submitMessage = "Attendance submitted! ✅" }
                    isSubmitting = false
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) { dismiss() }
                }
            } catch {
                await MainActor.run {
                    submitMessage = "Submission failed. Please retry."
                    isSubmitting = false
                }
            }
        }
    }

    private func submitClubAttendance() async {
        guard let clubId = authManager.clubId else { isSubmitting = false; return }
        do {
            let session: AttendanceSessionResponse = try await APIClient.shared.request(
                "/club-attendance/\(clubId)/session", method: "POST"
            )
            for p in participants {
                let choice = choices[p.id] ?? .absent
                let rec = AttendanceRecordRequest(
                    session_id: session.id,
                    student_id: p.student_id,
                    status: choice == .present ? "Present" : "Absent"
                )
                let _: AttendanceRecordResponse = try await APIClient.shared.request(
                    "/club-attendance/mark", method: "POST", body: rec
                )
            }
        } catch { print("❌ Club attendance error: \(error)") }

        await MainActor.run {
            withAnimation { submitMessage = "Attendance submitted! ✅" }
            isSubmitting = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) { dismiss() }
        }
    }
}

// MARK: - Header
private struct EventAttendanceHeader: View {
    let title: String
    let subtitle: String
    @Environment(\.dismiss) private var dismiss

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        ZStack(alignment: .top) {
            LinearGradient(
                colors: [Color.blue, Color.purple],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            .frame(height: safeTop + 80)

            VStack(spacing: 0) {
                Color.clear.frame(height: safeTop + 8)
                HStack(alignment: .center) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle()
                                .fill(Color.white.opacity(0.18))
                                .frame(width: 38, height: 38)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(.white)
                        }
                    }
                    Spacer()
                    VStack(spacing: 2) {
                        Text(title)
                            .font(.headline)
                            .foregroundColor(.white)
                        Text(subtitle)
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.8))
                    }
                    Spacer()
                    // Balance the back button
                    Circle()
                        .fill(Color.clear)
                        .frame(width: 38, height: 38)
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 14)
            }
        }
    }
}

// MARK: - Summary Banner
private struct AttendanceSummaryBanner: View {
    let total: Int
    let present: Int
    let absent: Int
    let substitute: Int

    var body: some View {
        HStack(spacing: 0) {
            SummaryPill(value: present, label: "Present", color: .green)
            Divider().frame(height: 30).opacity(0.3)
            SummaryPill(value: absent, label: "Absent", color: .red)
            Divider().frame(height: 30).opacity(0.3)
            SummaryPill(value: substitute, label: "Sub", color: .orange)
            Divider().frame(height: 30).opacity(0.3)
            SummaryPill(value: total - present - absent - substitute, label: "Unmarked", color: .secondary)
        }
        .padding(.vertical, 10)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .shadow(color: .black.opacity(0.04), radius: 4, y: 2)
    }
}

private struct SummaryPill: View {
    let value: Int
    let label: String
    let color: Color

    var body: some View {
        VStack(spacing: 2) {
            Text("\(value)")
                .font(.title3).bold()
                .foregroundColor(color)
            Text(label)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Participant Row
private struct ParticipantAttendanceRow: View {
    let participant: EventParticipant
    @Binding var choice: AttendanceChoice?
    let substitute: EventParticipant?
    let noSubAvailable: Bool
    let onPickSubstitute: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // Person info
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(LinearGradient(
                            colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.5)],
                            startPoint: .topLeading, endPoint: .bottomTrailing
                        ))
                        .frame(width: 44, height: 44)
                    Text(String(participant.name.prefix(1)).uppercased())
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.white)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(participant.name)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    Text(participant.email.isEmpty ? "Registered member" : participant.email)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
                Spacer()
                // Status indicator dot
                if let c = choice {
                    Circle()
                        .fill(c.color)
                        .frame(width: 10, height: 10)
                        .shadow(color: c.color.opacity(0.5), radius: 3)
                }
            }

            // Action buttons
            HStack(spacing: 8) {
                ForEach(AttendanceChoice.allCases, id: \.self) { opt in
                    let isSelected = choice == opt
                    Button {
                        withAnimation(.spring(response: 0.3)) {
                            choice = opt
                        }
                    } label: {
                        HStack(spacing: 5) {
                            Image(systemName: isSelected ? opt.icon : unselectedIcon(opt))
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(isSelected ? opt.color : .secondary)
                            Text(opt.rawValue)
                                .font(.caption)
                                .fontWeight(isSelected ? .bold : .medium)
                                .foregroundColor(isSelected ? opt.color : .secondary)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(
                            isSelected
                            ? opt.color.opacity(0.15)
                            : Color(UIColor.tertiarySystemFill)
                        )
                        .clipShape(Capsule())
                        .overlay(
                            Capsule()
                                .stroke(isSelected ? opt.color.opacity(0.5) : Color.clear, lineWidth: 1)
                        )
                    }
                    .buttonStyle(PlainButtonStyle())
                    .scaleEffect(isSelected ? 1.04 : 1.0)
                    .animation(.spring(response: 0.25), value: isSelected)
                }
            }

            // Substitute Sub-section (Appears only when Absent)
            if choice == .absent {
                Group {
                    if let sub = substitute {
                        HStack(spacing: 6) {
                            Image(systemName: "arrow.triangle.2.circlepath")
                                .font(.caption2)
                                .foregroundColor(.orange)
                            Text("Substitute: ")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text(sub.name)
                                .font(.caption)
                                .fontWeight(.semibold)
                                .foregroundColor(.orange)
                            Spacer()
                            Button("Change") { onPickSubstitute() }
                                .font(.caption)
                                .foregroundColor(.blue)
                        }
                        .padding(8)
                        .background(Color.orange.opacity(0.08))
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    } else if noSubAvailable {
                        HStack(spacing: 6) {
                            Image(systemName: "person.slash.fill")
                                .font(.caption2)
                            Text("No substitute left")
                                .font(.caption)
                                .fontWeight(.semibold)
                        }
                        .foregroundColor(.red)
                        .padding(8)
                        .background(Color.red.opacity(0.08))
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    } else {
                        Button {
                            onPickSubstitute()
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "person.badge.plus")
                                Text("Assign Substitute")
                                    .fontWeight(.semibold)
                            }
                            .font(.caption)
                            .foregroundColor(.orange)
                            .padding(8)
                            .background(Color.orange.opacity(0.1))
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                        }
                    }
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.04), radius: 5, y: 2)
    }

    private func unselectedIcon(_ opt: AttendanceChoice) -> String {
        switch opt {
        case .present:    return "checkmark.circle"
        case .absent:     return "xmark.circle"
        }
    }
}

// MARK: - Substitute Picker Sheet
struct SubstitutePickerSheet: View {
    let target: EventParticipant
    let candidates: [EventParticipant]
    let isLoading: Bool
    let onSelect: (EventParticipant) -> Void
    let onDismiss: () -> Void

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            Group {
                if isLoading {
                    VStack(spacing: 16) {
                        ProgressView()
                        Text("Finding substitutes...")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if candidates.isEmpty {
                    VStack(spacing: 20) {
                        ZStack {
                            Circle()
                                .fill(Color.red.opacity(0.1))
                                .frame(width: 80, height: 80)
                            Image(systemName: "person.slash.fill")
                                .font(.system(size: 36))
                                .foregroundColor(.red)
                        }
                        Text("No Substitute Available")
                            .font(.title3)
                            .fontWeight(.bold)
                        Text("All club members are already registered for this event.")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                        Button("OK") {
                            onDismiss()
                            dismiss()
                        }
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.horizontal, 40)
                        .padding(.vertical, 12)
                        .background(Color.red)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List(candidates) { candidate in
                        Button {
                            onSelect(candidate)
                            dismiss()
                        } label: {
                            HStack(spacing: 14) {
                                ZStack {
                                    Circle()
                                        .fill(LinearGradient(
                                            colors: [Color.orange.opacity(0.7), Color.yellow.opacity(0.5)],
                                            startPoint: .topLeading, endPoint: .bottomTrailing
                                        ))
                                        .frame(width: 42, height: 42)
                                    Text(String(candidate.name.prefix(1)).uppercased())
                                        .font(.system(size: 15, weight: .bold))
                                        .foregroundColor(.white)
                                }
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(candidate.name)
                                        .font(.subheadline)
                                        .fontWeight(.semibold)
                                        .foregroundColor(.primary)
                                    Text(candidate.email)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                        .lineLimit(1)
                                }
                                Spacer()
                                Image(systemName: "plus.circle.fill")
                                    .foregroundColor(.orange)
                                    .font(.title3)
                            }
                            .padding(.vertical, 4)
                        }
                        .listRowBackground(Color(UIColor.secondarySystemGroupedBackground))
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("Pick Substitute")
            .navigationSubtitle("for \(target.name)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        onDismiss()
                        dismiss()
                    }
                    .foregroundColor(.secondary)
                }
            }
        }
    }
}

// MARK: - Empty / Error States
private struct EmptyParticipantsView: View {
    var body: some View {
        VStack(spacing: 20) {
            ZStack {
                Circle()
                    .fill(Color.purple.opacity(0.1))
                    .frame(width: 90, height: 90)
                Image(systemName: "person.3.sequence.fill")
                    .font(.system(size: 40))
                    .foregroundColor(.purple.opacity(0.6))
            }
            Text("No Registrations Yet")
                .font(.title3)
                .fontWeight(.bold)
            Text("No students have registered for this event.\nShare the event to get members to sign up.")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
    }
}

private struct ErrorStateView: View {
    let message: String
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 40))
                .foregroundColor(.orange)
            Text(message)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
        NavigationStack {
            MarkAttendanceView(eventId: "1")
                .environmentObject(AttendanceNotificationStore())
        }
    }
}
