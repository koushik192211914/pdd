import SwiftUI

// MARK: - Edit Profile View
struct EditProfileView: View {
    @Environment(\.dismiss) private var dismiss

    // State
    @State private var name        = ""
    @State private var email       = ""
    @State private var isLoading   = true
    @State private var isSaving    = false
    @State private var showSuccess = false
    @State private var errorMessage: String?

    // Computed safe top
    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        VStack(spacing: 0) {
            // ── Custom Header ──────────────────────────────────────────────
            ZStack(alignment: .top) {
                LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                    .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                    .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

                VStack(alignment: .leading, spacing: 0) {
                    Color.clear.frame(height: safeTop + 8)
                    HStack(alignment: .center, spacing: 12) {
                        Button(action: { dismiss() }) {
                            ZStack {
                                Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                            }
                        }
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Edit Profile").font(.title3).bold().foregroundColor(.white)
                            Text("Update your personal details")
                                .font(.caption).foregroundColor(.white.opacity(0.80)).lineLimit(1)
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 18).padding(.bottom, 22)
                }
            }
            .frame(height: safeTop + 92)

            if isLoading {
                Spacer()
                ProgressView("Loading Profile...")
                Spacer()
            } else {
                ScrollView {
                    VStack(spacing: 24) {
                        // Avatar Section
                        VStack(spacing: 12) {
                            ZStack {
                                Circle()
                                    .fill(LinearGradient(
                                        colors: [.purple, .blue],
                                        startPoint: .topLeading, endPoint: .bottomTrailing
                                    ))
                                    .frame(width: 100, height: 100)
                                    .shadow(color: .purple.opacity(0.3), radius: 10, y: 5)
                                
                                Text(String(name.prefix(2)).uppercased())
                                    .font(.system(size: 30, weight: .bold)).foregroundColor(.white)
                            }
                            
                            Button(action: {}) {
                                Text("Change Photo")
                                    .font(.subheadline).fontWeight(.semibold)
                                    .foregroundColor(.purple)
                            }
                        }
                        .padding(.top, 30)

                        // Form Section
                        VStack(alignment: .leading, spacing: 20) {
                            LabeledProfileField(label: "Full Name", icon: "person.fill", value: $name)
                            LabeledProfileField(label: "Email Address", icon: "envelope.fill", value: $email)
                                .disabled(true)
                                .opacity(0.6)
                        }
                        .padding(20)
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(18)
                        .shadow(color: .black.opacity(0.04), radius: 6, x: 0, y: 3)
                        
                        if let err = errorMessage {
                            Text("⚠️ \(err)")
                                .font(.caption).foregroundColor(.red)
                                .padding(.horizontal)
                        }

                        Spacer(minLength: 40)

                        // Save Button
                        Button(action: {
                            Task { await saveProfile() }
                        }) {
                            HStack(spacing: 10) {
                                if isSaving {
                                    ProgressView().tint(.white)
                                } else {
                                    Image(systemName: "checkmark.circle.fill")
                                        .font(.system(size: 18, weight: .semibold))
                                }
                                Text(isSaving ? "Saving..." : "Save Profile")
                                    .font(.headline)
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(
                                LinearGradient(colors: [.purple, .blue], startPoint: .leading, endPoint: .trailing)
                            )
                            .cornerRadius(16)
                            .shadow(color: .purple.opacity(0.3), radius: 8, x: 0, y: 4)
                        }
                        .disabled(isSaving || name.isEmpty)
                        .opacity(isSaving || name.isEmpty ? 0.6 : 1.0)
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 40)
                }
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .task {
            await loadProfile()
        }
        .alert("Profile Saved", isPresented: $showSuccess) {
            Button("OK") { dismiss() }
        } message: {
            Text("Your profile has been updated successfully.")
        }
    }

    @MainActor
    private func loadProfile() async {
        isLoading = true
        do {
            let user = try await AuthService.shared.getMe()
            self.name = user.name
            self.email = user.email
        } catch {
            errorMessage = "Failed to load profile"
        }
        isLoading = false
    }

    @MainActor
    private func saveProfile() async {
        isSaving = true
        errorMessage = nil
        do {
            let updatedUser = try await AuthService.shared.updateProfile(name: name)
            AuthManager.shared.saveSession(user: updatedUser)
            showSuccess = true
        } catch {
            errorMessage = error.localizedDescription
        }
        isSaving = false
    }
}

// MARK: - Reusable labeled field row
private struct LabeledProfileField: View {
    let label: String
    let icon: String
    @Binding var value: String
    var keyboardType: UIKeyboardType = .default

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(label, systemImage: icon)
                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
            TextField(label, text: $value)
                .font(.subheadline)
                .keyboardType(keyboardType)
                .autocapitalization(keyboardType == .emailAddress ? .none : .words)
                .padding()
                .background(Color(UIColor.tertiarySystemGroupedBackground))
                .cornerRadius(12)
        }
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
    NavigationStack {
        EditProfileView()
    }

    }
}
