//
//  DashboardViewModels.swift
//  CLUB ANALYTICSs
//

import Foundation
import SwiftUI
import Combine



// MARK: - Admin Dashboard
@MainActor
final class AdminHomeViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showDebugAlert = false
    @Published var debugMessage = ""
    @Published var lastUpdated = Date()
    @Published var summary: PlatformSummaryResponse?
    @Published var dashboard: DashboardResponse?
    @Published var announcements: [AnnouncementResponse] = []
    
    // Flattened properties for easier direct binding
    @Published var totalClubs: Int = 0
    @Published var totalMembers: Int = 0
    @Published var activeEvents: Int = 0
    @Published var engagementRate: Double = 0.0
    
    func fetchData() async {
        if isLoading { return }
        print("🔍 [AdminHomeViewModel] fetchData() started")
        isLoading = true
        errorMessage = nil
        
        do {
            print("🚀 [AdminHomeViewModel] Starting data fetch from AdminService...")
            async let s = AdminService.shared.getPlatformSummary()
            async let d = AdminService.shared.getDashboard()
            
            // For Admin, we'll fetch announcements for all clubs or a general list.
            // Since announcements are per-club, the Admin dashboard will show a consolidated view or recent ones.
            // For now, let's fetch for club 0 or a specialized admin endpoint if exists. 
            // Fetch Platform-wide announcements for Admin
            let clubs = try await ClubService.shared.getClubs()
            var allAnns: [AnnouncementResponse] = []
            
            // Parallel fetch for each club (limit parallel tasks if many clubs, but here it's fine)
            try await withThrowingTaskGroup(of: [AnnouncementResponse].self) { group in
                for club in clubs {
                    group.addTask {
                        try await AnnouncementService.shared.getAnnouncements(clubId: club.id)
                    }
                }
                
                for try await list in group {
                    allAnns.append(contentsOf: list)
                }
            }
            
            // Sort by creation date (descending)
            allAnns.sort { $0.created_at > $1.created_at }
            
            // Deduplicate across clubs (same title and content)
            var uniqueAnns: [AnnouncementResponse] = []
            var seenTokens = Set<String>()
            for ann in allAnns {
                let token = "\(ann.title)|\(ann.content)"
                if !seenTokens.contains(token) {
                    seenTokens.insert(token)
                    uniqueAnns.append(ann)
                }
            }
            
            let (summaryResponse, dashboardResponse) = try await (s, d)
            print("✅ [AdminHomeViewModel] API Response Received!")
            
            self.summary = summaryResponse
            self.dashboard = dashboardResponse
            self.announcements = uniqueAnns
            self.lastUpdated = Date()
            self.objectWillChange.send()
            
            self.totalClubs = summaryResponse.total_clubs
            self.totalMembers = summaryResponse.total_members
            self.activeEvents = summaryResponse.active_events
            self.engagementRate = summaryResponse.engagement_rate
            
            print("💾 [AdminHomeViewModel] Local state updated successfully.")
        } catch {
            print("❌ [AdminHomeViewModel] Error in fetchData: \(error.localizedDescription)")
            errorMessage = "Sync Error: \(error.localizedDescription)"
        }
        
        print("🏁 [AdminHomeViewModel] fetchData() finished. isLoading set to false.")
        isLoading = false
    }
}


// MARK: - President Dashboard
@MainActor
final class PresidentHomeViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var club: ClubResponse?
    @Published var lastUpdated = Date()
    @Published var health: ClubHealthResponse?
    @Published var events: [EventResponse] = []
    @Published var lowEngagementMembers: [LowEngagementMember] = []
    @Published var announcements: [AnnouncementResponse] = []
    @Published var pendingRequestCount: Int = 0 
    
    // Flattened properties for card binding
    @Published var totalMembers: Int = 0
    @Published var upcomingEventsCount: Int = 0
    @Published var engagementRate: Double = 0.0
    @Published var lowEngagementCount: Int = 0

    func fetchData(clubId: Int) async {
        if isLoading { return }
        print("🔍 [PresidentHomeViewModel] fetchData(clubId: \(clubId)) started")
        isLoading = true
        errorMessage = nil
        
        do {
            print("🚀 [PresidentHomeViewModel] Fetching data for club \(clubId)...")
            async let c = ClubService.shared.getClub(id: clubId)
            async let h = AnalyticsService.shared.getClubHealth(clubId: clubId)
            async let e = EventService.shared.getEvents(clubId: clubId)
            async let l = AnalyticsService.shared.getLowEngagementMembers(clubId: clubId)
            async let ann = AnnouncementService.shared.getAnnouncements(clubId: clubId)
            async let pending = JoinRequestService.shared.getPendingRequests(clubId: clubId)
            
            let (clubRes, healthRes, eventsList, lowEng, annList, pendingList) = try await (c, h, e, l, ann, pending)
            
            print("✅ [PresidentHomeViewModel] Data received successfully")
            
            // Filter events to only show upcoming ones (date >= today)
            let now = Date()
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withFullDate, .withDashSeparatorInDate, .withTime, .withColonSeparatorInTime]
            
            // Simplified date check: if we can't parse it, we keep it. 
            // If we can, we only keep it if it's today or in the future.
            let upcomingEvents = eventsList.filter { event in
                if let eventDate = formatter.date(from: event.date) {
                    // Set both to start of day for inclusive "today" check
                    let calendar = Calendar.current
                    let eventDay = calendar.startOfDay(for: eventDate)
                    let currentDay = calendar.startOfDay(for: now)
                    return eventDay >= currentDay
                }
                return true
            }
            
            // Signal change before updating state
            self.objectWillChange.send()
            
            self.club = clubRes
            self.health = healthRes
            self.events = upcomingEvents
            self.lowEngagementMembers = lowEng
            self.announcements = annList
            self.pendingRequestCount = pendingList.count
            
            // Map to flattened properties
            self.totalMembers = healthRes.total_members
            self.upcomingEventsCount = upcomingEvents.count
            self.engagementRate = healthRes.club_health_score // Use health score for 0-100% percentage
            self.lowEngagementCount = lowEng.count
            
            self.lastUpdated = Date()
            print("💾 [PresidentHomeViewModel] UI state updated. Health Score: \(healthRes.club_health_score)%")
        } catch {
            print("❌ [PresidentHomeViewModel] Error: \(error.localizedDescription)")
            errorMessage = "Sync Error: \(error.localizedDescription)"
        }
        
        isLoading = false
        print("🏁 [PresidentHomeViewModel] fetchData() finished")
    }
}

// MARK: - Secretary Dashboard
final class SecretaryHomeViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var club: ClubResponse?
    @Published var announcements: [AnnouncementResponse] = []
    @Published var reports: [ReportResponse] = []
    @Published var summary: [String: Int] = [:]
    @Published var lastUpdated = Date()
    
    @MainActor
    func fetchData(clubId: Int) async {
        if isLoading { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            async let c = ClubService.shared.getClub(id: clubId)
            async let a = AnnouncementService.shared.getAnnouncements(clubId: clubId)
            async let r = ReportService.shared.getReports()
            async let s: [String: Int] = APIClient.shared.request("/analytics/club/\(clubId)")
            
            let (club, ann, allReports, sum) = try await (c, a, r, s)
            self.club = club
            self.announcements = ann
            // Filter reports by this club
            self.reports = allReports.filter { $0.club_id == clubId }
            self.summary = sum
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}


// MARK: - Student Dashboard
final class StudentHomeViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var engagement: StudentEngagementResponse?
    @Published var myClubs: [ClubResponse] = []
    @Published var events: [EventResponse] = []
    @Published var announcements: [AnnouncementResponse] = []
    
    @MainActor
    func fetchData(studentId: Int, clubId: Int?) async {
        if isLoading { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            let eng = try await AnalyticsService.shared.getStudentEngagement(studentId: studentId)
            self.engagement = eng
            
            // If the user just joined a club, we might get the clubId from the engagement response
            let effectiveClubId = clubId ?? eng.club_id
            
            if let cid = effectiveClubId {
                // Load only the student's own club and its events
                async let c = ClubService.shared.getClub(id: cid)
                async let ev = EventService.shared.getEvents(clubId: cid)
                async let ann = AnnouncementService.shared.getAnnouncements(clubId: cid)
                let (club, clubEvents, annList) = try await (c, ev, ann)
                self.myClubs = [club]
                self.events = clubEvents
                self.announcements = annList
            } else {
                // No club yet — clear lists
                self.myClubs = []
                self.events = []
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
