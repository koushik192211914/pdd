//
//  ClubsViewModel.swift
//  CLUB ANALYTICSs
//

import Foundation
import Combine

@MainActor
final class ClubsViewModel: ObservableObject {
    @Published var clubs: [ClubResponse] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    func load() async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            print("🔄 [ClubsViewModel] Fetching clubs from API...")
            clubs = try await ClubService.shared.getClubs()
            print("✅ [ClubsViewModel] Fetched \(clubs.count) clubs")
        } catch {
            print("❌ [ClubsViewModel] Fetch error: \(error)")
            errorMessage = error.localizedDescription
        }
    }
}

@MainActor
final class ClubDetailViewModel: ObservableObject {
    @Published var health: ClubHealthResponse?
    @Published var events: [EventResponse] = []
    @Published var isLoading = false
    
    func load(clubId: Int) async {
        isLoading = true
        defer { isLoading = false }
        do {
            async let fetchHealth = try? AnalyticsService.shared.getClubHealth(clubId: clubId)
            async let fetchEvents = try? EventService.shared.getEvents(clubId: clubId)
            
            self.health = await fetchHealth
            self.events = await fetchEvents ?? []
        }
    }
}
