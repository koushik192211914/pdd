import SwiftUI

// Reusable placeholder view for tab destinations and internal navigation
struct PlaceholderScreen: View {
    let title: String
    let description: String
    
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "wrench.and.screwdriver.fill")
                .font(.system(size: 60))
                .foregroundColor(.purple)
            
            Text(title)
                .font(.largeTitle)
                .fontWeight(.bold)
            
            Text(description)
                .font(.body)
                .foregroundColor(.secondary)
            
            Spacer()
        }
        .padding()
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

// Navigation destinations needed
struct EventCreationScreen: View { var body: some View { CreateEventScreen() } }

struct AnnouncementCreationScreen: View {
    var body: some View {
        CreateAnnouncementScreen()
    }
}
struct AnalyticsDashboardScreen: View { var body: some View { PlaceholderScreen(title: "View Analytics", description: "Deep Dive Analytics Dashboard") } }
// EventDetailsScreen — navigation destination from event card taps
struct EventDetailsScreen: View {
    var body: some View {
        EventDetailScreen(eventId: 0, clubId: 0, title: "Event Details", club: "Tech Innovation Club",
                          day: "15", month: "MAR", time: "9:00 AM",
                          location: "Main Auditorium", registered: 156)
    }
}
struct SubstituteSelectionScreen: View { var body: some View { PlaceholderScreen(title: "Select Substitute", description: "Find a substitute for the member") } }
struct AnnouncementDetailsScreen: View {
    let announcement: AnnouncementResponse
    var body: some View {
        AnnouncementDetailView(announcement: announcement)
    }
}
struct MediaUploadScreen: View { var body: some View { PlaceholderScreen(title: "Upload Media", description: "Upload photos and videos") } }
struct EventReportsScreen: View { var body: some View { PlaceholderScreen(title: "Event Reports", description: "Auto-generated AI reports") } }

// MARK: - Admin-specific screens
// CreateClubScreen now lives in AdminScreens.swift — no stub needed here
struct UserManagementScreen: View { var body: some View { ManageUsersScreen() } }

// AdminAnnouncementScreen captures its own dismiss and threads it all the
// way to AnnouncementSuccessScreen as dismissToRoot.  When dismissToRoot()
// is called from the success screen, SwiftUI pops AdminAnnouncementScreen
// from the navigation stack — which automatically removes every screen
// stacked above it, giving a clean one-tap return to Admin Dashboard.
struct AdminAnnouncementScreen: View {
    var body: some View {
        CreateAnnouncementScreen()
    }
}
