import SwiftUI

struct PresidentDashboardView: View {
    /// All officer roles share this shell: President, VP, Secretary.
    var role: ClubRole = .president
    
    @EnvironmentObject private var authManager: AuthManager
    
    @State private var selectedTab: Int = 0
    
    @StateObject private var adminVM = AdminHomeViewModel()
    @StateObject private var presidentVM = PresidentHomeViewModel()
    @StateObject private var secretaryVM = SecretaryHomeViewModel()
    @StateObject private var studentVM = StudentHomeViewModel()

    // MARK: - Role title for header
    private var roleTitle: String {
        switch role {
        case .admin:         return "Admin Dashboard"
        case .president:     return "President Dashboard"
        case .vicePresident: return "Vice President Dashboard"
        case .secretary:     return "Secretary Dashboard"
        default:             return "\(role.rawValue) Dashboard"
        }
    }

    // MARK: - Home tab — role-specific dashboard
    @ViewBuilder
    private var homeTab: some View {
        switch role {
        case .admin:
            AdminHomeDashboard(viewModel: adminVM)
        case .student:
            StudentHomeDashboard(viewModel: studentVM, onViewEvents: { selectedTab = 2 })
        case .secretary:
            SecretaryHomeDashboard(viewModel: secretaryVM)
        default:
            // President and Vice President share the same home layout
            PresidentHomeDashboard(viewModel: presidentVM, role: role, roleTitle: roleTitle, onViewAnalytics: { selectedTab = 3 })
        }
    }

    var body: some View {
        TabView(selection: $selectedTab) {
            // ── Home ──────────────────────────────────────────────────────
            NavigationStack { homeTab }
                .tabItem { Label("Home",      systemImage: "house.fill") }
                .tag(0)

            // ── Clubs ─────────────────────────────────────────────────────
            NavigationStack { ClubsScreen(role: role) }
                .tabItem { Label("Clubs",     systemImage: "building.2.fill") }
                .tag(1)

            // ── Events ────────────────────────────────────────────────────
            NavigationStack { EventsScreen(role: role) }
                .tabItem { Label("Events",    systemImage: "calendar") }
                .tag(2)

            // ── Analytics ─────────────────────────────────────────────────
            if role != .student && role != .secretary {
                NavigationStack { AnalyticsDashboardView(role: role) }
                    .tabItem { Label("Analytics", systemImage: "chart.bar.fill") }
                    .tag(3)
            }

            // ── Profile (with Logout) ──────────────────────────────────────
            NavigationStack { ProfileScreen(role: role, onLogout: { authManager.logout() }) }
                .tabItem { Label("Profile",   systemImage: "person.fill") }
                .tag(4)
        }
        .tint(.purple)
        .toolbar(.hidden, for: .navigationBar)
        .onAppear {
            print("👤 [PresidentDashboardView] Initialized with role: \(role.rawValue)")
        }
        .onChange(of: role) { oldValue, newValue in
            print("👤 [PresidentDashboardView] Role changed from \(oldValue.rawValue) to \(newValue.rawValue)")
        }
    }
}

struct PresidentDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        PreviewWrapper {
        Group {
            PresidentDashboardView(role: .admin)         .previewDisplayName("Admin")
            PresidentDashboardView(role: .president)     .previewDisplayName("President")
            PresidentDashboardView(role: .vicePresident) .previewDisplayName("Vice President")
            PresidentDashboardView(role: .secretary)     .previewDisplayName("Secretary")
        }
        .environmentObject(AttendanceNotificationStore())
    
        }
    }
}

