//
//  SharedDashboardComponents.swift
//  CLUB ANALYTICSs
//
//  Reusable header + stat model shared by Secretary and Treasurer dashboards.
//

import SwiftUI

// MARK: - Stat data model
struct DashboardStat {
    let title:    String
    let value:    String
    let icon:     String
    var isWarning: Bool = false
}

// MARK: - Shared gradient header (used by Secretary, Treasurer & Student dashboards)
struct RoleDashboardHeader: View {
    let role: ClubRole
    let roleTitle: String
    var subtitle:  String = "Purple Innovation Club"   // ← now configurable
    let stats: [DashboardStat]          // exactly 4 items expected

    @EnvironmentObject private var store: AttendanceNotificationStore
    @State private var showNotificationPanel = false
    

    private var safeTop: CGFloat {
        UIApplication.shared
            .connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?
            .safeAreaInsets.top ?? 50
    }

    var body: some View {
        ZStack(alignment: .top) {
            // ── Gradient background ───────────────────────────────────────────
            LinearGradient(
                colors: [Color.purple, Color.blue],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)

            // ── Content ───────────────────────────────────────────────────────
            VStack(alignment: .leading, spacing: 0) {

                // Safe-area spacer – pushes content below Dynamic Island / camera
                Color.clear.frame(height: safeTop + 16)

                // Row 1 – Title + Bell
                HStack(alignment: .center) {
                    Text(roleTitle)
                        .font(.title2).bold()
                        .foregroundColor(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                    Spacer()
                    Button(action: { showNotificationPanel = true }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 44, height: 44)
                            Image(systemName: "bell.badge.fill")
                                .font(.system(size: 20)).foregroundColor(.white)
                            
                            if store.unreadCount > 0 {
                                Circle()
                                    .fill(Color.red)
                                    .frame(width: 12, height: 12)
                                    .offset(x: 12, y: -12)
                            }
                        }
                    }
                }
                .padding(.horizontal, 18)

                // Row 2 – Subtitle
                Text(subtitle)
                    .font(.subheadline).fontWeight(.medium)
                    .foregroundColor(.white.opacity(0.80))
                    .padding(.horizontal, 18)
                    .padding(.top, 4)
                    .padding(.bottom, 20)

                // Row 3 – Stat cards grid (2×2)
                LazyVGrid(columns: [
                    GridItem(.flexible(), spacing: 16),
                    GridItem(.flexible(), spacing: 16)
                ], spacing: 16) {
                    ForEach(stats.prefix(4), id: \.title) { stat in
                        StatCardView(
                            title:     stat.title,
                            value:     stat.value,
                            icon:      stat.icon,
                            isWarning: stat.isWarning
                        )
                    }
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 26)
            }
        }
        .frame(height: safeTop + 280)
        .sheet(isPresented: $showNotificationPanel) {
            NavigationStack {
                NotificationsView(role: role)
                    .environmentObject(store)
            }
        }
    }
}

// MARK: - Notifications View
struct NotificationsView: View {
    let role: ClubRole
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: AttendanceNotificationStore

    private var displayNotifications: [AttendanceNotification] {
        if role == .student {
            // Students only see notifications for events they are participating in or registered for
            return store.notifications.filter { note in
                if note.type == .eventRegistration {
                    return store.registeredEventTitles.contains(note.eventTitle)
                }
                return store.participants(for: note.eventTitle).contains(where: { $0.name == "Student User" }) // Mocking current user
            }
        } else {
            // Authorities see all updates
            return store.notifications
        }
    }

    var body: some View {
        List {
            if displayNotifications.isEmpty {
                Text("No new notifications")
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.top, 40)
                    .listRowBackground(Color.clear)
            } else {
                ForEach(displayNotifications) { note in
                    VStack(alignment: .leading, spacing: 6) {
                        if note.type == .eventRegistration {
                            Text("Event Registration")
                                .font(.headline)
                            
                            Text(note.eventTitle)
                                .font(.subheadline)
                            
                            Text("Status: Successfully Registered")
                                .font(.subheadline)
                                .foregroundColor(.green)
                        } else {
                            Text("Event Update — \(note.eventTitle)")
                                .font(.headline)
                            
                            Text("Participant: \(note.participantName)")
                                .font(.subheadline)
                            
                            if let sub = note.substituteName {
                                Text("Substitute: \(sub)")
                                    .font(.subheadline)
                                    .foregroundColor(.orange)
                            } else {
                                // Determine status from the participants list
                                let status = store.participants(for: note.eventTitle)
                                    .first(where: { $0.name == note.participantName })?.status ?? .confirmed
                                
                                if status == .absent {
                                    Text("Status: Absent")
                                        .font(.subheadline)
                                        .foregroundColor(.red)
                                } else {
                                    Text("Status: Confirmed")
                                        .font(.subheadline)
                                        .foregroundColor(.green)
                                }
                            }
                        }
                        
                        Text(note.timestamp, style: .time)
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)
                    .listRowBackground(note.isRead ? Color(UIColor.systemBackground) : Color.blue.opacity(0.05))
                }
            }
        }
        .navigationTitle("Notifications")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("Done") { dismiss() }
            }
        }
        .onAppear {
            store.markAllRead()
        }
    }
}

// MARK: - Shared Quick Action button used by all role dashboards
struct RoleQuickActionButton: View {
    let title:       String
    let icon:        String
    let color:       Color
    var action:      () -> Void = {}

    var body: some View {
        Button(action: action) {
            VStack(spacing: 12) {
                ZStack {
                    Circle().fill(color.opacity(0.15)).frame(width: 50, height: 50)
                    Image(systemName: icon).font(.system(size: 24)).foregroundColor(color)
                }
                Text(title)
                    .font(.subheadline).fontWeight(.semibold)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(16)
            .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Section header row (title + optional "View All" button)
struct SectionHeaderRow: View {
    let title: String
    var showViewAll: Bool = false

    var body: some View {
        HStack {
            Text(title).font(.title2).bold()
            Spacer()
            if showViewAll {
                Button("View All") {}
                    .font(.subheadline).fontWeight(.semibold).foregroundColor(.purple)
            }
        }
        .padding(.horizontal)
    }
}
