//
//  AppModels.swift
//  CLUB ANALYTICSs
//
//  Codable Swift models matching the FastAPI backend response schemas.
//

import Foundation
import SwiftUI

struct ClubMemberItem: Decodable, Identifiable, Hashable {
    let id: Int
    let name: String
    let email: String
    let role: String
}

// MARK: - Legacy / UI Models
struct ClubUser: Identifiable, Hashable {
    let id: UUID
    var dbId: Int = 0
    let name: String
    let role: String
    let club: String
    let eventsAttended: Int
    let attendance: Int
    let engagement: Int

    var initials: String {
        let parts = name.split(separator: " ")
        if parts.count >= 2 {
            return "\(parts[0].prefix(1))\(parts[1].prefix(1))".uppercased()
        }
        return String(name.prefix(2)).uppercased()
    }
}

struct ClubItem: Hashable {
    let name: String
    let category: String
    let icon: String // SF Symbol name
    let iconColor: Color
    let members: Int
    let engagement: Int
    let description: String
}

// MARK: - Auth
struct LoginRequest: Encodable {
    let email: String
    let password: String
}

struct SignupRequest: Encodable {
    let name: String
    let email: String
    let password: String
}

struct LoginResponse: Decodable {
    let message: String
    let user: UserResponseModel
}

struct UserResponseModel: Decodable {
    let id: Int
    let name: String
    let email: String
    let role: String
    let created_at: String
    var club_id: Int? // Optional club context
}

struct MessageResponse: Decodable {
    let message: String
}

// MARK: - Clubs
struct ClubResponse: Decodable, Identifiable {
    let id: Int
    let name: String
    let category: String?
    let description: String?
    let created_by: Int?
    let created_at: String
    let occupied_roles: [String]
    let instagram_url: String?

    enum CodingKeys: String, CodingKey {
        case id, category, description, created_by, created_at, occupied_roles, instagram_url
        case name = "club_name"
    }
}

// MARK: - Events
struct EventResponse: Decodable, Identifiable {
    let id: Int
    let title: String
    let description: String?
    let club_id: Int
    let date: String
    let created_by: Int?
    let created_at: String

    enum CodingKeys: String, CodingKey {
        case id, description, club_id, created_by, created_at
        case title = "event_name"
        case date = "event_date"
    }
}

// MARK: - Event Registration
struct EventRegistrationResponse: Decodable, Identifiable {
    let id: Int
    let event_id: Int
    let student_id: Int
    let registration_date: String
    let status: String
}

struct EventRegistrationCreate: Encodable {
    let event_id: Int
}

// MARK: - Announcements
struct AnnouncementResponse: Decodable, Identifiable {
    let id: Int
    let title: String
    let content: String
    let club_id: Int
    let author_id: Int
    let created_at: String
    let priority: String?
    let author_name: String?
    let club_name: String?
}

struct AnnouncementCreate: Encodable {
    let title: String
    let content: String
    let club_id: Int
}

// MARK: - Join Requests
struct JoinRequestResponse: Decodable, Identifiable {
    let id: Int
    let student_id: Int
    let club_id: Int
    let status: String
    let requested_at: String
    let student_name: String?
    let student_email: String?
}

struct JoinRequestCreate: Encodable {
    let student_id: Int
    let club_id: Int
}

// MARK: - Event Participants (for Attendance Marking)
struct EventParticipant: Decodable, Identifiable {
    let student_id: Int
    let name: String
    let email: String
    let role: String?
    let status: String?
    var id: Int { student_id }
}

// MARK: - Documents
struct DocumentResponse: Decodable, Identifiable {
    let id: Int
    let club_id: Int
    let title: String
    let file_url: String
    let uploaded_by: Int
    let created_at: String
}

struct DocumentCreate: Encodable {
    let club_id: Int
    let title: String
    let file_url: String
}

// MARK: - Reports
struct ReportResponse: Decodable, Identifiable {
    let id: Int
    let title: String
    let event_id: Int
    let club_id: Int
    let report_type: String
    let description: String?
    let file_url: String?
    let submitted_by: Int
    let submitted_at: String
    let event_name: String?
    let club_name: String?
}

// MARK: - Finance
struct ExpenseResponse: Decodable, Identifiable {
    let id: Int
    let club_id: Int
    let added_by: Int
    let title: String
    let amount: Double
    let description: String?
    let created_at: String
}

struct BudgetStatusResponse: Decodable {
    let total_budget: Double
    let remaining_budget: Double
}

struct ExpenseCreate: Encodable {
    let club_id: Int
    let title: String
    let amount: Double
    let description: String?
}

// MARK: - Analytics
struct ClubHealthResponse: Decodable {
    let club_id: Int
    let club_health_score: Double
    let average_engagement: Double
    let total_members: Int
    let event_participation_rate: Double
    let total_events: Int? // Made Optional to prevent decoding errors
}

struct ClubRankingItem: Identifiable {
    let clubId: Int
    let clubName: String
    let engagementScore: Double

    var id: Int { clubId }
}

struct StudentEngagementResponse: Decodable {
    let student_id: Int
    let events_registered: Int
    let events_attended: Int
    let club_attendance: Int
    let engagement_score: Int
    let clubs_joined: Int
    let club_id: Int?
}

// MARK: - Notifications
struct NotificationResponseModel: Decodable, Identifiable {
    let id: Int
    let title: String
    let message: String
    let created_at: String
}

// MARK: - Admin
struct AdminUserResponse: Decodable, Identifiable {
    let id: Int
    let name: String
    let email: String
    let role: String
    let created_at: String
}

struct PromoteRequest: Encodable {
    let role: String
    let club_id: Int  // Required: the club this user is being promoted to lead
}

struct ChangeLeadershipRequest: Encodable {
    let new_leader_id: Int
}

// MARK: - Club Attendance
struct AttendanceSessionResponse: Decodable {
    let id: Int
}

struct AttendanceRecordResponse: Decodable {
    let id: Int
    let status: String
}

struct AttendanceRecordRequest: Encodable {
    let session_id: Int
    let student_id: Int
    let status: String
}

struct EventAttendanceRequest: Encodable {
    let event_id: Int
    let student_id: Int
    let status: String
    var substitute_id: Int?
}

// MARK: - User Update
struct UserUpdateRequest: Encodable {
    let name: String?
    let email: String?
}

// MARK: - Dashboard & Analytics
struct PlatformSummaryResponse: Decodable {
    let total_clubs: Int
    let total_members: Int
    let active_events: Int
    let engagement_rate: Double
}

struct PlatformHealthResponse: Decodable {
    let health_score: Double
    let improvement: String
}

struct EngagementTrendResponse: Decodable {
    let labels: [String]
    let data: [Int]
}

struct AIAlert: Decodable, Identifiable {
    let id: String
    let type: String
    let title: String
    let message: String
}

struct AIAlertsResponse: Decodable {
    let alerts: [AIAlert]
}

struct FinancialReportResponse: Decodable {
    let total_budget: Double
    let total_expenses: Double
    let remaining_budget: Double
    let number_of_expenses: Int
    let events_funded: Int
}

struct DashboardResponse: Decodable {
    let total_clubs: Int
    let total_events: Int
    let recent_events: [EventResponse]
}

struct LowEngagementMember: Decodable, Identifiable {
    let student_id: Int
    let name: String
    let engagement_score: Int
    
    var id: Int { student_id }
}

// MARK: - Predictive Analytics
struct EventPrediction: Decodable, Identifiable {
    let event_name: String
    let predicted_participation_pct: Int
    var id: String { event_name }
}

struct AtRiskMember: Decodable, Identifiable {
    let name: String
    let initials: String
    let predicted_engagement_score: Int
    var id: String { name }
}

struct FutureTrend: Decodable, Identifiable {
    let week_label: String
    let trend_value: Double
    var id: String { week_label }
}

struct PredictiveAnalyticsResponse: Decodable {
    let event_predictions: [EventPrediction]
    let at_risk_members: [AtRiskMember]
    let future_trend: [FutureTrend]
}

// MARK: - AI Recommendations
struct SubstituteRecommendation: Decodable, Identifiable {
    let student_id: Int
    let name: String
    let engagement_score: Int
    var id: Int { student_id }
}

struct AIRecommendationResponse: Decodable, Identifiable {
    let id: String
    let icon: String
    let color: String
    let title: String
    let content: String
    
    var swiftColor: Color {
        switch color.lowercased() {
        case "red": return .red
        case "orange": return .orange
        case "blue": return .blue
        case "purple": return .purple
        case "green": return .green
        case "teal": return .teal
        default: return .gray
        }
    }
}

struct AIRecommendationsListResponse: Decodable {
    let recommendations: [AIRecommendationResponse]
}

// MARK: - Utilities
struct AnyEncodable: Encodable {
    private let _encode: (Encoder) throws -> Void

    init<T: Encodable>(_ wrapped: T) {
        _encode = wrapped.encode
    }

    func encode(to encoder: Encoder) throws {
        try _encode(encoder)
    }
}
