from fastapi import APIRouter, Depends
from sqlalchemy import inspect
from database import engine
import models
from core.permissions import require_authority

router = APIRouter(prefix="/system", tags=["System Audit"])

EXPECTED_MODULES = [
    "auth", "permissions", "admin", "clubs", "club_requests", "club_members",
    "member_management", "events", "event_registration", "attendance",
    "substitutions", "notifications", "documents", "finance", "analytics",
    "engagement", "recommendations"
]

EXPECTED_TABLES = [
    "users", "clubs", "club_members", "club_join_requests", "events",
    "event_registrations", "event_attendance", "club_attendance_sessions",
    "club_attendance_records", "substitutions", "notifications",
    "club_documents", "budgets", "expenses"
]

@router.get("/audit")
def system_audit(auth_user: models.User = Depends(require_authority)):
    inspector = inspect(engine)
    actual_tables = inspector.get_table_names()
    
    table_status = {}
    missing_tables = []
    
    for table in EXPECTED_TABLES:
        check_table = table
        if table == "substitutions" and "event_substitutions" in actual_tables:
            check_table = "event_substitutions"
            
        if check_table in actual_tables:
            table_status[table] = "OK"
        else:
            missing_tables.append(table)

    base_dir = os.path.dirname(os.path.dirname(__file__))
    routes_dir = os.path.join(base_dir, "routes")
    core_dir = os.path.join(base_dir, "core")
    
    actual_files = set()
    if os.path.exists(routes_dir):
        for f in os.listdir(routes_dir):
            if f.endswith(".py"):
                actual_files.add(f[:-3])
                
    if os.path.exists(core_dir):
        for f in os.listdir(core_dir):
            if f.endswith(".py"):
                actual_files.add(f[:-3])
                
    module_mappings = {
        "event_registration": ["registrations"],
        "attendance": ["event_attendance", "club_attendance"],
        "substitutions": ["substitutions"]
    }
    
    module_status = {}
    missing_modules = []
    
    for mod in EXPECTED_MODULES:
        found = False
        if mod in actual_files:
            found = True
        elif mod in module_mappings:
            for alias in module_mappings[mod]:
                if alias in actual_files:
                    found = True
                    break
                    
        if found:
            module_status[mod] = "OK"
        else:
            missing_modules.append(mod)
            
    return {
        "server_status": "running",
        "modules": module_status,
        "database_tables": table_status,
        "missing_modules": missing_modules,
        "missing_tables": missing_tables
    }
