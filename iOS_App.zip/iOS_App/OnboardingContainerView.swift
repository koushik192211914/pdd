//
//  OnboardingContainerView.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Onboarding Container (3 pages → Login)
//

import SwiftUI

struct OnboardingContainerView: View {
    @State private var currentPage = 0
    @State private var goLogin = false

    private let pages: [OnboardingPage] = [
        OnboardingPage(
            systemIcon: "waveform.path.ecg",
            accentColor: Color(red: 0.45, green: 0.25, blue: 0.95),
            title: "AI Insights Introduction",
            subtitle: "Unleash the Power of AI",
            description: "ClubSphere AI analyses student activity patterns, club performance, and engagement trends — surfacing intelligent insights so you can make smarter decisions, faster.",
            badge: "Powered by Machine Learning"
        ),
        OnboardingPage(
            systemIcon: "person.3.fill",
            accentColor: Color(red: 0.28, green: 0.14, blue: 0.80),
            title: "Club Engagement Tracking",
            subtitle: "Know Your Community",
            description: "Track attendance, participation scores, and member retention across all clubs in real time. Identify top performers and nurture every student's campus journey.",
            badge: "Real-Time Analytics"
        ),
        OnboardingPage(
            systemIcon: "calendar.badge.clock",
            accentColor: Color(red: 0.55, green: 0.12, blue: 0.72),
            title: "Smart Event Analytics",
            subtitle: "Plan. Execute. Improve.",
            description: "From registrations to post-event feedback, ClubSphere AI tracks every event metric and suggests optimisations for future events based on historical data.",
            badge: "AI-Driven Suggestions"
        )
    ]

    var body: some View {
        ZStack {
            onboardingBackground
            contentStack
        }
        .navigationDestination(isPresented: $goLogin) {
            LoginView()
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    private var onboardingBackground: some View {
        LinearGradient(
            colors: [
                Color(red: 0.04, green: 0.09, blue: 0.35),
                Color(red: 0.18, green: 0.06, blue: 0.42),
                Color(red: 0.30, green: 0.04, blue: 0.52)
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
        .overlay(
            AINetworkLinesView()
                .opacity(0.18)
                .ignoresSafeArea()
        )
    }

    private var contentStack: some View {
        VStack(spacing: 0) {
            TabView(selection: $currentPage) {
                ForEach(0..<pages.count, id: \.self) { i in
                    OnboardingPageView(page: pages[i])
                        .tag(i)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .animation(.easeInOut(duration: 0.4), value: currentPage)

            bottomControls
                .padding(.bottom, 44)
        }
    }

    private var bottomControls: some View {
        VStack(spacing: 28) {
            // Dot indicator
            HStack(spacing: 8) {
                ForEach(0..<pages.count, id: \.self) { i in
                    Capsule()
                        .fill(i == currentPage ? Color.white : Color.white.opacity(0.30))
                        .frame(width: i == currentPage ? 24 : 8, height: 8)
                        .animation(.spring(response: 0.35, dampingFraction: 0.7), value: currentPage)
                }
            }

            nextButton

            if currentPage < pages.count - 1 {
                Button { goLogin = true } label: {
                    Text("Skip")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(Color.white.opacity(0.45))
                }
            } else {
                Spacer().frame(height: 20)
            }
        }
    }

    private var nextButton: some View {
        let isLast = currentPage == pages.count - 1
        return Button {
            if isLast {
                goLogin = true
            } else {
                withAnimation(.easeInOut(duration: 0.4)) {
                    currentPage += 1
                }
            }
        } label: {
            HStack(spacing: 10) {
                Text(isLast ? "Get Started" : "Next")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(.white)
                Image(systemName: isLast ? "checkmark" : "arrow.right")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .background(
                LinearGradient(
                    colors: [
                        Color(red: 0.55, green: 0.30, blue: 1.0),
                        Color(red: 0.35, green: 0.10, blue: 0.80)
                    ],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: Color.purple.opacity(0.45), radius: 12, x: 0, y: 6)
        }
        .padding(.horizontal, 28)
    }
}

// MARK: – Data Model
struct OnboardingPage {
    let systemIcon: String
    let accentColor: Color
    let title: String
    let subtitle: String
    let description: String
    let badge: String
}

// MARK: – Single Onboarding Page
struct OnboardingPageView: View {
    let page: OnboardingPage
    @State private var appeared = false

    var body: some View {
        VStack(spacing: 0) {
            Spacer()
            illustrationCard
            Spacer().frame(height: 44)
            badgeView
            Spacer().frame(height: 20)
            textBlock
            Spacer()
        }
        .onAppear {
            withAnimation(.spring(response: 0.65, dampingFraction: 0.72).delay(0.1)) {
                appeared = true
            }
        }
        .onDisappear { appeared = false }
    }

    private var illustrationCard: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 36)
                .fill(page.accentColor.opacity(0.25))
                .frame(width: 220, height: 220)
                .blur(radius: 40)

            RoundedRectangle(cornerRadius: 32)
                .fill(
                    LinearGradient(
                        colors: [Color.white.opacity(0.10), Color.white.opacity(0.04)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 180, height: 180)
                .overlay(
                    RoundedRectangle(cornerRadius: 32)
                        .stroke(Color.white.opacity(0.12), lineWidth: 1)
                )

            Image(systemName: page.systemIcon)
                .resizable()
                .scaledToFit()
                .frame(width: 72, height: 72)
                .foregroundStyle(
                    LinearGradient(
                        colors: [.white, page.accentColor.opacity(0.8)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
        }
        .scaleEffect(appeared ? 1 : 0.75)
        .opacity(appeared ? 1 : 0)
    }

    private var badgeView: some View {
        Text(page.badge)
            .font(.system(size: 12, weight: .semibold))
            .foregroundColor(page.accentColor.opacity(0.9))
            .padding(.horizontal, 14)
            .padding(.vertical, 6)
            .background(
                Capsule()
                    .fill(Color.white.opacity(0.10))
                    .overlay(Capsule().stroke(page.accentColor.opacity(0.35), lineWidth: 1))
            )
            .opacity(appeared ? 1 : 0)
    }

    private var textBlock: some View {
        VStack(spacing: 8) {
            Text(page.subtitle)
                .font(.system(size: 30, weight: .bold))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 28)

            Text(page.title)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(page.accentColor.opacity(0.85))
                .tracking(1.2)

            Spacer().frame(height: 10)

            Text(page.description)
                .font(.system(size: 15, weight: .regular))
                .foregroundColor(Color.white.opacity(0.60))
                .multilineTextAlignment(.center)
                .lineSpacing(5)
                .padding(.horizontal, 32)
        }
        .opacity(appeared ? 1 : 0)
    }
}

#Preview {
    PreviewWrapper {
    NavigationStack {
        OnboardingContainerView()
    }
    .environmentObject(AttendanceNotificationStore())

    }
}
