# iOS Integration Guide (Node.js Backend)

This guide explains how to replace your local/mock data with API calls to the new Node.js backend (`http://127.0.0.1:3000`).

## 1. Storing the JWT Token
When you log in, the backend returns a `token`. Store this securely in the `Keychain` (recommended) or `UserDefaults` (for simplicity during development).

```swift
// Example: Storing token in UserDefaults
UserDefaults.standard.set(token, forKey: "cs_token")
```

## 2. Authentication API Call (Swift)
```swift
func login(email: String, password: String) {
    let url = URL(string: "http://127.0.0.1:3000/api/auth/login")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    
    let body = ["email": email, "password": password]
    request.httpBody = try? JSONSerialization.data(withJSONObject: body)
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data else { return }
        // Parse JWT Token from response and store it
    }.resume()
}
```

## 3. Protected API Call (Fetching Tasks)
Include the token in the `Authorization` header.

```swift
func fetchTasks() {
    let token = UserDefaults.standard.string(forKey: "cs_token") ?? ""
    let url = URL(string: "http://127.0.0.1:3000/api/tasks")!
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        // Handle response...
    }.resume()
}
```

## 4. Key Endpoints
- **POST /api/auth/login**: Sign in.
- **POST /api/auth/signup**: Register.
- **GET /api/tasks**: Fetch your tasks.
- **PUT /api/tasks/:id**: Update task status (e.g., `{"status": "Completed"}`).
