//
//  SSOButton.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Apple / Google SSO outlined buttons
//

import SwiftUI

struct SSOButton: View {
    let provider: SSOProvider
    let action: () -> Void

    @State private var isPressed = false

    enum SSOProvider {
        case apple, google

        var label: String {
            switch self {
            case .apple:  return "Apple"
            case .google: return "Google"
            }
        }

        var iconName: String {
            switch self {
            case .apple:  return "apple.logo"
            case .google: return "envelope.circle.fill"   // closest safe SF Symbol
            }
        }

        var iconColor: Color {
            switch self {
            case .apple:  return Color(red: 0.10, green: 0.10, blue: 0.12)
            case .google: return Color(red: 0.85, green: 0.28, blue: 0.24)
            }
        }
    }

    var body: some View {
        Button { action() } label: {
            HStack(spacing: 8) {
                Image(systemName: provider.iconName)
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(provider.iconColor)

                Text(provider.label)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(Color(red: 0.15, green: 0.15, blue: 0.18))
            }
            .frame(maxWidth: .infinity)
            .frame(height: 50)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color(red: 0.82, green: 0.82, blue: 0.86), lineWidth: 1)
                    )
                    .shadow(color: Color.black.opacity(0.04), radius: 4, x: 0, y: 2)
            )
            .scaleEffect(isPressed ? 0.97 : 1.0)
        }
        .buttonStyle(PlainButtonStyle())
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in
                    withAnimation(.easeOut(duration: 0.10)) { isPressed = true }
                }
                .onEnded { _ in
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) { isPressed = false }
                }
        )
    }
}

#Preview {
    PreviewWrapper {
    HStack(spacing: 12) {
        SSOButton(provider: .apple)  {}
        SSOButton(provider: .google) {}
    }
    .padding()

    }
}
