import SwiftUI

// MARK: - Edit Profile View
struct EditProfileView: View {
    @Environment(\.dismiss) private var dismiss

    // State
    @State private var name        = ""
    @State private var email       = ""
    @State private var isLoading   = true
    @State private var isSaving    = false
    @State private var showSuccess = false
    @State private var errorMessage: String?

    var body: some View {
        Group {
            if isLoading {
                ProgressView("Loading Profile...")
            } else {
                Form {
                    Section {
                        HStack {
                            Spacer()
                            VStack(spacing: 10) {
                                ZStack {
                                    Circle()
                                        .fill(LinearGradient(
                                            colors: [.purple, .blue],
                                            startPoint: .topLeading, endPoint: .bottomTrailing
                                        ))
                                        .frame(width: 80, height: 80)
                                    Text(String(name.prefix(2)).uppercased())
                                        .font(.title2).bold().foregroundColor(.white)
                                }
                            }
                            Spacer()
                        }
                        .listRowBackground(Color.clear)
                    }

                    Section(header: Text("Personal Information")) {
                        ProfileField(label: "Name", value: $name)
                        ProfileField(label: "Email", value: $email, keyboardType: .emailAddress)
                            .disabled(true)
                    }
                    
                    if let err = errorMessage {
                        Text(err).foregroundColor(.red).font(.caption)
                    }
                }
            }
        }
        .navigationTitle("Edit Profile")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if !isLoading {
                    Button("Save") {
                        Task { await saveProfile() }
                    }
                    .fontWeight(.semibold)
                    .foregroundColor(.purple)
                    .disabled(isSaving)
                }
            }
            ToolbarItem(placement: .navigationBarLeading) {
                Button("Cancel") { dismiss() }
                    .foregroundColor(.secondary)
            }
        }
        .task {
            await loadProfile()
        }
        .alert("Profile Saved", isPresented: $showSuccess) {
            Button("OK") { dismiss() }
        } message: {
            Text("Your profile has been updated successfully.")
        }
    }

    @MainActor
    private func loadProfile() async {
        isLoading = true
        do {
            let user = try await AuthService.shared.getMe()
            self.name = user.name
            self.email = user.email
        } catch {
            errorMessage = "Failed to load profile"
        }
        isLoading = false
    }

    @MainActor
    private func saveProfile() async {
        isSaving = true
        errorMessage = nil
        do {
            let updatedUser = try await AuthService.shared.updateProfile(name: name)
            AuthManager.shared.saveSession(user: updatedUser)
            showSuccess = true
        } catch {
            errorMessage = error.localizedDescription
        }
        isSaving = false
    }
}

// MARK: - Reusable text field row
private struct ProfileField: View {
    let label: String
    @Binding var value: String
    var keyboardType: UIKeyboardType = .default

    var body: some View {
        HStack {
            Text(label)
                .foregroundColor(.secondary)
                .frame(width: 110, alignment: .leading)
            TextField(label, text: $value)
                .keyboardType(keyboardType)
                .autocapitalization(keyboardType == .emailAddress ? .none : .words)
                .multilineTextAlignment(.leading)
        }
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
    NavigationStack {
        EditProfileView()
    }

    }
}
