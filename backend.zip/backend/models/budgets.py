from sqlalchemy import Column, Integer, Float, ForeignKey, DateTime, String
from sqlalchemy.sql import func
from database import Base

class Budget(Base):
    __tablename__ = "budgets"

    id = Column(Integer, primary_key=True, index=True)
    club_id = Column(Integer, ForeignKey("clubs.id"), nullable=False)
    total_budget = Column(Float, nullable=False)
    remaining_budget = Column(Float, nullable=False)
    status = Column(String(20), default="pending")  # pending, approved, rejected
    notes = Column(String(500), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
