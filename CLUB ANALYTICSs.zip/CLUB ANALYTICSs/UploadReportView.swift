import SwiftUI

struct UploadReportView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var reportTitle: String = ""
    @State private var selectedEvent: String = ""
    @State private var reportType: ReportType = .eventReport
    @State private var description: String = ""
    @State private var showSuccessMessage = false

    private let eventOptions = ["Tech Workshop", "Annual General Meeting", "Spring Hackathon", "Career Fair"]

    enum ReportType: String, CaseIterable, Identifiable {
        case eventReport = "Event Report"
        case meetingMinutes = "Meeting Minutes"
        case activityReport = "Activity Report"
        var id: String { self.rawValue }
    }

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // ── Header ───────────────────────────────────────────────
                headerView

                VStack(spacing: 24) {
                    // ── Form Area ───────────────────────────────────────────
                    VStack(alignment: .leading, spacing: 20) {
                        // Title
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Report Title", systemImage: "pencil.line")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            TextField("Enter report title", text: $reportTitle)
                                .padding()
                                .background(Color(UIColor.secondarySystemGroupedBackground))
                                .cornerRadius(12)
                                .shadow(color: .black.opacity(0.03), radius: 5, x: 0, y: 2)
                        }

                        // Event Picker
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Select Event", systemImage: "calendar")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            Menu {
                                ForEach(eventOptions, id: \.self) { event in
                                    Button(event) { selectedEvent = event }
                                }
                            } label: {
                                HStack {
                                    Text(selectedEvent.isEmpty ? "Select an event" : selectedEvent)
                                        .foregroundColor(selectedEvent.isEmpty ? .secondary : .primary)
                                    Spacer()
                                    Image(systemName: "chevron.down").font(.caption).foregroundColor(.secondary)
                                }
                                .padding()
                                .background(Color(UIColor.secondarySystemGroupedBackground))
                                .cornerRadius(12)
                                .shadow(color: .black.opacity(0.03), radius: 5, x: 0, y: 2)
                            }
                        }

                        // Report Type
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Report Type", systemImage: "doc.text.fill")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            Picker("Report Type", selection: $reportType) {
                                ForEach(ReportType.allCases) { type in
                                    Text(type.rawValue).tag(type)
                                }
                            }
                            .pickerStyle(.segmented)
                        }

                        // File Upload Placeholder
                        VStack(alignment: .leading, spacing: 8) {
                            Label("File Upload (PDF / DOC / Image)", systemImage: "paperclip")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            Button(action: { /* File picker action */ }) {
                                HStack {
                                    Image(systemName: "arrow.up.doc.fill")
                                    Text("Choose File").fontWeight(.medium)
                                    Spacer()
                                }
                                .padding()
                                .foregroundColor(.blue)
                                .background(Color.blue.opacity(0.08))
                                .cornerRadius(12)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.blue.opacity(0.3), lineWidth: 1)
                                )
                            }
                        }

                        // Description
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Description (Optional)", systemImage: "text.alignleft")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            TextEditor(text: $description)
                                .frame(minHeight: 120)
                                .padding(8)
                                .background(Color(UIColor.secondarySystemGroupedBackground))
                                .cornerRadius(12)
                                .shadow(color: .black.opacity(0.03), radius: 5, x: 0, y: 2)
                        }
                    }
                    .padding(.horizontal)

                    // ── Submit Button ───────────────────────────────────────
                    Button(action: {
                        // In a real app, save logic goes here
                        withAnimation {
                            showSuccessMessage = true
                        }
                        // Navigate back after a short delay
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                            dismiss()
                        }
                    }) {
                        Text("Submit Report")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(
                                LinearGradient(colors: [.purple, .blue], startPoint: .leading, endPoint: .trailing)
                            )
                            .cornerRadius(16)
                            .shadow(color: .purple.opacity(0.3), radius: 8, x: 0, y: 4)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 40)
                    .disabled(reportTitle.isEmpty || selectedEvent.isEmpty)
                    .opacity(reportTitle.isEmpty || selectedEvent.isEmpty ? 0.6 : 1.0)
                }
                .padding(.top, 24)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .overlay(
            Group {
                if showSuccessMessage {
                    ZStack {
                        Color.black.opacity(0.3).ignoresSafeArea()
                        VStack(spacing: 16) {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.green)
                            Text("Report Submitted!")
                                .font(.title3).bold()
                            Text("Returning to dashboard...")
                                .font(.subheadline).foregroundColor(.secondary)
                        }
                        .padding(30)
                        .background(Color(UIColor.systemBackground))
                        .cornerRadius(24)
                        .shadow(radius: 20)
                    }
                    .transition(.opacity)
                }
            }
        )
    }

    private var headerView: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 8)
                HStack(alignment: .center, spacing: 12) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Upload Report").font(.title3).bold().foregroundColor(.white)
                        Text("Submit new event or meeting documentation")
                            .font(.caption).foregroundColor(.white.opacity(0.80)).lineLimit(1)
                    }
                    Spacer()
                }
                .padding(.horizontal, 18).padding(.bottom, 22)
            }
        }
        .frame(height: safeTop + 92) // Changed from minHeight to height
    }
}

#Preview {
    PreviewWrapper {
    UploadReportView()

    }
}
