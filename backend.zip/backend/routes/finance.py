from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import UserRole, User, Club
from models.budgets import Budget
from models.expenses import Expense

from schemas.finance import (
    BudgetCreate, 
    ExpenseCreate, 
    ExpenseResponse, 
    BudgetResponse, 
    BudgetUpdateFull, 
    FinancialReportResponse
)
from core.permissions import get_current_user, require_authority

router = APIRouter(prefix="/finance", tags=["Finance"])

@router.post("/budget/create")
def create_budget(budget_in: BudgetCreate, db: Session = Depends(get_db), auth_user: User = Depends(require_authority)):
    club = db.query(Club).filter(Club.id == budget_in.club_id).first()
    if not club:
        raise HTTPException(status_code=404, detail="Club not found")
        
    budget = Budget(
        club_id=budget_in.club_id,
        total_budget=budget_in.total_budget,
        remaining_budget=budget_in.total_budget
    )
    db.add(budget)
    db.commit()
    db.refresh(budget)
    return {"total_budget": budget.total_budget, "remaining_budget": budget.remaining_budget}

@router.post("/expense/add")
def add_expense(
    expense_in: ExpenseCreate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(get_current_user)
):
    if current_user.role not in [UserRole.Treasurer, UserRole.Admin, UserRole.VicePresident]:
        raise HTTPException(status_code=403, detail="Only Treasurer, VicePresident or Admin can add expenses")
        
    club = db.query(Club).filter(Club.id == expense_in.club_id).first()
    if not club:
        raise HTTPException(status_code=404, detail="Club not found")
        
    budget = db.query(Budget).filter(Budget.club_id == expense_in.club_id).order_by(Budget.created_at.desc()).first()
    if not budget:
        raise HTTPException(status_code=400, detail="No budget set for this club")
        
    if budget.remaining_budget < expense_in.amount:
        raise HTTPException(status_code=400, detail="Insufficient remaining budget")
        
    expense = Expense(
        club_id=expense_in.club_id,
        added_by=current_user.id,
        title=expense_in.title,
        amount=expense_in.amount,
        description=expense_in.description
    )
    db.add(expense)
    
    budget.remaining_budget -= expense_in.amount
    db.commit()
    db.refresh(expense)
    return expense

@router.get("/expenses/{club_id}", response_model=List[ExpenseResponse])
def view_expenses(club_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    allowed_roles = [UserRole.President, UserRole.VicePresident, UserRole.Admin, UserRole.Treasurer]
    if current_user.role not in allowed_roles:
        raise HTTPException(status_code=403, detail="Not authorized to view expenses")
        
    expenses = db.query(Expense).filter(Expense.club_id == club_id).order_by(Expense.created_at.desc()).all()
    return expenses

@router.get("/budget/{club_id}")
def view_budget_status(club_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    allowed_roles = [UserRole.Admin, UserRole.President, UserRole.VicePresident, UserRole.Treasurer]
    if current_user.role not in allowed_roles:
        raise HTTPException(status_code=403, detail="Not authorized to view budgets")
        
    budget = db.query(Budget).filter(Budget.club_id == club_id).order_by(Budget.created_at.desc()).first()
    if not budget:
        return {"total_budget": 0.0, "remaining_budget": 0.0}
        
    return {
        "total_budget": budget.total_budget,
        "remaining_budget": budget.remaining_budget
    }

@router.post("/budget/{budget_id}/approve", response_model=BudgetResponse)
def approve_budget(budget_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_authority)):
    budget = db.query(Budget).filter(Budget.id == budget_id).first()
    if not budget:
        raise HTTPException(status_code=404, detail="Budget not found")
        
    budget.status = "approved"
    db.commit()
    db.refresh(budget)
    return budget

@router.post("/budget/{budget_id}/reject", response_model=BudgetResponse)
def reject_budget(budget_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_authority)):
    budget = db.query(Budget).filter(Budget.id == budget_id).first()
    if not budget:
        raise HTTPException(status_code=404, detail="Budget not found")
        
    budget.status = "rejected"
    db.commit()
    db.refresh(budget)
    return budget

@router.put("/budget/{budget_id}", response_model=BudgetResponse)
def update_budget(budget_id: int, budget_in: BudgetUpdateFull, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role not in [UserRole.Treasurer, UserRole.Admin]:
        raise HTTPException(status_code=403, detail="Only Treasurer or Admin can update budgets")
        
    budget = db.query(Budget).filter(Budget.id == budget_id).first()
    if not budget:
        raise HTTPException(status_code=404, detail="Budget not found")
        
    budget.total_budget = budget_in.total_budget
    budget.remaining_budget = budget_in.remaining_budget
    budget.notes = budget_in.notes
    
    db.commit()
    db.refresh(budget)
    return budget

@router.delete("/expense/{expense_id}")
def delete_expense(expense_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role not in [UserRole.Treasurer, UserRole.Admin]:
        raise HTTPException(status_code=403, detail="Only Treasurer or Admin can delete expenses")
        
    expense = db.query(Expense).filter(Expense.id == expense_id).first()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
        
    # Optional: Restore remaining budget
    budget = db.query(Budget).filter(Budget.club_id == expense.club_id).order_by(Budget.created_at.desc()).first()
    if budget:
        budget.remaining_budget += expense.amount
        
    db.delete(expense)
    db.commit()
    return {"message": "Expense deleted successfully"}

@router.get("/reports/{club_id}", response_model=FinancialReportResponse)
def get_financial_report(club_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_authority)):
    budget = db.query(Budget).filter(Budget.club_id == club_id).order_by(Budget.created_at.desc()).first()
    expenses = db.query(Expense).filter(Expense.club_id == club_id).all()
    
    total_budget = budget.total_budget if budget else 0.0
    remaining_budget = budget.remaining_budget if budget else 0.0
    total_expenses = sum(e.amount for e in expenses)
    number_of_expenses = len(expenses)
    
    # Events funded (heuristic: unique titles or just number of expenses for now if no direct event mapping in model)
    # The prompt mentions events_funded. Let's count expenses that mention 'Event' or are distinct.
    events_funded = len(set(e.title for e in expenses if "event" in e.title.lower()))
    if events_funded == 0 and number_of_expenses > 0:
        events_funded = 1 # Fallback
        
    return {
        "total_budget": total_budget,
        "total_expenses": total_expenses,
        "remaining_budget": remaining_budget,
        "number_of_expenses": number_of_expenses,
        "events_funded": events_funded
    }
