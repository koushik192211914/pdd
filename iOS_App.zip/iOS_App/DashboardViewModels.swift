//
//  DashboardViewModels.swift
//  CLUB ANALYTICSs
//

import Foundation
import SwiftUI
import Combine



// MARK: - Admin Dashboard
@MainActor
final class AdminHomeViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showDebugAlert = false
    @Published var debugMessage = ""
    @Published var lastUpdated = Date()
    @Published var summary: PlatformSummaryResponse?
    @Published var dashboard: DashboardResponse?
    
    // Flattened properties for easier direct binding
    @Published var totalClubs: Int = 0
    @Published var totalMembers: Int = 0
    @Published var activeEvents: Int = 0
    @Published var engagementRate: Double = 0.0
    
    func fetchData() async {
        if isLoading { return }
        print("🔍 [AdminHomeViewModel] fetchData() started")
        isLoading = true
        errorMessage = nil
        
        do {
            print("🚀 [AdminHomeViewModel] Starting data fetch from AdminService...")
            async let s = AdminService.shared.getPlatformSummary()
            async let d = AdminService.shared.getDashboard()
            
            let (summaryResponse, dashboardResponse) = try await (s, d)
            print("✅ [AdminHomeViewModel] API Response Received!")
            print("📊 Platform Stats: Clubs=\(summaryResponse.total_clubs), Members=\(summaryResponse.total_members), Events=\(summaryResponse.active_events)")
            
            self.summary = summaryResponse
            self.dashboard = dashboardResponse
            
            // Explicitly signal change before updating flattened properties
            self.objectWillChange.send()
            
            self.totalClubs = summaryResponse.total_clubs
            self.totalMembers = summaryResponse.total_members
            self.activeEvents = summaryResponse.active_events
            self.engagementRate = summaryResponse.engagement_rate
            
            print("💾 [AdminHomeViewModel] Local state updated successfully.")
            self.lastUpdated = Date()
        } catch {
            print("❌ [AdminHomeViewModel] Error in fetchData: \(error.localizedDescription)")
            errorMessage = "Sync Error: \(error.localizedDescription)"
        }
        
        print("🏁 [AdminHomeViewModel] fetchData() finished. isLoading set to false.")
        isLoading = false
    }
}


// MARK: - President Dashboard
final class PresidentHomeViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var club: ClubResponse?
    @Published var lastUpdated = Date()
    @Published var health: ClubHealthResponse?
    @Published var events: [EventResponse] = []
    @Published var lowEngagementMembers: [LowEngagementMember] = []
    @Published var announcements: [AnnouncementResponse] = []
    @Published var pendingRequestCount: Int = 0 
    
    @MainActor
    func fetchData(clubId: Int) async {
        if isLoading { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            async let c = ClubService.shared.getClub(id: clubId)
            async let h = AnalyticsService.shared.getClubHealth(clubId: clubId)
            async let e = EventService.shared.getEvents(clubId: clubId)
            async let l = AnalyticsService.shared.getLowEngagementMembers(clubId: clubId)
            async let ann = AnnouncementService.shared.getAnnouncements(clubId: clubId)
            async let pending = JoinRequestService.shared.getPendingRequests(clubId: clubId)
            
            let (club, health, events, lowEng, annList, pendingList) = try await (c, h, e, l, ann, pending)
            self.club = club
            self.health = health
            self.events = events
            self.lowEngagementMembers = lowEng
            self.announcements = annList
            self.pendingRequestCount = pendingList.count
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: - Secretary Dashboard
final class SecretaryHomeViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var club: ClubResponse?
    @Published var announcements: [AnnouncementResponse] = []
    @Published var documents: [DocumentResponse] = []
    @Published var summary: [String: Int] = [:]
    @Published var lastUpdated = Date()
    
    @MainActor
    func fetchData(clubId: Int) async {
        if isLoading { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            async let c = ClubService.shared.getClub(id: clubId)
            async let a = AnnouncementService.shared.getAnnouncements(clubId: clubId)
            async let d = DocumentService.shared.getDocuments(clubId: clubId)
            async let s: [String: Int] = APIClient.shared.request("/analytics/club/\(clubId)")
            
            let (club, ann, docs, sum) = try await (c, a, d, s)
            self.club = club
            self.announcements = ann
            self.documents = docs
            self.summary = sum
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}


// MARK: - Student Dashboard
final class StudentHomeViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var engagement: StudentEngagementResponse?
    @Published var myClubs: [ClubResponse] = []
    @Published var events: [EventResponse] = []
    
    @MainActor
    func fetchData(studentId: Int, clubId: Int?) async {
        if isLoading { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            let eng = try await AnalyticsService.shared.getStudentEngagement(studentId: studentId)
            self.engagement = eng
            
            // If the user just joined a club, we might get the clubId from the engagement response
            let effectiveClubId = clubId ?? eng.club_id
            
            if let cid = effectiveClubId {
                // Load only the student's own club and its events
                async let c = ClubService.shared.getClub(id: cid)
                async let ev = EventService.shared.getEvents(clubId: cid)
                let (club, clubEvents) = try await (c, ev)
                self.myClubs = [club]
                self.events = clubEvents
            } else {
                // No club yet — clear lists
                self.myClubs = []
                self.events = []
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
