import SwiftUI

struct UpdateBudgetView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var totalBudget: String = ""
    @State private var allocatedBudget: String = ""
    @State private var remainingBudget: String = ""
    @State private var showSuccessMessage = false

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // ── Header ───────────────────────────────────────────────
                headerView

                VStack(spacing: 24) {
                    // ── Form Area ───────────────────────────────────────────
                    VStack(alignment: .leading, spacing: 20) {
                        
                        formField(title: "Total Club Budget", icon: "building.columns", placeholder: "e.g. 50000", text: $totalBudget)
                        
                        formField(title: "Allocated Budget", icon: "chart.pie", placeholder: "e.g. 32000", text: $allocatedBudget)
                        
                        formField(title: "Remaining Budget", icon: "indianrupeesign.circle", placeholder: "e.g. 18000", text: $remainingBudget)
                        
                        // Description/Note
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Update Notes (Optional)", systemImage: "text.alignleft")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            TextEditor(text: .constant(""))
                                .frame(minHeight: 120)
                                .padding(8)
                                .background(Color(UIColor.secondarySystemGroupedBackground))
                                .cornerRadius(12)
                                .shadow(color: .black.opacity(0.03), radius: 5, x: 0, y: 2)
                        }
                    }
                    .padding(.horizontal)

                    // ── Submit Button ───────────────────────────────────────
                    Button(action: {
                        withAnimation { showSuccessMessage = true }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                            dismiss()
                        }
                    }) {
                        Text("Update Budget")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(
                                LinearGradient(colors: [.orange, .red], startPoint: .leading, endPoint: .trailing)
                            )
                            .cornerRadius(16)
                            .shadow(color: .orange.opacity(0.3), radius: 8, x: 0, y: 4)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 40)
                    .disabled(totalBudget.isEmpty)
                    .opacity(totalBudget.isEmpty ? 0.6 : 1.0)
                }
                .padding(.top, 24)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .overlay(
            Group {
                if showSuccessMessage {
                    ZStack {
                        Color.black.opacity(0.3).ignoresSafeArea()
                        VStack(spacing: 16) {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.green)
                            Text("Budget Updated!")
                                .font(.title3).bold()
                            Text("Navigating to dashboard...")
                                .font(.subheadline).foregroundColor(.secondary)
                        }
                        .padding(30)
                        .background(Color(UIColor.systemBackground))
                        .cornerRadius(24)
                        .shadow(radius: 20)
                    }
                    .transition(.opacity)
                }
            }
        )
    }

    private var headerView: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 8)
                HStack(alignment: .center, spacing: 12) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Update Budget").font(.title3).bold().foregroundColor(.white)
                        Text("Modify club financial allocations")
                            .font(.caption).foregroundColor(.white.opacity(0.80)).lineLimit(1)
                    }
                    Spacer()
                }
                .padding(.horizontal, 18).padding(.bottom, 22)
            }
        }
        .frame(height: safeTop + 92)
    }

    private func formField(title: String, icon: String, placeholder: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(title, systemImage: icon)
                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
            HStack {
                Text("₹").foregroundColor(.secondary).fontWeight(.medium)
                TextField(placeholder, text: text)
                    .keyboardType(.decimalPad)
            }
            .padding()
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.03), radius: 5, x: 0, y: 2)
        }
    }
}

#Preview {
    PreviewWrapper {
    UpdateBudgetView()

    }
}
