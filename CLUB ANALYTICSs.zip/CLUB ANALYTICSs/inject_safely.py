import os
import re

dir_path = "/Users/sail/Desktop/CLUB ANALYTICSs/CLUB ANALYTICSs"

def get_matching_brace(text, start_idx):
    count = 1
    idx = start_idx
    while count > 0 and idx < len(text):
        if text[idx] == '{': count += 1
        elif text[idx] == '}': count -= 1
        idx += 1
    return idx if count == 0 else -1

files_modified = 0

for filename in os.listdir(dir_path):
    if not filename.endswith(".swift") or filename == "PreviewWrapper.swift":
        continue
        
    filepath = os.path.join(dir_path, filename)
    with open(filepath, 'r') as f:
        content = f.read()
        
    original = content
    
    # Process #Preview blocks
    pattern1 = r'#Preview(?:\s*\([^)]*\))?\s*\{'
    matches = list(re.finditer(pattern1, content))
    for match in reversed(matches):
        start_idx = match.end()
        end_idx = get_matching_brace(content, start_idx)
        if end_idx == -1: continue
        
        inner = content[start_idx:end_idx-1]
        if "PreviewWrapper" in inner: continue
        
        new_inner = f"\n    PreviewWrapper {{{inner}\n    }}\n"
        content = content[:start_idx] + new_inner + content[end_idx-1:]

    # Process PreviewProvider blocks
    pattern2 = r'(static\s+var\s+previews\s*:\s*some\s+View\s*\{)'
    matches = list(re.finditer(pattern2, content))
    for match in reversed(matches):
        start_idx = match.end()
        end_idx = get_matching_brace(content, start_idx)
        if end_idx == -1: continue
        
        inner = content[start_idx:end_idx-1]
        if "PreviewWrapper" in inner: continue
        
        new_inner = f"\n        PreviewWrapper {{{inner}\n        }}\n    "
        content = content[:start_idx] + new_inner + content[end_idx-1:]

    if content != original:
        with open(filepath, 'w') as f:
            f.write(content)
        files_modified += 1
        print(f"Patched {filename}")

print(f"Successfully processed {files_modified} files.")
