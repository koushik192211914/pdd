import sys
sys.path.append("/Users/sail/Desktop/CLUB ANALYTICSs/backend")
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import User, Base
from database import engine, SessionLocal
from core.security import hash_password, verify_password

def test_db():
    db = SessionLocal()
    users = db.query(User).all()
    print("Users in DB:")
    for u in users:
        print(f"ID: {u.id}, Email: {u.email}, Hash: {u.password_hash}")
    
    # Let's create a test user if none exist or just print
    if not any(u.email == "test@example.com" for u in users):
        test_user = User(
            name="Test User",
            email="test@example.com",
            password_hash=hash_password("password123"),
            role="Student"
        )
        db.add(test_user)
        db.commit()
        print("Created test@example.com / password123")
    else:
        u = db.query(User).filter(User.email=="test@example.com").first()
        print("Test user exists. Verifying password 'password123':", verify_password("password123", u.password_hash))
    
    db.close()

if __name__ == "__main__":
    test_db()
