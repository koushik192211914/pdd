//
//  DashboardView.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Dashboard placeholder (to be expanded later)
//

import SwiftUI

struct DashboardView: View {
    let role: String

    var body: some View {
        ZStack {
            Color(red: 0.97, green: 0.97, blue: 0.98)
                .ignoresSafeArea()

            VStack(spacing: 24) {
                ZStack {
                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [
                                    Color(red: 0.92, green: 0.88, blue: 1.0),
                                    Color(red: 0.80, green: 0.72, blue: 1.0)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: 100, height: 100)

                    Image(systemName: "house.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 44, height: 44)
                        .foregroundColor(Color(red: 0.55, green: 0.18, blue: 0.95))
                }

                VStack(spacing: 8) {
                    Text("Welcome to Dashboard")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(Color(red: 0.10, green: 0.10, blue: 0.12))

                    Text("Signed in as \(role)")
                        .font(.system(size: 15, weight: .regular))
                        .foregroundColor(Color(red: 0.50, green: 0.50, blue: 0.55))
                }
            }
        }
        .navigationTitle("")
        .toolbar(.hidden, for: .navigationBar)
    }
}

#Preview {
    PreviewWrapper {
    DashboardView(role: "Admin")

    }
}
