import SwiftUI
import Combine

// MARK: ─────────────────────────────────────────────────────────────
// ANNOUNCEMENT WORKFLOW
// Full 3-screen flow:
//   CreateAnnouncementScreen → PreviewAnnouncementScreen → AnnouncementSuccessScreen
//
// Entry point:  Admin Dashboard "Send Announcement" quick action
// Exit point:   AnnouncementSuccessScreen "Return to Dashboard" → pop to root
// ─────────────────────────────────────────────────────────────────
extension Notification.Name {
    static let dismissAnnouncementFlow = Notification.Name("dismissAnnouncementFlow")
}

// MARK: - Announcement Data Model (shared across all screens)
struct AnnouncementDraft {
    var title:    String            = ""
    var message:  String            = ""
    var audience: AudienceTarget    = .allClubs
    var club:     String            = ""
    var priority: AnnouncementLevel = .normal
}

enum AudienceTarget: String, CaseIterable, Identifiable {
    case allClubs      = "All Clubs"
    case specificClub  = "Specific Club"
    case specificRole  = "Specific Role"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .allClubs:     return "globe"
        case .specificClub: return "building.2.fill"
        case .specificRole: return "person.badge.key.fill"
        }
    }
}

enum AnnouncementLevel: String, CaseIterable, Identifiable {
    case high   = "High"
    case medium = "Medium"
    case normal = "Normal"
    var id: String { rawValue }

    var color: Color {
        switch self {
        case .high:   return .red
        case .medium: return .orange
        case .normal: return .blue
        }
    }
    var icon: String {
        switch self {
        case .high:   return "exclamationmark.triangle.fill"
        case .medium: return "exclamationmark.circle.fill"
        case .normal: return "info.circle.fill"
        }
    }
    var label: String { "\(rawValue) Priority" }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - SCREEN 1 · Create Announcement Screen
// ─────────────────────────────────────────────────────────────────
struct CreateAnnouncementScreen: View {
    // Support both push navigation (Admin Dashboard) and internal back-nav
    var existingDraft: AnnouncementDraft? = nil

    @Environment(\.dismiss) private var dismiss

    @State private var draft = AnnouncementDraft()
    @State private var showValidation  = false
    @State private var navigatePreview = false

    private let clubOptions: [String] = [
        "Tech Innovation Club", "Robotics Society", "Business Leaders",
        "Design Collective", "Environmental Club", "Music & Arts Club"
    ]
    private let roleOptions: [String] = [
        "President", "Vice President", "Secretary", "Students"
    ]

    private var isFormValid: Bool {
        !draft.title.trimmingCharacters(in: .whitespaces).isEmpty &&
        !draft.message.trimmingCharacters(in: .whitespaces).isEmpty
    }

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 0) {
                    // ── Gradient header ──────────────────────────────────────
                    announcementHeader

                    VStack(spacing: 20) {
                        // ── Form card ────────────────────────────────────────
                        formCard

                        // ── Priority selector ────────────────────────────────
                        priorityCard

                        // Validation
                        if showValidation {
                            HStack(spacing: 8) {
                                Image(systemName: "exclamationmark.circle.fill")
                                    .foregroundColor(.red).font(.caption)
                                Text("Title and Message are required.")
                                    .font(.caption).foregroundColor(.red)
                            }
                            .padding(.horizontal, 4)
                        }

                        // ── Buttons ──────────────────────────────────────────
                        actionButtons
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    .padding(.bottom, 48)
                }
            }
            .ignoresSafeArea(edges: .top)
            .background(Color(UIColor.systemGroupedBackground))
            .navigationBarHidden(true)
            .onAppear { if let d = existingDraft { draft = d } }
            .navigationDestination(isPresented: $navigatePreview) {
                PreviewAnnouncementScreen(
                    draft:         draft
                )
            }
        }
    }

    // MARK: Header
    private var announcementHeader: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [Color.purple, Color.blue],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 8)
                HStack(alignment: .center, spacing: 12) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Create Announcement").font(.title3).bold().foregroundColor(.white)
                        Text("Compose platform-wide or targeted messages")
                            .font(.caption).foregroundColor(.white.opacity(0.80)).lineLimit(1)
                    }
                    Spacer()
                }
                .padding(.horizontal, 18).padding(.bottom, 22)
            }
        }
        .frame(minHeight: safeTop + 92)
    }

    // MARK: Form card
    private var formCard: some View {
        VStack(spacing: 18) {
            // Title
            VStack(alignment: .leading, spacing: 8) {
                Label("Announcement Title", systemImage: "megaphone.fill")
                    .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                TextField("e.g. Reminder: Submit Event Reports", text: $draft.title)
                    .font(.subheadline)
                    .padding(.horizontal, 14).padding(.vertical, 12)
                    .background(Color(UIColor.tertiarySystemGroupedBackground))
                    .cornerRadius(12)
            }

            // Message
            VStack(alignment: .leading, spacing: 8) {
                Label("Announcement Message", systemImage: "text.alignleft")
                    .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                TextField("Write your announcement message here…",
                          text: $draft.message, axis: .vertical)
                    .font(.subheadline).lineLimit(5)
                    .padding(.horizontal, 14).padding(.vertical, 12)
                    .background(Color(UIColor.tertiarySystemGroupedBackground))
                    .cornerRadius(12)
            }

            // Target Audience
            VStack(alignment: .leading, spacing: 8) {
                Label("Target Audience", systemImage: "person.3.fill")
                    .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                // Segmented-style chips
                HStack(spacing: 8) {
                    ForEach(AudienceTarget.allCases) { target in
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.15)) { draft.audience = target }
                        }) {
                            HStack(spacing: 4) {
                                Image(systemName: target.icon).font(.caption2)
                                Text(target.rawValue).font(.caption).fontWeight(.semibold)
                            }
                            .foregroundColor(draft.audience == target ? .white : .secondary)
                            .padding(.horizontal, 10).padding(.vertical, 7)
                            .background(
                                draft.audience == target
                                ? AnyView(LinearGradient(colors: [Color.purple, Color.blue],
                                                         startPoint: .leading, endPoint: .trailing)
                                    .clipShape(Capsule()))
                                : AnyView(Capsule().fill(Color(UIColor.tertiarySystemGroupedBackground)))
                            )
                        }
                        .animation(.easeInOut(duration: 0.15), value: draft.audience)
                    }
                }

                // Conditional club picker (Specific Club only)
                if draft.audience == .specificClub {
                    Menu {
                        ForEach(clubOptions, id: \.self) { club in
                            Button(club) { draft.club = club }
                        }
                    } label: {
                        HStack {
                            Text(draft.club.isEmpty ? "Select a club" : draft.club)
                                .font(.subheadline)
                                .foregroundColor(draft.club.isEmpty ? Color(UIColor.placeholderText) : .primary)
                            Spacer()
                            Image(systemName: "chevron.up.chevron.down")
                                .font(.caption).foregroundColor(.secondary)
                        }
                        .padding(.horizontal, 14).padding(.vertical, 12)
                        .background(Color(UIColor.tertiarySystemGroupedBackground))
                        .cornerRadius(12)
                    }
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }

                // Conditional role picker (Specific Role only)
                if draft.audience == .specificRole {
                    Menu {
                        ForEach(roleOptions, id: \.self) { role in
                            Button(role) { draft.club = role }     // reuse .club field to store role name
                        }
                    } label: {
                        HStack {
                            Text(draft.club.isEmpty ? "Select a role" : draft.club)
                                .font(.subheadline)
                                .foregroundColor(draft.club.isEmpty ? Color(UIColor.placeholderText) : .primary)
                            Spacer()
                            Image(systemName: "chevron.up.chevron.down")
                                .font(.caption).foregroundColor(.secondary)
                        }
                        .padding(.horizontal, 14).padding(.vertical, 12)
                        .background(Color(UIColor.tertiarySystemGroupedBackground))
                        .cornerRadius(12)
                    }
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
        }
        .padding(18)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 3)
        .animation(.easeInOut(duration: 0.20), value: draft.audience)
    }

    // MARK: Priority card
    private var priorityCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Priority", systemImage: "flag.fill")
                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)

            HStack(spacing: 10) {
                ForEach(AnnouncementLevel.allCases) { level in
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.15)) { draft.priority = level }
                    }) {
                        HStack(spacing: 5) {
                            Image(systemName: level.icon).font(.caption2)
                            Text(level.rawValue).font(.caption).fontWeight(.semibold)
                        }
                        .foregroundColor(draft.priority == level ? .white : level.color)
                        .frame(maxWidth: .infinity).padding(.vertical, 10)
                        .background(
                            draft.priority == level
                            ? AnyView(level.color.clipShape(RoundedRectangle(cornerRadius: 10)))
                            : AnyView(level.color.opacity(0.10)
                                .clipShape(RoundedRectangle(cornerRadius: 10)))
                        )
                    }
                }
            }
        }
        .padding(18)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 3)
    }

    // MARK: Action buttons
    private var actionButtons: some View {
        VStack(spacing: 12) {
            // Preview
            Button(action: {
                guard isFormValid else { withAnimation { showValidation = true }; return }
                showValidation = false
                navigatePreview = true
            }) {
                HStack(spacing: 8) {
                    Image(systemName: "eye.fill").font(.system(size: 16, weight: .semibold))
                    Text("Preview Announcement").font(.headline)
                }
                .foregroundColor(.purple)
                .frame(maxWidth: .infinity).padding(.vertical, 16)
                .background(Color.purple.opacity(0.10))
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.purple.opacity(0.30), lineWidth: 1.5))
            }

            // Publish directly
            NavigationLink(
                destination: AnnouncementSuccessScreen(
                    draft:         draft
                )
            ) {
                HStack(spacing: 8) {
                    Image(systemName: "paperplane.fill").font(.system(size: 16, weight: .semibold))
                    Text("Publish Announcement").font(.headline)
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity).padding(.vertical, 16)
                .background(isFormValid
                             ? LinearGradient(colors: [Color.purple, Color.blue],
                                              startPoint: .leading, endPoint: .trailing)
                             : LinearGradient(colors: [Color.gray.opacity(0.4), Color.gray.opacity(0.4)],
                                              startPoint: .leading, endPoint: .trailing))
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.purple.opacity(isFormValid ? 0.30 : 0), radius: 8, x: 0, y: 4)
            }
            .simultaneousGesture(TapGesture().onEnded {
                if !isFormValid { withAnimation { showValidation = true } }
            })
            .disabled(!isFormValid)
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - SCREEN 2 · Preview Announcement Screen
// ─────────────────────────────────────────────────────────────────
struct PreviewAnnouncementScreen: View {
    let draft:         AnnouncementDraft

    @Environment(\.dismiss) private var dismiss

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        VStack(spacing: 0) {
            // ── Header ───────────────────────────────────────────────
            ZStack(alignment: .top) {
                LinearGradient(colors: [Color.purple, Color.blue],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

                VStack(alignment: .leading, spacing: 0) {
                    Color.clear.frame(height: safeTop + 8)
                    HStack(alignment: .center, spacing: 12) {
                        Button(action: { dismiss() }) {
                            ZStack {
                                Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                            }
                        }
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Preview Announcement").font(.title3).bold().foregroundColor(.white)
                            Text("Review before publishing")
                                .font(.caption).foregroundColor(.white.opacity(0.80))
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 18).padding(.bottom, 22)
                }
            }
            .frame(minHeight: safeTop + 92)

            ScrollView {
                VStack(spacing: 24) {
                    // ── Preview label ──────
                    HStack(spacing: 8) {
                        Image(systemName: "eye.fill").foregroundColor(.purple).font(.caption)
                        Text("This is how the announcement will appear to recipients")
                            .font(.caption).foregroundColor(.secondary)
                    }
                    .padding(12)
                    .background(Color.purple.opacity(0.07))
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
                    .padding(.top, 20)

                    // ── Announcement preview card ──
                    announcementPreviewCard
                        .padding(.horizontal, 20)

                    // ── Audience info card ──
                    audienceInfoCard
                        .padding(.horizontal, 20)

                    Divider().padding(.horizontal, 20)

                    // ── Action buttons ──
                    HStack(spacing: 12) {
                        // Edit → pop back to CreateAnnouncementScreen
                        Button(action: { dismiss() }) {
                            HStack(spacing: 6) {
                                Image(systemName: "pencil").font(.system(size: 15, weight: .semibold))
                                Text("Edit").font(.headline)
                            }
                            .foregroundColor(.purple)
                            .frame(maxWidth: .infinity).padding(.vertical, 16)
                            .background(Color.purple.opacity(0.10))
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.purple.opacity(0.30), lineWidth: 1.5))
                        }

                        // Publish → SuccessScreen
                        NavigationLink(destination: AnnouncementSuccessScreen(
                            draft:         draft
                        )) {
                            HStack(spacing: 6) {
                                Image(systemName: "paperplane.fill").font(.system(size: 15, weight: .semibold))
                                Text("Publish").font(.headline)
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity).padding(.vertical, 16)
                            .background(LinearGradient(colors: [Color.purple, Color.blue],
                                                       startPoint: .leading, endPoint: .trailing))
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                            .shadow(color: Color.purple.opacity(0.30), radius: 8, x: 0, y: 4)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 48)
                }
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
    }

    // MARK: Announcement preview card
    private var announcementPreviewCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            // Header row
            HStack(spacing: 10) {
                ZStack {
                    Circle().fill(LinearGradient(colors: [Color.purple, Color.blue],
                                                 startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 40, height: 40)
                    Image(systemName: "megaphone.fill")
                        .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("ClubSphere Admin").font(.subheadline).fontWeight(.bold)
                    Text("Just now").font(.caption).foregroundColor(.secondary)
                }
                Spacer()
                // Priority badge
                HStack(spacing: 4) {
                    Image(systemName: draft.priority.icon)
                        .font(.caption2).foregroundColor(draft.priority.color)
                    Text(draft.priority.label)
                        .font(.caption2).fontWeight(.bold).foregroundColor(draft.priority.color)
                }
                .padding(.horizontal, 8).padding(.vertical, 4)
                .background(draft.priority.color.opacity(0.10))
                .clipShape(Capsule())
            }

            Divider()

            // Title
            Text(draft.title.isEmpty ? "Announcement Title" : draft.title)
                .font(.headline)
                .foregroundColor(draft.title.isEmpty ? .secondary : .primary)

            // Message
            Text(draft.message.isEmpty ? "Your message will appear here…" : draft.message)
                .font(.subheadline)
                .foregroundColor(draft.message.isEmpty ? Color(UIColor.placeholderText) : .secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(18)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.06), radius: 8, x: 0, y: 3)
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.purple.opacity(0.15), lineWidth: 1))
    }

    // MARK: Audience info card
    private var audienceInfoCard: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.blue.opacity(0.12)).frame(width: 40, height: 40)
                Image(systemName: draft.audience.icon)
                    .font(.system(size: 16, weight: .medium)).foregroundColor(.blue)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text("Target Audience").font(.caption).foregroundColor(.secondary)
                Text(draft.audience.rawValue).font(.subheadline).fontWeight(.semibold)
                if draft.audience != .allClubs, !draft.club.isEmpty {
                    Text(draft.club).font(.caption).foregroundColor(.blue)
                }
            }
            Spacer()
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - SCREEN 3 · Announcement Success Screen
// ─────────────────────────────────────────────────────────────────
struct AnnouncementSuccessScreen: View {
    let draft:         AnnouncementDraft
    @Environment(\.dismiss) private var dismiss

    /// Countdown in seconds before auto-redirect (3 → 0)
    @State private var countdown: Int    = 3
    @State private var progress: CGFloat = 1.0   // 1.0 = full bar, drains to 0
    @State private var hasDismissed: Bool = false

    // Timer fires every second
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        VStack(spacing: 0) {
            Spacer()

            // ── Success illustration ──────────────────────────────────
            VStack(spacing: 20) {
                ZStack {
                    Circle().fill(LinearGradient(
                        colors: [Color.purple.opacity(0.15), Color.blue.opacity(0.10)],
                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 130, height: 130)
                    Circle().fill(LinearGradient(
                        colors: [Color.purple, Color.blue],
                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 90, height: 90)
                    .shadow(color: Color.purple.opacity(0.35), radius: 12, x: 0, y: 6)
                    Image(systemName: "paperplane.fill")
                        .font(.system(size: 40, weight: .semibold)).foregroundColor(.white)
                }

                Text("Announcement Sent!")
                    .font(.title2).bold().multilineTextAlignment(.center)

                Text("Your announcement has been delivered to the selected audience.")
                    .font(.subheadline).foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 32)
            }

            Spacer()

            // ── Sent announcement summary card ────────────────────────
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 10) {
                    ZStack {
                        Circle().fill(LinearGradient(colors: [Color.purple, Color.blue],
                                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 38, height: 38)
                        Image(systemName: "megaphone.fill")
                            .font(.system(size: 14, weight: .semibold)).foregroundColor(.white)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(draft.title.isEmpty ? "Announcement" : draft.title)
                            .font(.subheadline).fontWeight(.bold).lineLimit(1)
                        Text("Sent just now").font(.caption).foregroundColor(.secondary)
                    }
                    Spacer()
                    HStack(spacing: 4) {
                        Image(systemName: draft.priority.icon).font(.caption2)
                            .foregroundColor(draft.priority.color)
                        Text(draft.priority.label).font(.caption2).fontWeight(.bold)
                            .foregroundColor(draft.priority.color)
                    }
                    .padding(.horizontal, 8).padding(.vertical, 4)
                    .background(draft.priority.color.opacity(0.10)).clipShape(Capsule())
                }

                if !draft.message.isEmpty {
                    Text(draft.message)
                        .font(.caption).foregroundColor(.secondary)
                        .lineLimit(2).fixedSize(horizontal: false, vertical: true)
                }

                HStack(spacing: 6) {
                    Image(systemName: draft.audience.icon).font(.caption2).foregroundColor(.blue)
                    Text("Sent to: \(draft.audience.rawValue)\(draft.club.isEmpty ? "" : " · \(draft.club)")")
                        .font(.caption).foregroundColor(.blue)
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .shadow(color: .black.opacity(0.06), radius: 8, x: 0, y: 4)
            .padding(.horizontal, 24)

            Spacer()

            // ── Auto-redirect progress bar ────────────────────────────
            VStack(spacing: 6) {
                Text("Returning to dashboard in \(countdown)s…")
                    .font(.caption).foregroundColor(.secondary)

                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color(UIColor.tertiarySystemGroupedBackground))
                            .frame(height: 4)
                        Capsule()
                            .fill(LinearGradient(colors: [Color.purple, Color.blue],
                                                 startPoint: .leading, endPoint: .trailing))
                            .frame(width: geo.size.width * progress, height: 4)
                            .animation(.linear(duration: 1), value: progress)
                    }
                }
                .frame(height: 4)
            }
            .padding(.horizontal, 40)
            .padding(.bottom, 16)

            // ── Manual button (immediate) ─────────────────────────────
            Button(action: {
                hasDismissed = true
                dismiss()
            }) {
                HStack(spacing: 8) {
                    Image(systemName: "house.fill")
                    Text("Return to Dashboard").font(.headline)
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity).padding(.vertical, 16)
                .background(LinearGradient(colors: [Color.purple, Color.blue],
                                           startPoint: .leading, endPoint: .trailing))
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.purple.opacity(0.30), radius: 8, x: 0, y: 4)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 48)
        }
        .background(Color(UIColor.systemGroupedBackground).ignoresSafeArea())
        .navigationBarHidden(true)
        // ── Tick the countdown every second ──────────────────────────
        .onReceive(timer) { _ in
            if countdown > 0 {
                countdown -= 1
                withAnimation(.linear(duration: 1)) {
                    progress = CGFloat(countdown) / 3.0
                }
            }
            
            // If countdown is 0, we attempt dismissal. We don't return early
            // on subsequent ticks to ensure we eventually exit this screen.
            if countdown == 0 && !hasDismissed {
                print("⏲️ [AnnouncementSuccessScreen] Timer hit 0, POSITIVELY dismissing fullScreenCover.")
                hasDismissed = true
                dismiss()
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - Shared Announcement Card (for dashboards)
// Shows in Recent Announcements sections across role dashboards.
// Works alongside the existing AnnouncementCard in PresidentHomeDashboard.
// ─────────────────────────────────────────────────────────────────
struct AdminAnnouncementCard: View {
    let title:   String
    let message: String
    let priority: AnnouncementLevel
    let postedTime: String

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Header row
            HStack(spacing: 8) {
                Image(systemName: "megaphone.fill")
                    .font(.system(size: 14)).foregroundColor(.purple)
                Text(title)
                    .font(.subheadline).fontWeight(.semibold)
                    .foregroundColor(.primary).lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }

            // Message preview
            if !message.isEmpty {
                Text(message)
                    .font(.caption).foregroundColor(.secondary)
                    .lineLimit(2).fixedSize(horizontal: false, vertical: true)
            }

            // Footer: priority + time
            HStack {
                HStack(spacing: 4) {
                    Image(systemName: priority.icon).font(.caption2).foregroundColor(priority.color)
                    Text(priority.label).font(.caption2).fontWeight(.bold).foregroundColor(priority.color)
                }
                .padding(.horizontal, 8).padding(.vertical, 4)
                .background(priority.color.opacity(0.10)).clipShape(Capsule())

                Spacer()

                HStack(spacing: 4) {
                    Image(systemName: "clock").font(.caption2).foregroundColor(.secondary)
                    Text(postedTime).font(.caption).foregroundColor(.secondary)
                }
            }
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - Previews
// ─────────────────────────────────────────────────────────────────
struct AnnouncementWorkflow_Previews: PreviewProvider {
    static var previews: some View {
        PreviewWrapper {
        Group {
            CreateAnnouncementScreen()
                .previewDisplayName("Create Announcement")

            NavigationStack {
                PreviewAnnouncementScreen(
                    draft: AnnouncementDraft(
                        title:    "Reminder: Submit Event Reports",
                        message:  "Please submit your reports by Friday 5 PM.",
                        audience: .allClubs,
                        club:     "",
                        priority: .high
                    )
                )
            }
            .previewDisplayName("Preview Announcement")

            NavigationStack {
                AnnouncementSuccessScreen(
                    draft: AnnouncementDraft(
                        title:    "Reminder: Submit Event Reports",
                        message:  "Please submit your reports by Friday 5 PM.",
                        audience: .allClubs,
                        club:     "",
                        priority: .high
                    )
                )
            }
            .previewDisplayName("Announcement Success")
        }
    
        }
    }
}
