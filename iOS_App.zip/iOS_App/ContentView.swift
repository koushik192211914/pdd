//
//  ContentView.swift
//  CLUB ANALYTICSs
//
//  Created by SAIL on 06/03/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}

#Preview {
    PreviewWrapper {
    ContentView()

    }
}
