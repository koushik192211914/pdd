//
//  AuthService.swift
//  CLUB ANALYTICSs
//
//  POST /auth/login  — POST /auth/signup
//

import Foundation

final class AuthService {
    static let shared = AuthService()
    private init() {}

    func login(email: String, password: String) async throws -> LoginResponse {
        let request = LoginRequest(email: email, password: password)
        return try await APIClient.shared.request("/auth/login", method: "POST", body: request)
    }

    func signup(name: String, email: String, password: String) async throws -> MessageResponse {
        let request = SignupRequest(name: name, email: email, password: password)
        return try await APIClient.shared.request("/auth/signup", method: "POST", body: request)
    }

    func getMe() async throws -> UserResponseModel {
        return try await APIClient.shared.request("/users/me")
    }

    func updateProfile(name: String) async throws -> UserResponseModel {
        let request = UserUpdateRequest(name: name, email: nil)
        return try await APIClient.shared.request("/users/me", method: "PUT", body: request)
    }
}
