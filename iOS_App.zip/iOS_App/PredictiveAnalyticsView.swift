import SwiftUI

// MARK: - Predictive Analytics View
struct PredictiveAnalyticsView: View {
    @EnvironmentObject private var authManager: AuthManager
    @State private var isLoading = true
    @State private var predictions: PredictiveAnalyticsResponse?
    @State private var errorMessage: String?

    var body: some View {
        ScrollView(showsIndicators: false) {
            if isLoading {
                VStack(spacing: 16) {
                    ProgressView().scaleEffect(1.3)
                    Text("Loading AI Predictions…")
                        .font(.subheadline).foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.top, 60)
            } else if let err = errorMessage {
                VStack(spacing: 12) {
                    Image(systemName: "exclamationmark.triangle.fill").font(.system(size: 40)).foregroundColor(.red)
                    Text("Failed to Load Data").font(.title3).fontWeight(.semibold)
                    Text(err).font(.caption).foregroundColor(.secondary).multilineTextAlignment(.center)
                }
                .padding(.top, 60).padding(.horizontal)
            } else if let data = predictions {
                VStack(spacing: 24) {

                    // ── Predicted Event Participation ────────────────────────────
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 8) {
                            Image(systemName: "chart.line.uptrend.xyaxis").foregroundColor(.blue)
                            Text("Predicted Participation").font(.title3).bold()
                        }
                        .padding(.horizontal)

                        if data.event_predictions.isEmpty {
                            Text("No upcoming events.").font(.subheadline).foregroundColor(.secondary).padding(.horizontal)
                        } else {
                            ForEach(data.event_predictions) { event in
                                HStack(spacing: 14) {
                                    Text(event.event_name)
                                        .font(.subheadline).fontWeight(.medium)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                    GeometryReader { geo in
                                        ZStack(alignment: .leading) {
                                            RoundedRectangle(cornerRadius: 5).fill(Color(UIColor.systemFill))
                                                .frame(height: 8)
                                            RoundedRectangle(cornerRadius: 5).fill(Color.purple)
                                                .frame(width: geo.size.width * CGFloat(event.predicted_participation_pct) / 100, height: 8)
                                        }
                                    }
                                    .frame(width: 90, height: 8)
                                    Text("\(event.predicted_participation_pct)%")
                                        .font(.caption).fontWeight(.bold).foregroundColor(.purple)
                                        .frame(width: 36, alignment: .trailing)
                                }
                                .padding(.horizontal, 20)
                            }
                        }
                    }
                    .padding(.top, 16)

                    Divider().padding(.horizontal)

                    // ── Members Likely to Drop Engagement ───────────────────────
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 8) {
                            Image(systemName: "person.fill.xmark").foregroundColor(.red)
                            Text("At-Risk Members").font(.title3).bold()
                        }
                        .padding(.horizontal)

                        if data.at_risk_members.isEmpty {
                            Text("All members are engaged!").font(.subheadline).foregroundColor(.secondary).padding(.horizontal)
                        } else {
                            ForEach(data.at_risk_members) { member in
                                HStack(spacing: 14) {
                                    ZStack {
                                        Circle().fill(Color.red.opacity(0.12)).frame(width: 40, height: 40)
                                        Text(member.initials).font(.subheadline).fontWeight(.semibold).foregroundColor(.red)
                                    }
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(member.name).font(.subheadline).fontWeight(.semibold)
                                        Text("Predicted drop to \(member.predicted_engagement_score)% engagement")
                                            .font(.caption).foregroundColor(.secondary)
                                    }
                                    Spacer()
                                    Text("⚠️").font(.title3)
                                }
                                .padding(14)
                                .background(Color(UIColor.secondarySystemGroupedBackground))
                                .cornerRadius(14)
                                .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
                                .padding(.horizontal)
                            }
                        }
                    }

                    Divider().padding(.horizontal)

                    // ── Future Engagement Trend ──────────────────────────────────
                    VStack(alignment: .leading, spacing: 14) {
                        HStack(spacing: 8) {
                            Image(systemName: "waveform.path.ecg").foregroundColor(.purple)
                            Text("4-Week Forecast").font(.title3).bold()
                        }
                        .padding(.horizontal)

                        HStack(alignment: .bottom, spacing: 10) {
                            ForEach(data.future_trend) { trend in
                                VStack(spacing: 6) {
                                    RoundedRectangle(cornerRadius: 6)
                                        .fill(
                                            LinearGradient(
                                                colors: [.purple, .blue],
                                                startPoint: .top, endPoint: .bottom
                                            )
                                        )
                                        .frame(height: CGFloat(trend.trend_value) * 100)
                                    Text(trend.week_label).font(.caption2).foregroundColor(.secondary)
                                }
                                .frame(maxWidth: .infinity)
                            }
                        }
                        .frame(height: 120)
                        .padding(.horizontal, 24)

                        Text("Engagement is projected to grow steadily over the next 4 weeks if current event scheduling is maintained.")
                            .font(.caption).foregroundColor(.secondary)
                            .padding(.horizontal)
                    }

                }
                .padding(.bottom, 40)
            }
        }
        .background(Color(UIColor.systemGroupedBackground))
        .navigationTitle("Predictive Analytics")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            await fetchData()
        }
    }

    @MainActor
    private func fetchData() async {
        guard let clubId = authManager.clubId else {
            isLoading = false
            errorMessage = "No club assigned."
            return
        }
        isLoading = true
        errorMessage = nil
        do {
            let data = try await AnalyticsService.shared.getPredictiveAnalytics(clubId: clubId)
            self.predictions = data
        } catch {
            self.errorMessage = error.localizedDescription
        }
        isLoading = false
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
    NavigationStack {
        PredictiveAnalyticsView()
    }

    }
}
