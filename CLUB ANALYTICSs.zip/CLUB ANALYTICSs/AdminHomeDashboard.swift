import SwiftUI

// MARK: - Admin Home Dashboard
struct AdminHomeDashboard: View {
    @StateObject private var viewModel = AdminHomeViewModel()
    
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // 1️⃣ HEADER + PLATFORM OVERVIEW CARDS
                AdminDashboardHeader(viewModel: viewModel)

                VStack(spacing: 32) {
                    // 2️⃣ QUICK ACTIONS
                    AdminQuickActionsSection()

                    // 3️⃣ RECENT ACTIVITY
                    AdminRecentActivitySection(viewModel: viewModel)
                }
                .padding(.top, 24)
                .padding(.bottom, 100)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .task {
            await viewModel.fetchData()
        }
    }
}

// MARK: - Admin Dashboard Header
struct AdminDashboardHeader: View {
    @ObservedObject var viewModel: AdminHomeViewModel

    @State private var showNotificationPanel = false
    @EnvironmentObject private var store: AttendanceNotificationStore

    private var safeTop: CGFloat {
        UIApplication.shared
            .connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?
            .safeAreaInsets.top ?? 50
    }

    var body: some View {
        ZStack(alignment: .top) {
            // ── Gradient background ───────────────────────────────────────────
            LinearGradient(
                colors: [Color.purple, Color.blue],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)

            // ── Content stack ─────────────────────────────────────────────────
            VStack(alignment: .leading, spacing: 0) {

                // Safe-area spacer
                Color.clear.frame(height: safeTop + 16)

                // Row 1 – Title + Bell
                HStack(alignment: .center) {
                    Text("Admin Dashboard")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)

                    Spacer()

                    Button(action: { showNotificationPanel = true }) {
                        ZStack {
                            Circle()
                                .fill(Color.white.opacity(0.20))
                                .frame(width: 44, height: 44)
                            Image(systemName: "bell.badge.fill")
                                .font(.system(size: 20))
                                .foregroundColor(.white)
                        }
                    }
                    .sheet(isPresented: $showNotificationPanel) {
                        NavigationStack {
                            NotificationsView(role: .admin)
                                .environmentObject(store)
                        }
                    }
                }
                .padding(.horizontal, 18)

                // Row 2 – Subtitle
                Text("ClubSphere Platform Management")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.white.opacity(0.80))
                    .padding(.horizontal, 18)
                    .padding(.top, 4)
                    .padding(.bottom, 20)

                // Row 3 – Platform Overview Cards (2×2)
                LazyVGrid(columns: [
                    GridItem(.flexible(), spacing: 16),
                    GridItem(.flexible(), spacing: 16)
                ], spacing: 16) {
                    StatCardView(title: "Total Clubs",     value: "\(viewModel.summary?.total_clubs ?? 0)",        icon: "building.2.fill")
                    StatCardView(title: "Total Members",   value: "\(viewModel.summary?.total_members ?? 0)",      icon: "person.3.fill")
                    StatCardView(title: "Active Events",   value: "\(viewModel.summary?.active_events ?? 0)",      icon: "calendar.badge.checkmark")
                    StatCardView(title: "Engagement Rate", value: "\(Int(viewModel.summary?.engagement_rate ?? 0))%",   icon: "chart.line.uptrend.xyaxis")
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 26)
            }
        }
        .frame(height: safeTop + 280)
    }
}

// MARK: - Admin Quick Actions Section
struct AdminQuickActionsSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Quick Actions")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.horizontal)

            LazyVGrid(columns: [
                GridItem(.flexible(), spacing: 16),
                GridItem(.flexible(), spacing: 16)
            ], spacing: 16) {

                QuickActionButton(
                    title: "Create Club",
                    icon: "building.2.crop.circle.fill",
                    color: .purple,
                    destination: AnyView(CreateClubScreen())
                )

                QuickActionButton(
                    title: "Create Event",
                    icon: "plus.circle.fill",
                    color: .blue,
                    destination: AnyView(EventCreationScreen())
                )

                QuickActionButton(
                    title: "Manage Users",
                    icon: "person.2.badge.gearshape.fill",
                    color: .orange,
                    destination: AnyView(UserManagementScreen())
                )

                QuickActionButton(
                    title: "Send Announcement",
                    icon: "megaphone.fill",
                    color: .green,
                    destination: AnyView(AdminAnnouncementScreen())
                )
            }
            .padding(.horizontal)
        }
    }
}

// MARK: - Recent Activity Section
struct AdminRecentActivitySection: View {
    @ObservedObject var viewModel: AdminHomeViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionHeaderRow(title: "Recent Activity", showViewAll: true)

            if let recentEvents = viewModel.dashboard?.recent_events, !recentEvents.isEmpty {
                VStack(spacing: 12) {
                    ForEach(recentEvents) { event in
                        HStack(spacing: 14) {
                            ZStack {
                                Circle().fill(Color.blue.opacity(0.12)).frame(width: 44, height: 44)
                                Image(systemName: "calendar").foregroundColor(.blue)
                            }
                            VStack(alignment: .leading, spacing: 3) {
                                Text(event.title).font(.subheadline).fontWeight(.semibold)
                                Text(event.description ?? "New event created").font(.caption).foregroundColor(.secondary)
                            }
                            Spacer()
                            Text("Recent").font(.caption2).foregroundColor(.secondary)
                        }
                        .padding(12)
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(14)
                        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
                    }
                }
                .padding(.horizontal)
            } else {
                VStack(spacing: 20) {
                    Image(systemName: "clock.badge.exclamationmark")
                        .font(.system(size: 40))
                        .foregroundColor(.secondary.opacity(0.5))
                    
                    Text("No Recent Events")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 40)
                .background(Color(UIColor.secondarySystemGroupedBackground))
                .cornerRadius(16)
                .padding(.horizontal)
            }
            
            /* OLD MOCK DATA REMOVED
            VStack(spacing: 12) {
                ForEach(activities) { item in
                    AdminActivityRow(item: item)
                }
            }
            .padding(.horizontal)
            */
        }
    }
}

// MARK: - Activity Model
struct AdminActivityItem: Identifiable {
    let id = UUID()
    let icon:      String
    let iconColor: Color
    let title:     String
    let detail:    String
    let time:      String
}

// MARK: - Activity Row
struct AdminActivityRow: View {
    let item: AdminActivityItem

    var body: some View {
        HStack(spacing: 14) {
            // Icon badge
            ZStack {
                Circle()
                    .fill(item.iconColor.opacity(0.12))
                    .frame(width: 44, height: 44)
                Image(systemName: item.icon)
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(item.iconColor)
            }

            // Text
            VStack(alignment: .leading, spacing: 3) {
                Text(item.title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                Text(item.detail)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }

            Spacer(minLength: 0)

            // Time
            Text(item.time)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .padding(12)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Preview
struct AdminHomeDashboard_Previews: PreviewProvider {
    static var previews: some View {
        PreviewWrapper {
        NavigationStack {
            AdminHomeDashboard()
        }
        .environmentObject(AttendanceNotificationStore())
        .previewDisplayName("Admin Dashboard")
    
        }
    }
}
