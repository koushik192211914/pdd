import SwiftUI

// MARK: - Notification Settings View
struct NotificationSettingsView: View {
    @AppStorage("notif_events")        private var eventNotifications   = true
    @AppStorage("notif_announcements") private var announcements        = true
    @AppStorage("notif_attendance")    private var attendanceUpdates    = true
    @AppStorage("notif_substitutes")   private var substituteAlerts     = true

    var body: some View {
        List {
            Section {
                NotifToggleRow(
                    icon: "calendar.badge.exclamationmark",
                    iconColor: .blue,
                    title: "Event Notifications",
                    subtitle: "Alerts for upcoming and updated events",
                    isOn: $eventNotifications
                )

                NotifToggleRow(
                    icon: "megaphone.fill",
                    iconColor: .orange,
                    title: "Announcement Alerts",
                    subtitle: "Club-wide messages and announcements",
                    isOn: $announcements
                )

                NotifToggleRow(
                    icon: "checkmark.circle.fill",
                    iconColor: .green,
                    title: "Attendance Updates",
                    subtitle: "Confirmations and absence notifications",
                    isOn: $attendanceUpdates
                )

                NotifToggleRow(
                    icon: "arrow.triangle.2.circlepath.circle.fill",
                    iconColor: .purple,
                    title: "Substitute Alerts",
                    subtitle: "When a participant is replaced or substituted",
                    isOn: $substituteAlerts
                )
            } header: {
                Text("Notification Preferences")
            } footer: {
                Text("You can change these settings anytime. Turning off a category will stop push notifications for that type.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .navigationTitle("Notification Settings")
        .navigationBarTitleDisplayMode(.inline)
    }
}


// MARK: - Reusable toggle row
private struct NotifToggleRow: View {
    let icon:     String
    let iconColor: Color
    let title:    String
    let subtitle: String
    @Binding var isOn: Bool

    var body: some View {
        Toggle(isOn: $isOn) {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(iconColor)
                        .frame(width: 32, height: 32)
                    Image(systemName: icon)
                        .font(.system(size: 15, weight: .medium))
                        .foregroundColor(.white)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.body)
                    Text(subtitle)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
        .tint(.purple)
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
    NavigationStack {
        NotificationSettingsView()
    }

    }
}
