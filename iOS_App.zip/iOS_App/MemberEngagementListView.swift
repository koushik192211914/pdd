import SwiftUI

// MARK: - Member Engagement Detail Model
struct MemberEngagementDetail: Identifiable {
    let id: Int
    let name: String
    let email: String
    let role: String
    var engagement: StudentEngagementResponse?
    var isLoadingStats: Bool = true

    var attendanceRate: Int {
        guard let e = engagement else { return 0 }
        guard e.events_registered > 0 else { return 0 }
        return Int((Double(e.events_attended) / Double(e.events_registered)) * 100)
    }

    var engagementScore: Int { engagement?.engagement_score ?? 0 }
    var eventsAttended: Int  { engagement?.events_attended ?? 0 }
    var clubAttendance: Int  { engagement?.club_attendance ?? 0 }

    var engagementColor: Color {
        switch engagementScore {
        case 80...: return .green
        case 50..<80: return .orange
        default: return .red
        }
    }

    var attendanceColor: Color {
        switch attendanceRate {
        case 80...: return .green
        case 50..<80: return .orange
        default: return .red
        }
    }

    var engagementLabel: String {
        switch engagementScore {
        case 80...: return "High"
        case 50..<80: return "Medium"
        default: return "Low"
        }
    }
}

// MARK: - Member Engagement List View
struct MemberEngagementListView: View {
    @EnvironmentObject private var authManager: AuthManager

    @State private var members: [MemberEngagementDetail] = []
    @State private var isLoading = true
    @State private var errorMessage: String?
    @State private var searchText = ""

    private var filtered: [MemberEngagementDetail] {
        if searchText.isEmpty { return members }
        return members.filter {
            $0.name.localizedCaseInsensitiveContains(searchText) ||
            $0.role.localizedCaseInsensitiveContains(searchText)
        }
    }

    // Summary stats
    private var avgEngagement: Int {
        let loaded = members.filter { !$0.isLoadingStats }
        guard !loaded.isEmpty else { return 0 }
        return loaded.map { $0.engagementScore }.reduce(0, +) / loaded.count
    }

    private var avgAttendance: Int {
        let loaded = members.filter { !$0.isLoadingStats }
        guard !loaded.isEmpty else { return 0 }
        return loaded.map { $0.attendanceRate }.reduce(0, +) / loaded.count
    }

    private var highEngagers: Int {
        members.filter { $0.engagementScore >= 80 }.count
    }

    private var lowEngagers: Int {
        members.filter { !$0.isLoadingStats && $0.engagementScore < 50 }.count
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 20) {

                // ── Summary Cards ────────────────────────────────────
                if !members.isEmpty {
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 12),
                                        GridItem(.flexible(), spacing: 12)], spacing: 12) {
                        EngagementStatCard(
                            icon: "flame.fill", color: .purple,
                            label: "Avg Engagement",
                            value: "\(avgEngagement)%"
                        )
                        EngagementStatCard(
                            icon: "clock.fill", color: .blue,
                            label: "Avg Attendance",
                            value: "\(avgAttendance)%"
                        )
                        EngagementStatCard(
                            icon: "checkmark.circle.fill", color: .green,
                            label: "High Engagers",
                            value: "\(highEngagers)"
                        )
                        EngagementStatCard(
                            icon: "exclamationmark.triangle.fill", color: .orange,
                            label: "At Risk Members",
                            value: "\(lowEngagers)"
                        )
                    }
                    .padding(.horizontal)
                }

                // ── Search Bar ───────────────────────────────────────
                HStack(spacing: 10) {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.secondary)
                    TextField("Search members…", text: $searchText)
                        .font(.subheadline)
                }
                .padding(.horizontal, 14).padding(.vertical, 10)
                .background(Color(UIColor.secondarySystemGroupedBackground))
                .cornerRadius(12)
                .padding(.horizontal)

                // ── Content ──────────────────────────────────────────
                if isLoading {
                    VStack(spacing: 12) {
                        ProgressView().scaleEffect(1.2)
                        Text("Loading member analytics…")
                            .font(.subheadline).foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 60)

                } else if let err = errorMessage {
                    VStack(spacing: 12) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.system(size: 36)).foregroundColor(.orange)
                        Text(err)
                            .font(.subheadline).foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 40).padding(.horizontal)

                } else if filtered.isEmpty {
                    VStack(spacing: 10) {
                        Image(systemName: "person.3").font(.system(size: 44)).foregroundColor(.secondary)
                        Text("No members found.").foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 40)

                } else {
                    VStack(spacing: 12) {
                        ForEach(filtered) { member in
                            MemberEngagementCard(member: member)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 40)
                }
            }
            .padding(.top, 16)
        }
        .background(Color(UIColor.systemGroupedBackground))
        .navigationTitle("Student Engagement")
        .navigationBarTitleDisplayMode(.large)
        .task { await loadMembersWithEngagement() }
    }

    // MARK: - Data Loading
    private func loadMembersWithEngagement() async {
        guard let clubId = authManager.clubId else {
            errorMessage = "No club assigned."
            isLoading = false
            return
        }

        isLoading = true
        do {
            let clubMembers = try await ClubService.shared.getMembers(clubId: clubId)
            // Only include Students — exclude leadership roles
            let studentRoles: Set<String> = ["Student", "student"]
            let studentsOnly = clubMembers.filter { studentRoles.contains($0.role) }
            members = studentsOnly.map {
                MemberEngagementDetail(id: $0.id, name: $0.name, email: $0.email, role: $0.role)
            }
            isLoading = false

            // Fetch engagement per member concurrently
            await withTaskGroup(of: (Int, StudentEngagementResponse?).self) { group in
                for member in members {
                    group.addTask {
                        let engagement = try? await AnalyticsService.shared.getStudentEngagement(studentId: member.id)
                        return (member.id, engagement)
                    }
                }
                for await (memberId, engagement) in group {
                    if let idx = members.firstIndex(where: { $0.id == memberId }) {
                        members[idx].engagement = engagement
                        members[idx].isLoadingStats = false
                    }
                }
            }
        } catch {
            errorMessage = "Failed to load members: \(error.localizedDescription)"
            isLoading = false
        }
    }
}

// MARK: - Member Engagement Card
struct MemberEngagementCard: View {
    let member: MemberEngagementDetail

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            // ── Top Row: Avatar + Name + Badge ─────────────────────────
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(member.engagementColor.opacity(0.15))
                        .frame(width: 48, height: 48)
                    Text(String(member.name.prefix(1)).uppercased())
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(member.engagementColor)
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(member.name)
                        .font(.subheadline).fontWeight(.semibold)
                    Text(member.email)
                        .font(.caption).foregroundColor(.secondary)
                        .lineLimit(1)
                }

                Spacer()

                if member.isLoadingStats {
                    ProgressView().scaleEffect(0.8)
                } else {
                    VStack(alignment: .trailing, spacing: 3) {
                        Text(member.role)
                            .font(.caption2).fontWeight(.bold)
                            .foregroundColor(.purple)
                            .padding(.horizontal, 8).padding(.vertical, 3)
                            .background(Color.purple.opacity(0.10))
                            .clipShape(Capsule())
                        Text(member.engagementLabel)
                            .font(.caption2).fontWeight(.bold)
                            .foregroundColor(member.engagementColor)
                            .padding(.horizontal, 8).padding(.vertical, 3)
                            .background(member.engagementColor.opacity(0.10))
                            .clipShape(Capsule())
                    }
                }
            }

            if member.isLoadingStats {
                HStack(spacing: 6) {
                    ProgressView().scaleEffect(0.7)
                    Text("Loading stats…")
                        .font(.caption).foregroundColor(.secondary)
                }
            } else {
                // ── Engagement Score Bar ──────────────────────────────
                VStack(alignment: .leading, spacing: 5) {
                    HStack {
                        Label("Engagement Score", systemImage: "flame.fill")
                            .font(.caption2).fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        Spacer()
                        Text("\(member.engagementScore)%")
                            .font(.caption).fontWeight(.bold)
                            .foregroundColor(member.engagementColor)
                    }
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            Capsule()
                                .fill(Color.gray.opacity(0.10))
                                .frame(height: 7)
                            Capsule()
                                .fill(LinearGradient(
                                    colors: [member.engagementColor.opacity(0.8), member.engagementColor],
                                    startPoint: .leading, endPoint: .trailing))
                                .frame(width: geo.size.width * (CGFloat(min(member.engagementScore, 100)) / 100.0), height: 7)
                        }
                    }
                    .frame(height: 7)
                }

                // ── Attendance Rate Bar ───────────────────────────────
                VStack(alignment: .leading, spacing: 5) {
                    HStack {
                        Label("Attendance Rate", systemImage: "clock.fill")
                            .font(.caption2).fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        Spacer()
                        Text("\(member.attendanceRate)%")
                            .font(.caption).fontWeight(.bold)
                            .foregroundColor(member.attendanceColor)
                    }
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            Capsule()
                                .fill(Color.gray.opacity(0.10))
                                .frame(height: 7)
                            Capsule()
                                .fill(LinearGradient(
                                    colors: [member.attendanceColor.opacity(0.8), member.attendanceColor],
                                    startPoint: .leading, endPoint: .trailing))
                                .frame(width: geo.size.width * (CGFloat(min(member.attendanceRate, 100)) / 100.0), height: 7)
                        }
                    }
                    .frame(height: 7)
                }

                // ── Mini Stats Row ────────────────────────────────────
                HStack(spacing: 0) {
                    MiniStatItem(label: "Events Attended", value: "\(member.eventsAttended)", color: .blue)
                    Divider().frame(height: 28)
                    MiniStatItem(label: "Club Sessions", value: "\(member.clubAttendance)", color: .teal)
                    Divider().frame(height: 28)
                    MiniStatItem(label: "Score", value: "\(member.engagementScore)", color: member.engagementColor)
                }
                .background(Color(UIColor.tertiarySystemGroupedBackground))
                .cornerRadius(10)
            }
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 3)
    }
}

// MARK: - Helper Views
private struct MiniStatItem: View {
    let label: String
    let value: String
    let color: Color

    var body: some View {
        VStack(spacing: 2) {
            Text(value)
                .font(.subheadline).fontWeight(.bold)
                .foregroundColor(color)
            Text(label)
                .font(.caption2).foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
    }
}

private struct EngagementStatCard: View {
    let icon: String
    let color: Color
    let label: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(color.opacity(0.12))
                    .frame(width: 38, height: 38)
                Image(systemName: icon)
                    .font(.system(size: 16)).foregroundColor(color)
            }
            Text(value)
                .font(.title3).fontWeight(.bold)
            Text(label)
                .font(.caption).foregroundColor(.secondary).lineLimit(2)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.04), radius: 5, x: 0, y: 2)
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
        MemberEngagementListView()
            .environmentObject(AuthManager.shared)
    }
}
