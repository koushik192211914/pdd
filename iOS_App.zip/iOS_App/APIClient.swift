//
//  APIClient.swift
//  CLUB ANALYTICSs
//

import Foundation

enum APIError: Error, LocalizedError {
    case invalidURL
    case noData
    case decodingError
    case unauthorized
    case networkError(Error)
    case serverError(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL:          return "Invalid URL configuration."
        case .noData:              return "No valid response from server."
        case .decodingError:        return "Failed to decode server response."
        case .unauthorized:         return "Unauthorized access. Please log in again."
        case .networkError(let e):  return "Network error: \(e.localizedDescription)"
        case .serverError(let msg): return "Server error: \(msg)"
        }
    }
}

final class APIClient {
    static let shared = APIClient()
    
    // Using 127.0.0.1 often resolves IPv6 vs IPv4 issues on local dev
    public let baseURL = "http://127.0.0.1:8000" // Unified Python Backend
    
    private init() {}

    func upload<T: Decodable>(_ endpoint: String, data: Data, fileName: String, mimeType: String) async throws -> T {
        let cleanEndpoint = endpoint.hasPrefix("/") ? String(endpoint.dropFirst()) : endpoint
        let fullURLString = "\(baseURL)/\(cleanEndpoint)"
        
        guard let url = URL(string: fullURLString) else { throw APIError.invalidURL }
        
        let boundary = "Boundary-\(UUID().uuidString)"
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        if let token = UserDefaults.standard.string(forKey: "cs_token") {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(fileName)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: \(mimeType)\r\n\r\n".data(using: .utf8)!)
        body.append(data)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        
        let (responseData, response) = try await URLSession.shared.upload(for: request, from: body)
        
        guard let httpResponse = response as? HTTPURLResponse else { throw APIError.noData }
        if httpResponse.statusCode == 401 { throw APIError.unauthorized }
        guard (200...299).contains(httpResponse.statusCode) else {
            let errorMsg = String(data: responseData, encoding: .utf8) ?? "Upload failed"
            throw APIError.serverError(errorMsg)
        }
        
        return try JSONDecoder().decode(T.self, from: responseData)
    }
    
    func request<T: Decodable>(_ endpoint: String, method: String = "GET") async throws -> T {
        try await request(endpoint, method: method, body: nil as String?)
    }

    func request<T: Decodable, B: Encodable>(_ endpoint: String, method: String = "GET", body: B? = nil) async throws -> T {
        // Sanitize endpoint to prevent double slashes
        let cleanEndpoint = endpoint.hasPrefix("/") ? String(endpoint.dropFirst()) : endpoint
        let fullURLString = "\(baseURL)/\(cleanEndpoint)"
        
        guard let url = URL(string: fullURLString) else {
            print("❌ [APIClient] Invalid URL: \(fullURLString)")
            throw APIError.invalidURL
        }
        
        print("🚀 [APIClient] \(method) \(url.absoluteString)")
        
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        if let token = UserDefaults.standard.string(forKey: "cs_token") {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        if let body = body {
            do {
                request.httpBody = try JSONEncoder().encode(body)
            } catch {
                print("❌ [APIClient] Encoding error: \(error)")
                throw error
            }
        }
        
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            print("❌ [APIClient] Network error for \(url.lastPathComponent): \(error)")
            throw APIError.networkError(error)
        }
        
        guard let httpResponse = response as? HTTPURLResponse else {
            print("❌ [APIClient] Non-HTTP response: \(type(of: response))")
            throw APIError.noData
        }
        
        print("📥 [APIClient] Response: \(httpResponse.statusCode) for \(url.lastPathComponent)")
        
        if httpResponse.statusCode == 401 {
            throw APIError.unauthorized
        }
        
        guard (200...299).contains(httpResponse.statusCode) else {
            let errorMsg = String(data: data, encoding: .utf8) ?? "Unknown server error"
            print("❌ [APIClient] Server returned \(httpResponse.statusCode): \(errorMsg)")
            throw APIError.serverError(errorMsg)
        }
        
        do {
            let decoder = JSONDecoder()
            return try decoder.decode(T.self, from: data)
        } catch {
            print("❌ [APIClient] Decoding error: \(error)")
            // Log the raw JSON if decoding fails for debugging
            if let rawJSON = String(data: data, encoding: .utf8) {
                print("📄 [APIClient] Raw JSON: \(rawJSON)")
            }
            throw APIError.decodingError
        }
    }
}
