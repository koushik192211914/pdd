//
//  JoinRequestService.swift
//  CLUB ANALYTICSs
//
//  POST /club-requests/send
//  GET  /club-requests/{club_id}
//  POST /club-requests/approve/{id}
//  POST /club-requests/reject/{id}
//

import Foundation

final class JoinRequestService {
    static let shared = JoinRequestService()
    private init() {}

    func sendRequest(studentId: Int, clubId: Int) async throws -> MessageResponse {
        let request = JoinRequestCreate(student_id: studentId, club_id: clubId)
        return try await APIClient.shared.request("/club-requests/send", method: "POST", body: request)
    }

    func getPendingRequests(clubId: Int) async throws -> [JoinRequestResponse] {
        return try await APIClient.shared.request("/club-requests/\(clubId)")
    }

    func approveRequest(id: Int) async throws -> MessageResponse {
        return try await APIClient.shared.request("/club-requests/approve/\(id)", method: "POST")
    }

    func rejectRequest(id: Int) async throws -> MessageResponse {
        return try await APIClient.shared.request("/club-requests/reject/\(id)", method: "POST")
    }
}
