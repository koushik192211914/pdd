"""
OTP-based password reset via Gmail SMTP.

routes:
  POST /auth/forgot-password   – send 6-digit OTP to email
  POST /auth/verify-otp        – verify OTP (returns token)
  POST /auth/reset-password    – set new password after OTP verified
"""

import random, string
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr
from sqlalchemy.orm import Session

from database import get_db
import models

router = APIRouter(prefix="/auth", tags=["OTP Auth"])

# ── Pydantic Schemas ──────────────────────────────────────────────────────────

class ForgotPasswordRequest(BaseModel):
    email: str

class VerifyOTPRequest(BaseModel):
    email: str
    code: str

class ResetPasswordRequest(BaseModel):
    email: str
    code: str
    new_password: str

class OTPResponse(BaseModel):
    message: str

# ── Helper: Send Gmail ────────────────────────────────────────────────────────

def _send_otp_email(to_email: str, code: str):
    """Send OTP via Gmail SMTP using App Password. Falls back to console log if unconfigured."""
    import smtplib, os
    from email.mime.text import MIMEText

    sender   = os.getenv("GMAIL_ADDRESS", "")
    password = os.getenv("GMAIL_APP_PASSWORD", "")

    # ── Dev fallback if credentials are missing ───────────────────────────────
    if not sender or not password:
        print("\n" + "="*50)
        print("🔐 [DEV OTP FALLBACK]")
        print(f"  Email : {to_email}")
        print(f"  Code  : {code}")
        print("="*50 + "\n")
        print("💡 TIP: Set GMAIL_ADDRESS and GMAIL_APP_PASSWORD in your .env file to send real emails.")
        return

    # ── Build email message ───────────────────────────────────────────────────
    body = f"""Hello,

Your ClubSphere password reset OTP is:

  {code}

This code expires in 10 minutes. Do NOT share it with anyone.

– ClubSphere Team
"""
    msg = MIMEText(body)
    msg["Subject"] = "ClubSphere – Your OTP Code"
    msg["From"]    = sender
    msg["To"]      = to_email

    # ── Send via Gmail SMTP (explicit steps for reliability) ──────────────────
    try:
        server = smtplib.SMTP("smtp.gmail.com", 587, timeout=10)
        server.ehlo()           # Step 1: identify client
        server.starttls()       # Step 2: upgrade to TLS
        server.ehlo()           # Step 3: re-identify after TLS upgrade
        server.login(sender, password)
        server.sendmail(sender, to_email, msg.as_string())
        server.quit()
        print(f"✅ [OTP SUCCESS] Email sent to {to_email}")
    except Exception as e:
        print(f"⚠️  [OTP FATAL ERROR] SMTP dispatch failed: {e}")
        # Always print OTP to console as fallback so flow is never fully broken
        print(f"🔐 [DEV FALLBACK]  To: {to_email}  Code: {code}")
        print("💡 TIP: Ensure GMAIL_ADDRESS and GMAIL_APP_PASSWORD are correct in your .env file.")

# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/forgot-password", response_model=OTPResponse)
def forgot_password(payload: ForgotPasswordRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == payload.email).first()
    if not user:
        # Don't reveal whether email exists for security
        return OTPResponse(message="If that email is registered, an OTP has been sent.")

    # Generate 6-digit OTP
    code = "".join(random.choices(string.digits, k=6))
    expires_at = datetime.utcnow() + timedelta(minutes=10)

    # Invalidate old OTPs for this email
    db.query(models.OTPCode).filter(models.OTPCode.email == payload.email).delete()

    otp = models.OTPCode(email=payload.email, code=code, expires_at=expires_at)
    db.add(otp)
    db.commit()

    _send_otp_email(payload.email, code)
    return OTPResponse(message="If that email is registered, an OTP has been sent.")


@router.post("/verify-otp", response_model=OTPResponse)
def verify_otp(payload: VerifyOTPRequest, db: Session = Depends(get_db)):
    otp = db.query(models.OTPCode).filter(
        models.OTPCode.email == payload.email,
        models.OTPCode.code == payload.code,
        models.OTPCode.used == 0
    ).first()

    if not otp:
        raise HTTPException(status_code=400, detail="Invalid or expired OTP.")
    if datetime.utcnow() > otp.expires_at:
        raise HTTPException(status_code=400, detail="OTP has expired. Please request a new one.")

    return OTPResponse(message="OTP verified. You may now reset your password.")


@router.post("/reset-password", response_model=OTPResponse)
def reset_password(payload: ResetPasswordRequest, db: Session = Depends(get_db)):
    otp = db.query(models.OTPCode).filter(
        models.OTPCode.email == payload.email,
        models.OTPCode.code == payload.code,
        models.OTPCode.used == 0
    ).first()

    if not otp:
        raise HTTPException(status_code=400, detail="Invalid or expired OTP.")
    if datetime.utcnow() > otp.expires_at:
        raise HTTPException(status_code=400, detail="OTP has expired. Please request a new one.")

    if len(payload.new_password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters.")

    user = db.query(models.User).filter(models.User.email == payload.email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")

    from passlib.context import CryptContext
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    user.password_hash = pwd_context.hash(payload.new_password)

    # Mark OTP as used
    otp.used = 1
    db.commit()

    return OTPResponse(message="Password reset successfully. You may now log in.")
