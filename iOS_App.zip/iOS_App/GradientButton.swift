//
//  GradientButton.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Reusable Gradient Button
//

import SwiftUI

struct GradientButton: View {
    let title: String
    let action: () -> Void
    var icon: String? = nil
    var showChevron: Bool = false
    
    init(_ title: String, icon: String? = nil, showChevron: Bool = false, action: @escaping () -> Void) {
        self.title = title
        self.icon = icon
        self.showChevron = showChevron
        self.action = action
    }
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if let icon = icon {
                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .semibold))
                }
                
                Text(title)
                    .font(.system(size: 16, weight: .semibold))
                
                if showChevron {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 14, weight: .bold))
                }
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(
                LinearGradient(
                    colors: [
                        Color(red: 0.55, green: 0.18, blue: 0.95), // Deep Purple
                        Color(red: 0.18, green: 0.35, blue: 0.95)  // Bright Blue
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .cornerRadius(14)
            .shadow(color: Color(red: 0.55, green: 0.18, blue: 0.95).opacity(0.3), radius: 8, x: 0, y: 4)
        }
    }
}

#Preview {
    PreviewWrapper {
    VStack(spacing: 20) {
        GradientButton("Sign In") {}
        GradientButton("Continue with Apple", icon: "applelogo") {}
    }
    .padding()

    }
}
