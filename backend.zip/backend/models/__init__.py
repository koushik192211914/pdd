import enum
from sqlalchemy import Column, Integer, String, Enum, DateTime, ForeignKey, Date, Text
from sqlalchemy.sql import func
from database import Base

class UserRole(str, enum.Enum):
    Student = "Student"
    President = "President"
    VicePresident = "VicePresident"
    Secretary = "Secretary"
    Treasurer = "Treasurer"
    Admin = "Admin"

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(150), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(Enum(UserRole), nullable=False, default=UserRole.Student)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Club(Base):
    __tablename__ = "clubs"

    id = Column(Integer, primary_key=True, index=True)
    club_name = Column(String(150), unique=True, nullable=False)
    category = Column(String(100))
    description = Column(String(500))
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, server_default=func.now())

class Event(Base):
    __tablename__ = "events"

    id = Column(Integer, primary_key=True, index=True)
    event_name = Column(String(150), nullable=False)
    description = Column(String(500))
    club_id = Column(Integer, ForeignKey("clubs.id"))
    event_date = Column(DateTime)
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, server_default=func.now())

class EventRegistration(Base):
    __tablename__ = "event_registrations"

    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey("events.id"))
    student_id = Column(Integer, ForeignKey("users.id"))
    registration_date = Column(DateTime, server_default=func.now())
    status = Column(String(50), default="Registered")

class EventAttendance(Base):
    __tablename__ = "event_attendance"

    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey("events.id"))
    student_id = Column(Integer, ForeignKey("users.id"))
    status = Column(String(20))
    marked_by = Column(Integer, ForeignKey("users.id"))
    marked_at = Column(DateTime, server_default=func.now())

class EventSubstitution(Base):
    __tablename__ = "event_substitutions"

    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, ForeignKey("events.id"))
    original_student_id = Column(Integer, ForeignKey("users.id"))
    substitute_student_id = Column(Integer, ForeignKey("users.id"))
    assigned_by = Column(Integer, ForeignKey("users.id"))
    assigned_at = Column(DateTime, server_default=func.now())

class ClubMember(Base):
    __tablename__ = "club_members"

    id = Column(Integer, primary_key=True, index=True)
    club_id = Column(Integer, ForeignKey("clubs.id"))
    student_id = Column(Integer, ForeignKey("users.id"))
    joined_at = Column(DateTime, server_default=func.now())

class ClubAttendanceSession(Base):
    __tablename__ = "club_attendance_sessions"

    id = Column(Integer, primary_key=True, index=True)
    club_id = Column(Integer, ForeignKey("clubs.id"))
    attendance_date = Column(Date)
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, server_default=func.now())

class ClubAttendanceRecord(Base):
    __tablename__ = "club_attendance_records"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("club_attendance_sessions.id"))
    student_id = Column(Integer, ForeignKey("users.id"))
    status = Column(String(20))
    marked_at = Column(DateTime, server_default=func.now())

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # target recipient; None = global
    title = Column(String(255))
    message = Column(Text)
    is_read = Column(Integer, default=0)  # 0=unread, 1=read
    created_at = Column(DateTime, server_default=func.now())

class OTPCode(Base):
    __tablename__ = "otp_codes"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(150), index=True, nullable=False)
    code = Column(String(6), nullable=False)
    expires_at = Column(DateTime, nullable=False)
    used = Column(Integer, default=0)  # 0=unused, 1=used

class ClubDocument(Base):
    __tablename__ = "club_documents"

    id = Column(Integer, primary_key=True, index=True)
    club_id = Column(Integer, ForeignKey("clubs.id"))
    title = Column(String(255))
    file_url = Column(String(255))
    uploaded_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, server_default=func.now())

class JoinRequestStatus(str, enum.Enum):
    Pending = "Pending"
    Approved = "Approved"
    Rejected = "Rejected"

class ClubJoinRequest(Base):
    __tablename__ = "club_join_requests"

    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("users.id"))
    club_id = Column(Integer, ForeignKey("clubs.id"))
    status = Column(Enum(JoinRequestStatus), default=JoinRequestStatus.Pending)
    requested_at = Column(DateTime, server_default=func.now())

# Explicitly import submodules to allow 'from models.budgets import Budget'
# Note: These are namespace packages if __init__.py is in backend/models/
from .budgets import Budget
from .expenses import Expense
from .announcement import Announcement
