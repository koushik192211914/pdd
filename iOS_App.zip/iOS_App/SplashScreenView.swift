//
//  SplashScreenView.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Premium Splash Screen
//

import SwiftUI

struct SplashScreenView: View {
    @State private var logoScale: CGFloat = 0.4
    @State private var logoOpacity: Double = 0
    @State private var titleOpacity: Double = 0
    @State private var taglineOpacity: Double = 0
    @State private var loaderOpacity: Double = 0
    @State private var particleOpacity: Double = 0
    @State private var glowRadius: CGFloat = 0
    @State private var progressValue: CGFloat = 0
    let onFinished: () -> Void


    private let particles: [(x: CGFloat, y: CGFloat, size: CGFloat, opacity: Double)] = [
        (0.15, 0.12, 4, 0.45), (0.82, 0.08, 3, 0.30),
        (0.05, 0.35, 5, 0.35), (0.90, 0.28, 4, 0.40),
        (0.25, 0.70, 3, 0.25), (0.75, 0.65, 5, 0.35),
        (0.10, 0.82, 4, 0.30), (0.88, 0.78, 3, 0.40),
        (0.50, 0.05, 4, 0.30), (0.60, 0.90, 3, 0.25),
        (0.38, 0.18, 3, 0.20), (0.65, 0.42, 4, 0.30),
        (0.18, 0.55, 3, 0.25), (0.92, 0.52, 4, 0.20),
        (0.45, 0.85, 3, 0.30)
    ]

    var body: some View {
        ZStack {
            splashBackground
            particlesLayer
            mainContent
        }
        .toolbar(.hidden, for: .navigationBar)
        .onAppear { startAnimations() }
    }

    // MARK: – Background
    private var splashBackground: some View {
        LinearGradient(
            colors: [
                Color(red: 0.28, green: 0.38, blue: 0.98),  // vivid blue
                Color(red: 0.52, green: 0.25, blue: 0.92),  // purple
                Color(red: 0.82, green: 0.22, blue: 0.82)   // pink / magenta
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
        .overlay(
            AINetworkLinesView()
                .opacity(particleOpacity * 0.25)
                .ignoresSafeArea()
        )
    }

    // MARK: – Particles
    private var particlesLayer: some View {
        GeometryReader { geo in
            ForEach(0..<particles.count, id: \.self) { i in
                Circle()
                    .fill(Color.white.opacity(particles[i].opacity))
                    .frame(width: particles[i].size, height: particles[i].size)
                    .blur(radius: 0.8)
                    .position(
                        x: geo.size.width  * particles[i].x,
                        y: geo.size.height * particles[i].y
                    )
            }
        }
        .opacity(particleOpacity)
    }

    // MARK: – Main content
    private var mainContent: some View {
        VStack(spacing: 0) {
            Spacer()
            logoSection
            Spacer().frame(height: 36)
            titleSection
            Spacer()
            loaderSection
        }
        .padding(.horizontal, 24)
    }

    private var logoSection: some View {
        ZStack {
            // Soft glow halo behind the icon
            Circle()
                .fill(Color.white.opacity(0.18))
                .frame(width: 160, height: 160)
                .blur(radius: glowRadius)

            // White rounded-square card (matches reference)
            RoundedRectangle(cornerRadius: 28)
                .fill(Color.white)
                .frame(width: 110, height: 110)
                .shadow(color: Color.black.opacity(0.18), radius: 20, x: 0, y: 8)
                .overlay(
                    AILogoIconView()
                )
        }
        .scaleEffect(logoScale)
        .opacity(logoOpacity)
    }

    private var titleSection: some View {
        VStack(spacing: 10) {
            Text("ClubSphere AI")
                .font(.system(size: 34, weight: .bold))
                .foregroundColor(.white)
                .tracking(0.3)
                .shadow(color: Color.black.opacity(0.15), radius: 4, x: 0, y: 2)
                .opacity(titleOpacity)

            Text("AI-Powered Club Analytics")
                .font(.system(size: 15, weight: .medium))
                .foregroundColor(Color.white.opacity(0.80))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
                .opacity(taglineOpacity)
        }
    }

    private var loaderSection: some View {
        VStack(spacing: 16) {
            ZStack(alignment: .leading) {
                Capsule()
                    .fill(Color.white.opacity(0.12))
                    .frame(width: 180, height: 3)

                Capsule()
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(red: 0.55, green: 0.35, blue: 1.0),
                                Color(red: 0.85, green: 0.55, blue: 1.0)
                            ],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(width: 180 * progressValue, height: 3)
                    .shadow(color: Color.purple.opacity(0.8), radius: 4)
            }
            .clipShape(Capsule())

            Text("Loading your campus experience...")
                .font(.system(size: 12, weight: .regular))
                .foregroundColor(Color.white.opacity(0.45))
        }
        .opacity(loaderOpacity)
        .padding(.bottom, 56)
    }

    // MARK: – Animations
    private func startAnimations() {
        withAnimation(.easeIn(duration: 1.0)) { particleOpacity = 1 }

        withAnimation(.spring(response: 0.8, dampingFraction: 0.65).delay(0.2)) { logoScale = 1.0 }
        withAnimation(.easeIn(duration: 0.6).delay(0.2)) { logoOpacity = 1 }
        withAnimation(.easeInOut(duration: 1.2).delay(0.4)) { glowRadius = 30 }
        withAnimation(.easeIn(duration: 0.5).delay(0.7)) { titleOpacity = 1 }
        withAnimation(.easeIn(duration: 0.5).delay(0.95)) { taglineOpacity = 1 }
        withAnimation(.easeIn(duration: 0.5).delay(1.1)) { loaderOpacity = 1 }
        withAnimation(.easeInOut(duration: 1.4).delay(1.1)) { progressValue = 1.0 }

        DispatchQueue.main.asyncAfter(deadline: .now() + 2.8) {
            onFinished()
        }
    }
}

// MARK: – AI Logo Icon
struct AILogoIconView: View {
    var body: some View {
        ZStack {
            Image(systemName: "brain.head.profile")
                .resizable()
                .scaledToFit()
                .frame(width: 36, height: 36)
                .foregroundColor(.white.opacity(0.25))
                .offset(x: -4, y: -4)

            Image(systemName: "chart.bar.xaxis")
                .resizable()
                .scaledToFit()
                .frame(width: 26, height: 26)
                .foregroundColor(.white.opacity(0.30))
                .offset(x: 10, y: 10)

            Image(systemName: "sparkles")
                .resizable()
                .scaledToFit()
                .frame(width: 52, height: 52)
                .foregroundStyle(
                    LinearGradient(
                        colors: [.white, Color(red: 0.85, green: 0.65, blue: 1.0)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        }
    }
}

// MARK: – AI Network Lines
struct AINetworkLinesView: View {
    private let lines: [(x1: CGFloat, y1: CGFloat, x2: CGFloat, y2: CGFloat)] = [
        (0.10, 0.15, 0.30, 0.28), (0.30, 0.28, 0.55, 0.18),
        (0.55, 0.18, 0.75, 0.32), (0.75, 0.32, 0.92, 0.22),
        (0.10, 0.15, 0.15, 0.45), (0.30, 0.28, 0.25, 0.58),
        (0.55, 0.18, 0.50, 0.50), (0.75, 0.32, 0.85, 0.60),
        (0.15, 0.45, 0.25, 0.58), (0.25, 0.58, 0.50, 0.50),
        (0.50, 0.50, 0.85, 0.60), (0.15, 0.45, 0.10, 0.72),
        (0.25, 0.58, 0.40, 0.78), (0.50, 0.50, 0.60, 0.80),
        (0.85, 0.60, 0.90, 0.82), (0.10, 0.72, 0.40, 0.78),
        (0.40, 0.78, 0.60, 0.80)
    ]

    var body: some View {
        GeometryReader { geo in
            ForEach(0..<lines.count, id: \.self) { i in
                Path { path in
                    path.move(to: CGPoint(
                        x: geo.size.width  * lines[i].x1,
                        y: geo.size.height * lines[i].y1))
                    path.addLine(to: CGPoint(
                        x: geo.size.width  * lines[i].x2,
                        y: geo.size.height * lines[i].y2))
                }
                .stroke(
                    LinearGradient(
                        colors: [Color.purple.opacity(0.30), Color.blue.opacity(0.15)],
                        startPoint: .leading,
                        endPoint: .trailing
                    ),
                    lineWidth: 0.5
                )
            }

            ForEach(0..<lines.count, id: \.self) { i in
                Circle()
                    .fill(Color.white.opacity(0.20))
                    .frame(width: 3, height: 3)
                    .position(
                        x: geo.size.width  * lines[i].x1,
                        y: geo.size.height * lines[i].y1
                    )
            }
        }
    }
}

#Preview {
    PreviewWrapper {
    SplashScreenView(onFinished: {})
        .environmentObject(AttendanceNotificationStore())

    }
}
