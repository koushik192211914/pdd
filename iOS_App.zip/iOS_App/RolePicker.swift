//
//  RolePicker.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Role selection dropdown for login
//

import SwiftUI

// Supported roles
enum ClubRole: String, CaseIterable, Identifiable {
    case student       = "Student"
    case admin         = "Admin"
    case president     = "President"
    case vicePresident = "Vice President"
    case secretary     = "Secretary"

    var id: String { rawValue }

    /// SF Symbol used beside each role option
    var icon: String {
        switch self {
        case .student:       return "graduationcap.fill"
        case .admin:         return "shield.fill"
        case .president:     return "star.fill"
        case .vicePresident: return "star.leadinghalf.filled"
        case .secretary:     return "doc.fill"
        }
    }
}

// MARK: – Picker component
struct RolePicker: View {
    @Binding var selectedRole: ClubRole?

    // Style tokens
    private let fieldBG    = Color(red: 0.95, green: 0.95, blue: 0.97)
    private let borderColor = Color(red: 0.88, green: 0.88, blue: 0.92)
    private let purple     = Color(red: 0.55, green: 0.18, blue: 0.95)
    private let labelGray  = Color(red: 0.40, green: 0.40, blue: 0.45)

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Select Your Role")
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(labelGray)

            Menu {
                ForEach(ClubRole.allCases) { role in
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            selectedRole = role
                        }
                    } label: {
                        Label(role.rawValue, systemImage: role.icon)
                    }
                }
            } label: {
                menuLabel
            }
        }
    }

    private var menuLabel: some View {
        HStack {
            Text(selectedRole?.rawValue ?? "Choose your role")
                .font(.system(size: 16, weight: .regular))
                .foregroundColor(
                    selectedRole == nil
                    ? Color(red: 0.70, green: 0.70, blue: 0.75)
                    : Color(red: 0.10, green: 0.10, blue: 0.12)
                )
            Spacer()
            Image(systemName: "chevron.down")
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(Color(red: 0.60, green: 0.60, blue: 0.65))
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 14)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(fieldBG)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(borderColor, lineWidth: 1)
                )
        )
    }
}

#Preview {
    struct PreviewWrapper: View {
        @State private var role: ClubRole? = nil
        var body: some View {
            RolePicker(selectedRole: $role)
                .padding()
        }
    }
    return PreviewWrapper()
}
