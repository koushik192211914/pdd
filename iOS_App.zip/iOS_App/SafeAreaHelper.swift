import UIKit
import SwiftUI

var safeTop: CGFloat {
    UIApplication.shared.connectedScenes
        .compactMap { ($0 as? UIWindowScene)?.windows.first?.safeAreaInsets.top }
        .first ?? 0
}
