import SwiftUI

struct PresidentDashboardView: View {
    /// All officer roles share this shell: President, VP, Secretary, Treasurer.
    var role: ClubRole = .president

    @State private var isLoggedOut = false
    @State private var selectedTab: Int = 0

    // MARK: - Role title for header
    private var roleTitle: String {
        switch role {
        case .admin:         return "Admin Dashboard"
        case .president:     return "President Dashboard"
        case .vicePresident: return "Vice President Dashboard"
        case .secretary:     return "Secretary Dashboard"
        case .treasurer:     return "Treasurer Dashboard"
        default:             return "\(role.rawValue) Dashboard"
        }
    }

    // MARK: - Home tab — role-specific dashboard
    @ViewBuilder
    private var homeTab: some View {
        switch role {
        case .admin:
            AdminHomeDashboard()
        case .student:
            StudentHomeDashboard(onViewAnalytics: { selectedTab = 3 })
        case .secretary:
            SecretaryHomeDashboard(onViewAnalytics: { selectedTab = 3 })
        case .treasurer:
            TreasurerHomeDashboard(onViewAnalytics: { selectedTab = 3 })
        default:
            // President and Vice President share the same home layout
            PresidentHomeDashboard(roleTitle: roleTitle, onViewAnalytics: { selectedTab = 3 })
        }
    }

    var body: some View {
        TabView(selection: $selectedTab) {
            // ── Home ──────────────────────────────────────────────────────
            NavigationStack { homeTab }
                .tabItem { Label("Home",      systemImage: "house.fill") }
                .tag(0)

            // ── Clubs ─────────────────────────────────────────────────────
            NavigationStack { ClubsScreen(role: role) }
                .tabItem { Label("Clubs",     systemImage: "building.2.fill") }
                .tag(1)

            // ── Events ────────────────────────────────────────────────────
            NavigationStack { EventsScreen(role: role) }
                .tabItem { Label("Events",    systemImage: "calendar") }
                .tag(2)

            // ── Analytics ─────────────────────────────────────────────────
            NavigationStack { AnalyticsDashboardView(role: role) }
                .tabItem { Label("Analytics", systemImage: "chart.bar.fill") }
                .tag(3)

            // ── Profile (with Logout) ──────────────────────────────────────
            NavigationStack { ProfileScreen(role: role, onLogout: { isLoggedOut = true }) }
                .tabItem { Label("Profile",   systemImage: "person.fill") }
                .tag(4)
        }
        .tint(.purple)
        .toolbar(.hidden, for: .navigationBar)
        .navigationDestination(isPresented: $isLoggedOut) {
            LoginView().navigationBarBackButtonHidden(true)
        }
    }
}

struct PresidentDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        PreviewWrapper {
        Group {
            PresidentDashboardView(role: .admin)         .previewDisplayName("Admin")
            PresidentDashboardView(role: .president)     .previewDisplayName("President")
            PresidentDashboardView(role: .vicePresident) .previewDisplayName("Vice President")
            PresidentDashboardView(role: .secretary)     .previewDisplayName("Secretary")
            PresidentDashboardView(role: .treasurer)     .previewDisplayName("Treasurer")
        }
        .environmentObject(AttendanceNotificationStore())
    
        }
    }
}

