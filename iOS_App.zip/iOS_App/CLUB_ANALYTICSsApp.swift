//
//  CLUB_ANALYTICSsApp.swift
//  CLUB ANALYTICSs
//
//  Created by SAIL on 06/03/26.
//

import SwiftUI

@main
struct CLUB_ANALYTICSsApp: App {
    @StateObject private var store       = AttendanceNotificationStore()
    @StateObject private var authManager = AuthManager.shared

    @State private var isSplashScreenDone = false

    var body: some Scene {
        WindowGroup {
            Group {
                if !isSplashScreenDone {
                    // 1. Initial Loading Splash (Always shown for ~2.8s)
                    SplashScreenView {
                        print("🚀 [App] Splash done. isLoggedIn: \(authManager.isLoggedIn). Role: \(authManager.userRole)")
                        withAnimation(.easeInOut(duration: 0.5)) { 
                            isSplashScreenDone = true 
                        }
                    }
                } else if !authManager.hasSeenOnboarding {
                    // 2. Initial Onboarding Flow
                    NavigationStack {
                        OnboardingView()
                            .onAppear { print("✅ [App] Rendering OnboardingView branch") }
                    }
                    .transition(.asymmetric(
                        insertion: .move(edge: .trailing).combined(with: .opacity),
                        removal: .move(edge: .leading).combined(with: .opacity)
                    ))
                } else if !authManager.isLoggedIn {
                    // 3. Login Flow
                    NavigationStack {
                        LoginView()
                            .onAppear { print("✅ [App] Rendering LoginView branch") }
                    }
                    .transition(.opacity.combined(with: .move(edge: .bottom)))
                } else {
                    // 4. Main Application Dashboard
                    PresidentDashboardView(role: authManager.clubRole)
                        .onAppear { print("✅ [App] Rendering Main Dashboard branch") }
                        .transition(.opacity.combined(with: .scale(scale: 0.95)))
                }
            }
            .environmentObject(store)
            .environmentObject(authManager)
        }
    }
}
