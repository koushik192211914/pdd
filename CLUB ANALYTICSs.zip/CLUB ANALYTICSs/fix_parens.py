import os
import re

dir_path = "/Users/sail/Desktop/CLUB ANALYTICSs/CLUB ANALYTICSs"

files_fixed = 0

for filename in os.listdir(dir_path):
    if not filename.endswith(".swift"):
        continue
    filepath = os.path.join(dir_path, filename)
    with open(filepath, 'r') as f:
        content = f.read()
    original = content

    # Fix dangling `)` followed by `.previewDisplayName` or `.environmentObject` or `}` 
    # that was left from removing `.environmentObject(AttendanceNotificationStore())`
    # The regex was `\.environmentObject\([^)]*AttendanceNotificationStore[^)]*\)`
    # So it left `)` possibly followed by newlines.
    
    # Let's replace `}\n        )\n` with `}\n`
    content = re.sub(r'\}\s*\)\s*\.preview', '}\n        .preview', content)
    content = re.sub(r'\}\s*\)\s*\}', '}\n    }', content)
    content = re.sub(r'\)\s*\.preview', '.preview', content)
    # Also handle cases where it was just `)\n    }`
    content = re.sub(r'^\s*\)\s*$', '', content, flags=re.MULTILINE)

    if content != original:
        with open(filepath, 'w') as f:
            f.write(content)
        files_fixed += 1
        print(f"Fixed {filename}")

print(f"Fixed {files_fixed} files.")
