import Foundation

struct UserNotification: Decodable, Identifiable {
    let id: Int
    let user_id: Int?
    let title: String
    let message: String
    let is_read: Int
    let created_at: String
}

final class NotificationService {
    static let shared = NotificationService()
    private init() {}

    func getNotifications(userId: Int) async throws -> [UserNotification] {
        return try await APIClient.shared.request("/notifications/user/\(userId)")
    }

    func markRead(notificationId: Int) async throws {
        let _: MessageResponse = try await APIClient.shared.request(
            "/notifications/\(notificationId)/read", method: "POST"
        )
    }
}

