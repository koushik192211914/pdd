//
//  ProfileScreen.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Profile tab with Logout
//

import SwiftUI

struct ProfileScreen: View {
    let role: ClubRole
    /// Called when the user taps Logout – parent handles navigation.
    let onLogout: () -> Void

    @EnvironmentObject private var store: AttendanceNotificationStore
    @EnvironmentObject private var authManager: AuthManager

    @State private var clubName: String = "Loading..."

    private var displayName: String { authManager.userName.isEmpty ? "User" : authManager.userName }
    private var initials: String {
        let parts = authManager.userName.split(separator: " ")
        let letters = parts.prefix(2).compactMap { $0.first }.map { String($0) }
        return letters.isEmpty ? "U" : letters.joined()
    }

    private let avatarGradient = LinearGradient(
        colors: [Color(red: 0.55, green: 0.18, blue: 0.95), Color(red: 0.28, green: 0.08, blue: 0.70)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {

                // ── Header band ──────────────────────────────────────────────
                LinearGradient(
                    colors: [Color.purple, Color.blue],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .frame(height: 140)
                .overlay(
                    Text("Profile")
                        .font(.title2).bold()
                        .foregroundColor(.white)
                        .padding(.top, 10),
                    alignment: .center
                )
                .ignoresSafeArea(edges: .top)

                // ── Avatar (overlaps header bottom) ──────────────────────────
                ZStack {
                    Circle()
                        .fill(avatarGradient)
                        .frame(width: 90, height: 90)
                        .shadow(color: Color.purple.opacity(0.35), radius: 10, x: 0, y: 4)
                    Text(initials)
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(.white)
                }
                .offset(y: -45)
                .padding(.bottom, -45)

                // ── Name + Role badge + Club ─────────────────────────────────
                VStack(spacing: 6) {
                    Text(displayName)
                        .font(.title3).bold()
                        .foregroundColor(.primary)

                    Text(role.rawValue)
                        .font(.caption).fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 5)
                        .background(
                            Capsule()
                                .fill(LinearGradient(
                                    colors: [Color.purple, Color.blue],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                        )

                    HStack(spacing: 4) {
                        Image(systemName: role == .admin ? "shield.fill" : "building.2.fill")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text(role == .admin ? "ClubSphere System Admin" : clubName)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
                .padding(.top, 56)

                // ── Club Management (President Only) ──────────────────────────
                if role == .president, let clubId = authManager.clubId {
                    managementSection(clubId: clubId)
                        .padding(.top, 28)
                        .padding(.horizontal, 20)
                }

                // ── Settings list ────────────────────────────────────────────
                settingsSection
                    .padding(.top, 28)
                    .padding(.horizontal, 20)

                // ── Logout button ────────────────────────────────────────────
                Button(action: onLogout) {
                    HStack(spacing: 10) {
                        Image(systemName: "rectangle.portrait.and.arrow.right.fill")
                            .font(.system(size: 17, weight: .semibold))
                        Text("Logout")
                            .font(.system(size: 17, weight: .semibold))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(
                        LinearGradient(
                            colors: [Color.red, Color(red: 0.85, green: 0.10, blue: 0.10)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )

                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(color: Color.red.opacity(0.30), radius: 8, x: 0, y: 4)
                }
                .padding(.horizontal, 20)
                .padding(.top, 32)
                .padding(.bottom, 40)
            }
        }
        .background(Color(UIColor.systemGroupedBackground).ignoresSafeArea())
        .navigationBarHidden(true)
        .task {
            if role != .admin {
                if let clubId = authManager.clubId {
                    do {
                        let club = try await ClubService.shared.getClub(id: clubId)
                        await MainActor.run { self.clubName = club.name }
                    } catch {
                        await MainActor.run { self.clubName = "Unknown Club" }
                    }
                } else {
                    await MainActor.run { self.clubName = "No Club Assigned" }
                }
            }
        }
    }

    // MARK: – Club Management section
    private func managementSection(clubId: Int) -> some View {
        VStack(spacing: 0) {
            sectionHeader("Club Management")
            NavigationLink(destination: ManageMembersScreen(clubId: clubId)) {
                settingsRow(icon: "person.2.fill", color: .orange, title: "Manage Members")
            }
            .buttonStyle(PlainButtonStyle())
        }
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
    }

    // MARK: – Settings section
    private var settingsSection: some View {
        VStack(spacing: 0) {
            sectionHeader("Account")
            NavigationLink(destination: EditProfileView()) {
                settingsRow(icon: "pencil.circle.fill", color: .purple, title: "Edit Profile")
            }
            .buttonStyle(PlainButtonStyle())
            Divider().padding(.leading, 52)
            NavigationLink(destination: NotificationSettingsView()) {
                settingsRow(icon: "bell.fill", color: .blue, title: "Notifications")
            }
            .buttonStyle(PlainButtonStyle())

        }
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
    }

    private func sectionHeader(_ text: String) -> some View {
        Text(text)
            .font(.caption).fontWeight(.semibold)
            .foregroundColor(.secondary)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 16)
            .padding(.top, 14)
            .padding(.bottom, 4)
    }

    private func settingsRow(icon: String, color: Color, title: String) -> some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 8)
                    .fill(color)
                    .frame(width: 32, height: 32)
                Image(systemName: icon)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(.white)
            }
            Text(title)
                .font(.body)
                .foregroundColor(.primary)
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(Color(UIColor.tertiaryLabel))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .contentShape(Rectangle())
    }
}

#Preview {
    PreviewWrapper {
    ProfileScreen(role: .president, onLogout: {})

    }
}
