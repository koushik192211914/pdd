import Foundation
import Combine

@MainActor
final class NotificationViewModel: ObservableObject {
    @Published var notifications: [UserNotification] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    func load(userId: Int) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                notifications = try await NotificationService.shared.getNotifications(userId: userId)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func markRead(_ notification: UserNotification) {
        Task {
            try? await NotificationService.shared.markRead(notificationId: notification.id)
            if let idx = notifications.firstIndex(where: { $0.id == notification.id }) {
                notifications.remove(at: idx)
            }
        }
    }
}

