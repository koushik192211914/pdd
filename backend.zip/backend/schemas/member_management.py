from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class UserResponse(BaseModel):
    id: int
    name: str
    email: str
    role: str
    created_at: datetime

    class Config:
        from_attributes = True
        orm_mode = True

class MemberResponse(BaseModel):
    id: int
    student_id: int
    club_id: int
    joined_at: datetime

    class Config:
        from_attributes = True
        orm_mode = True
