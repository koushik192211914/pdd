from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from database import get_db
import models
import schemas

from core.permissions import require_authority

router = APIRouter(
    prefix="/documents",
    tags=["Documents"]
)

@router.post("/upload", response_model=schemas.DocumentResponse)
def upload_document(document: schemas.DocumentCreate, db: Session = Depends(get_db), current_user: models.User = Depends(require_authority)):
    new_doc = models.ClubDocument(
        club_id=document.club_id,
        title=document.title,
        file_url=document.file_url,
        uploaded_by=current_user.id
    )
    db.add(new_doc)
    db.commit()
    db.refresh(new_doc)
    return new_doc

@router.get("/club/{club_id}", response_model=List[schemas.DocumentResponse])
def get_documents_by_club(club_id: int, status: str = None, db: Session = Depends(get_db)):
    query = db.query(models.ClubDocument).filter(models.ClubDocument.club_id == club_id)
    if status:
        query = query.filter(models.ClubDocument.status == status)
    docs = query.all()
    return docs

@router.delete("/{document_id}")
def delete_document(document_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(require_authority)):
    doc = db.query(models.ClubDocument).filter(models.ClubDocument.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    
    db.delete(doc)
    db.commit()
    return {"message": "Document deleted successfully"}
