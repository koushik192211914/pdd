//
//  DashboardViewModels.swift
//  CLUB ANALYTICSs
//

import Foundation
import SwiftUI
import Combine

class BaseDashboardViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
}

// MARK: - Admin Dashboard
final class AdminHomeViewModel: BaseDashboardViewModel {
    @Published var summary: PlatformSummaryResponse?
    @Published var dashboard: DashboardResponse?
    
    @MainActor
    func fetchData() async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            async let s = AdminService.shared.getPlatformSummary()
            async let d = AdminService.shared.getDashboard()
            
            let (summary, dashboard) = try await (s, d)
            self.summary = summary
            self.dashboard = dashboard
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: - President Dashboard
final class PresidentHomeViewModel: BaseDashboardViewModel {
    @Published var club: ClubResponse?
    @Published var health: ClubHealthResponse?
    @Published var events: [EventResponse] = []
    @Published var lowEngagementMembers: [LowEngagementMember] = []
    @Published var announcements: [AnnouncementResponse] = []
    @Published var pendingRequestCount: Int = 0 
    
    @MainActor
    func fetchData(clubId: Int) async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            async let c = ClubService.shared.getClub(id: clubId)
            async let h = AnalyticsService.shared.getClubHealth(clubId: clubId)
            async let e = EventService.shared.getEvents(clubId: clubId)
            async let l = AnalyticsService.shared.getLowEngagementMembers(clubId: clubId)
            async let ann = AnnouncementService.shared.getAnnouncements(clubId: clubId)
            async let pending = JoinRequestService.shared.getPendingRequests(clubId: clubId)
            
            let (club, health, events, lowEng, annList, pendingList) = try await (c, h, e, l, ann, pending)
            self.club = club
            self.health = health
            self.events = events
            self.lowEngagementMembers = lowEng
            self.announcements = annList
            self.pendingRequestCount = pendingList.count
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: - Secretary Dashboard
final class SecretaryHomeViewModel: BaseDashboardViewModel {
    @Published var club: ClubResponse?
    @Published var announcements: [AnnouncementResponse] = []
    @Published var documents: [DocumentResponse] = []
    @Published var summary: [String: Int] = [:]
    
    @MainActor
    func fetchData(clubId: Int) async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            async let c = ClubService.shared.getClub(id: clubId)
            async let a = AnnouncementService.shared.getAnnouncements(clubId: clubId)
            async let d = DocumentService.shared.getDocuments(clubId: clubId)
            async let s: [String: Int] = APIClient.shared.request("/analytics/club/\(clubId)")
            
            let (club, ann, docs, sum) = try await (c, a, d, s)
            self.club = club
            self.announcements = ann
            self.documents = docs
            self.summary = sum
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: - Treasurer Dashboard
final class TreasurerHomeViewModel: BaseDashboardViewModel {
    @Published var financialReport: FinancialReportResponse?
    @Published var expenses: [ExpenseResponse] = []
    
    @MainActor
    func fetchData(clubId: Int) async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            async let r = FinanceService.shared.getFinancialReport(clubId: clubId)
            async let e = FinanceService.shared.getExpenses(clubId: clubId)
            
            let (report, exp) = try await (r, e)
            self.financialReport = report
            self.expenses = exp
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: - Student Dashboard
final class StudentHomeViewModel: BaseDashboardViewModel {
    @Published var engagement: StudentEngagementResponse?
    @Published var myClubs: [ClubResponse] = []
    @Published var events: [EventResponse] = []
    
    @MainActor
    func fetchData(studentId: Int, clubId: Int?) async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            let eng = try await AnalyticsService.shared.getStudentEngagement(studentId: studentId)
            self.engagement = eng
            
            // If the user just joined a club, we might get the clubId from the engagement response
            let effectiveClubId = clubId ?? eng.club_id
            
            if let cid = effectiveClubId {
                // Load only the student's own club and its events
                async let c = ClubService.shared.getClub(id: cid)
                async let ev = EventService.shared.getEvents(clubId: cid)
                let (club, clubEvents) = try await (c, ev)
                self.myClubs = [club]
                self.events = clubEvents
            } else {
                // No club yet — clear lists
                self.myClubs = []
                self.events = []
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
