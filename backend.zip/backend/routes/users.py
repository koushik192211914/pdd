import sys
import os
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

# Append backend directories to sys.path to allow importing from the new folders
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), "schemas"))

from database import get_db
import models
from schemas import UserResponse
from announcements import UserUpdate
from core.permissions import get_current_user

router = APIRouter(
    prefix="/users",
    tags=["Users"]
)

@router.get("/me", response_model=UserResponse)
def read_users_me(current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    membership = db.query(models.ClubMember).filter(models.ClubMember.student_id == current_user.id).first()
    club_id = membership.club_id if membership else None
    if not club_id:
        club = db.query(models.Club).filter(models.Club.created_by == current_user.id).first()
        club_id = club.id if club else None
        
    return {
        "id": current_user.id,
        "name": current_user.name,
        "email": current_user.email,
        "role": current_user.role,
        "created_at": current_user.created_at,
        "club_id": club_id
    }
@router.put("/me", response_model=UserResponse)
def update_user_me(
    user_update: UserUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    if user_update.name is not None:
        current_user.name = user_update.name
    if user_update.email is not None:
        # Check if email is already taken
        existing_user = db.query(models.User).filter(models.User.email == user_update.email).first()
        if existing_user and existing_user.id != current_user.id:
            raise HTTPException(status_code=400, detail="Email already registered")
        current_user.email = user_update.email

    db.commit()
    db.refresh(current_user)
    
    membership = db.query(models.ClubMember).filter(models.ClubMember.student_id == current_user.id).first()
    club_id = membership.club_id if membership else None
    if not club_id:
        club = db.query(models.Club).filter(models.Club.created_by == current_user.id).first()
        club_id = club.id if club else None
        
    return {
        "id": current_user.id,
        "name": current_user.name,
        "email": current_user.email,
        "role": current_user.role,
        "created_at": current_user.created_at,
        "club_id": club_id
    }

@router.get("/{user_id}", response_model=UserResponse)
def read_user_profile(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user
