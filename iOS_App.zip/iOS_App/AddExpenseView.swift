import SwiftUI

struct AddExpenseView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var title: String = ""
    @State private var amount: String = ""
    @State private var category: String = "Select Category"
    @State private var event: String = ""
    @State private var paymentMethod: String = "Cash"
    @State private var description: String = ""
    @State private var showSuccessMessage = false

    private let categories = ["Food & Bev", "Logistics", "Marketing", "Honorarium", "Other"]
    private let paymentMethods = ["Cash", "UPI", "Bank Transfer"]
    
    // Extracted safe Area logic
    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // ── Header ───────────────────────────────────────────────
                headerView

                VStack(spacing: 24) {
                    // ── Form Area ───────────────────────────────────────────
                    VStack(alignment: .leading, spacing: 20) {
                        
                        // Title
                        formField(title: "Expense Title", icon: "pencil", placeholder: "e.g. Pizza for Hackathon", text: $title)
                        
                        // Amount
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Amount", systemImage: "indianrupeesign")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            TextField("₹ 0.00", text: $amount)
                                .keyboardType(.decimalPad)
                                .padding()
                                .background(Color(UIColor.secondarySystemGroupedBackground))
                                .cornerRadius(12)
                                .shadow(color: .black.opacity(0.03), radius: 5, x: 0, y: 2)
                        }

                        // Category
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Expense Category", systemImage: "tag")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            Menu {
                                ForEach(categories, id: \.self) { cat in
                                    Button(cat) { category = cat }
                                }
                            } label: {
                                menuLabel(text: category, isPlaceholder: category == "Select Category")
                            }
                        }

                        // Event (Optional)
                        formField(title: "Event (Optional)", icon: "calendar", placeholder: "e.g. Fall Hackathon", text: $event)

                        // Payment Method
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Payment Method", systemImage: "creditcard")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            Picker("Payment Method", selection: $paymentMethod) {
                                ForEach(paymentMethods, id: \.self) { method in
                                    Text(method).tag(method)
                                }
                            }
                            .pickerStyle(.segmented)
                        }

                        // Upload Receipt
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Upload Receipt", systemImage: "doc.viewfinder")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            Button(action: { /* File picker */ }) {
                                HStack {
                                    Image(systemName: "camera.fill")
                                    Text("Scan or Choose Photo").fontWeight(.medium)
                                    Spacer()
                                }
                                .padding()
                                .foregroundColor(.purple)
                                .background(Color.purple.opacity(0.08))
                                .cornerRadius(12)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.purple.opacity(0.3), lineWidth: 1)
                                )
                            }
                        }

                        // Description
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Description (Optional)", systemImage: "text.alignleft")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            TextEditor(text: $description)
                                .frame(minHeight: 100)
                                .padding(8)
                                .background(Color(UIColor.secondarySystemGroupedBackground))
                                .cornerRadius(12)
                                .shadow(color: .black.opacity(0.03), radius: 5, x: 0, y: 2)
                        }
                    }
                    .padding(.horizontal)

                    // ── Submit Button ───────────────────────────────────────
                    Button(action: submitExpense) {
                        Text("Submit Expense")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(
                                LinearGradient(colors: [.purple, .blue], startPoint: .leading, endPoint: .trailing)
                            )
                            .cornerRadius(16)
                            .shadow(color: .purple.opacity(0.3), radius: 8, x: 0, y: 4)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 40)
                    .disabled(title.isEmpty || amount.isEmpty || category == "Select Category")
                    .opacity(title.isEmpty || amount.isEmpty || category == "Select Category" ? 0.6 : 1.0)
                }
                .padding(.top, 24)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .overlay(
            Group {
                if showSuccessMessage {
                    ZStack {
                        Color.black.opacity(0.3).ignoresSafeArea()
                        VStack(spacing: 16) {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.green)
                            Text("Expense Submitted!")
                                .font(.title3).bold()
                            Text("Navigating to dashboard...")
                                .font(.subheadline).foregroundColor(.secondary)
                        }
                        .padding(30)
                        .background(Color(UIColor.systemBackground))
                        .cornerRadius(24)
                        .shadow(radius: 20)
                    }
                    .transition(.opacity)
                }
            }
        )
    }

    private var headerView: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 8)
                HStack(alignment: .center, spacing: 12) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Add Expense").font(.title3).bold().foregroundColor(.white)
                        Text("Record a new club expenditure")
                            .font(.caption).foregroundColor(.white.opacity(0.80)).lineLimit(1)
                    }
                    Spacer()
                }
                .padding(.horizontal, 18).padding(.bottom, 22)
            }
        }
        .frame(height: safeTop + 92)
    }

    // Helper for simple text fields
    private func formField(title: String, icon: String, placeholder: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(title, systemImage: icon)
                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
            TextField(placeholder, text: text)
                .padding()
                .background(Color(UIColor.secondarySystemGroupedBackground))
                .cornerRadius(12)
                .shadow(color: .black.opacity(0.03), radius: 5, x: 0, y: 2)
        }
    }

    // Helper for menu labels
    private func menuLabel(text: String, isPlaceholder: Bool) -> some View {
        HStack {
            Text(text)
                .foregroundColor(isPlaceholder ? .secondary : .primary)
            Spacer()
            Image(systemName: "chevron.down").font(.caption).foregroundColor(.secondary)
        }
        .padding()
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.03), radius: 5, x: 0, y: 2)
    }

    private func submitExpense() {
        withAnimation { showSuccessMessage = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            // Ensure we return to Dashboard
            dismiss()
        }
    }
}

#Preview {
    PreviewWrapper {
    AddExpenseView()

    }
}
