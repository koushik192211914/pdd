//
//  CLUB_ANALYTICSsApp.swift
//  CLUB ANALYTICSs
//
//  Created by SAIL on 06/03/26.
//

import SwiftUI

@main
struct CLUB_ANALYTICSsApp: App {
    @StateObject private var store       = AttendanceNotificationStore()
    @StateObject private var authManager = AuthManager.shared

    @State private var isSplashScreenDone = false

    var body: some Scene {
        WindowGroup {
            Group {
                if !isSplashScreenDone {
                    // 1. Initial Loading Splash
                    SplashScreenView {
                        withAnimation { isSplashScreenDone = true }
                    }
                } else if !authManager.isLoggedIn {
                    // 2. Auth Flow (Onboarding -> Login)
                    NavigationStack {
                        OnboardingView()
                    }
                } else {
                    // 3. Main Application Dashboard
                    // No outer NavigationStack here! 
                    // PresidentDashboardView will provide its own per-tab stacks.
                    PresidentDashboardView(role: authManager.clubRole)
                }
            }
            .environmentObject(store)
            .environmentObject(authManager)
        }
    }
}
