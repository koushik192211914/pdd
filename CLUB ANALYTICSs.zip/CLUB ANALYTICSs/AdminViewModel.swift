//
//  AdminViewModel.swift
//  CLUB ANALYTICSs
//

import Foundation
import Combine

@MainActor
final class AdminViewModel: ObservableObject {
    @Published var users: [AdminUserResponse] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var successMessage: String?

    func loadUsers() {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                users = try await AdminService.shared.getAllUsers()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func promote(userId: Int, role: String) {
        Task {
            isLoading = true
            defer { isLoading = false }
            do {
                let result = try await AdminService.shared.promoteUser(userId: userId, role: role)
                successMessage = result.message
                loadUsers()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func demote(userId: Int) {
        Task {
            isLoading = true
            defer { isLoading = false }
            do {
                let result = try await AdminService.shared.demoteUser(userId: userId)
                successMessage = result.message
                loadUsers()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
