from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
import bcrypt

from database import get_db
from models import User, ClubMember, Club
from schemas import (
    SignupRequest,
    LoginRequest,
    ForgotPasswordRequest,
    LoginResponse,
    MessageResponse,
    UserResponse,
)

router = APIRouter(prefix="/auth", tags=["Authentication"])


# ── Helper ───────────────────────────────────────────────────────────────────

def hash_password(plain: str) -> str:
    return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))


# ── POST /signup ─────────────────────────────────────────────────────────────

@router.post("/signup", response_model=MessageResponse, status_code=status.HTTP_201_CREATED)
def signup(payload: SignupRequest, db: Session = Depends(get_db)):
    """Register a new user account."""
    existing = db.query(User).filter(User.email == payload.email).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="An account with this email already exists."
        )

    new_user = User(
        name=payload.name,
        email=payload.email,
        password_hash=hash_password(payload.password),
        role="Student",
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return {"message": "Account created successfully. Please log in."}


# ── POST /login ──────────────────────────────────────────────────────────────

@router.post("/login", response_model=LoginResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    """Authenticate a user and return their profile."""
    print(f"DEBUG: Login request received for email: {payload.email}")
    user = db.query(User).filter(User.email == payload.email).first()
    if not user:
        print("DEBUG: User not found")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password."
        )
    
    print("DEBUG: User found, verifying password...")
    if not verify_password(payload.password, user.password_hash):
        print("DEBUG: Password verification failed")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password."
        )
    
    print(f"DEBUG: Login successful for user: {user.name}")
    
    membership = db.query(ClubMember).filter(ClubMember.student_id == user.id).first()
    club_id = membership.club_id if membership else None
    if not club_id:
        club = db.query(Club).filter(Club.created_by == user.id).first()
        club_id = club.id if club else None
        
    return {
        "message": "Login successful.",
        "user": {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "role": user.role,
            "created_at": user.created_at,
            "club_id": club_id
        }
    }


