//
//  CLUB_ANALYTICSsApp.swift
//  CLUB ANALYTICSs
//
//  Created by SAIL on 06/03/26.
//

import SwiftUI

@main
struct CLUB_ANALYTICSsApp: App {
    @StateObject private var store       = AttendanceNotificationStore()
    @StateObject private var authManager = AuthManager.shared

    @State private var isSplashScreenDone = false

    var body: some Scene {
        WindowGroup {
            Group {
                if !isSplashScreenDone {
                    // 1. Initial Loading Splash (Always shown for ~2.8s)
                    SplashScreenView {
                        print("🚀 [App] Splash done. isLoggedIn: \(authManager.isLoggedIn). Role: \(authManager.userRole)")
                        withAnimation(.easeInOut(duration: 0.5)) { 
                            isSplashScreenDone = true 
                        }
                    }
                } else {
                    // Splash is done: Choose between Auth and Main App
                    if !authManager.isLoggedIn {
                        // 2. Auth Flow (Onboarding -> Login)
                        NavigationStack {
                            if !authManager.hasSeenOnboarding {
                                OnboardingView()
                                    .transition(.asymmetric(
                                        insertion: .move(edge: .bottom).combined(with: .opacity),
                                        removal: .move(edge: .top).combined(with: .opacity)
                                    ))
                            } else {
                                LoginView()
                                    .transition(.opacity.combined(with: .scale(scale: 0.95)))
                            }
                        }
                    } else {
                        // 3. Main Application Dashboard
                        PresidentDashboardView(role: authManager.clubRole)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
            }
            .environmentObject(store)
            .environmentObject(authManager)
        }
    }
}
