//
//  DashboardViewModels.swift
//  CLUB ANALYTICSs
//

import Foundation
import SwiftUI
import Combine



// MARK: - Admin Dashboard
@MainActor
final class AdminHomeViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showDebugAlert = false
    @Published var debugMessage = ""
    @Published var lastUpdated = Date()
    @Published var summary: PlatformSummaryResponse?
    @Published var dashboard: DashboardResponse?
    
    // Flattened properties for easier direct binding
    @Published var totalClubs: Int = 0
    @Published var totalMembers: Int = 0
    @Published var activeEvents: Int = 0
    @Published var engagementRate: Double = 0.0
    
    func fetchData() async {
        if isLoading { return }
        print("🔍 [AdminHomeViewModel] fetchData() started")
        isLoading = true
        errorMessage = nil
        
        do {
            print("🚀 [AdminHomeViewModel] Starting data fetch from AdminService...")
            async let s = AdminService.shared.getPlatformSummary()
            async let d = AdminService.shared.getDashboard()
            
            let (summaryResponse, dashboardResponse) = try await (s, d)
            print("✅ [AdminHomeViewModel] API Response Received!")
            print("📊 Platform Stats: Clubs=\(summaryResponse.total_clubs), Members=\(summaryResponse.total_members), Events=\(summaryResponse.active_events)")
            
            self.summary = summaryResponse
            self.dashboard = dashboardResponse
            
            // Explicitly signal change before updating flattened properties
            self.objectWillChange.send()
            
            self.totalClubs = summaryResponse.total_clubs
            self.totalMembers = summaryResponse.total_members
            self.activeEvents = summaryResponse.active_events
            self.engagementRate = summaryResponse.engagement_rate
            
            print("💾 [AdminHomeViewModel] Local state updated successfully.")
            self.lastUpdated = Date()
        } catch {
            print("❌ [AdminHomeViewModel] Error in fetchData: \(error.localizedDescription)")
            errorMessage = "Sync Error: \(error.localizedDescription)"
        }
        
        print("🏁 [AdminHomeViewModel] fetchData() finished. isLoading set to false.")
        isLoading = false
    }
}


// MARK: - President Dashboard
@MainActor
final class PresidentHomeViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var club: ClubResponse?
    @Published var lastUpdated = Date()
    @Published var health: ClubHealthResponse?
    @Published var events: [EventResponse] = []
    @Published var lowEngagementMembers: [LowEngagementMember] = []
    @Published var announcements: [AnnouncementResponse] = []
    @Published var pendingRequestCount: Int = 0 
    
    // Flattened properties for card binding
    @Published var totalMembers: Int = 0
    @Published var upcomingEventsCount: Int = 0
    @Published var engagementRate: Double = 0.0
    @Published var lowEngagementCount: Int = 0

    func fetchData(clubId: Int) async {
        if isLoading { return }
        print("🔍 [PresidentHomeViewModel] fetchData(clubId: \(clubId)) started")
        isLoading = true
        errorMessage = nil
        
        do {
            print("🚀 [PresidentHomeViewModel] Fetching data for club \(clubId)...")
            async let c = ClubService.shared.getClub(id: clubId)
            async let h = AnalyticsService.shared.getClubHealth(clubId: clubId)
            async let e = EventService.shared.getEvents(clubId: clubId)
            async let l = AnalyticsService.shared.getLowEngagementMembers(clubId: clubId)
            async let ann = AnnouncementService.shared.getAnnouncements(clubId: clubId)
            async let pending = JoinRequestService.shared.getPendingRequests(clubId: clubId)
            
            let (clubRes, healthRes, eventsList, lowEng, annList, pendingList) = try await (c, h, e, l, ann, pending)
            
            print("✅ [PresidentHomeViewModel] Data received successfully")
            
            // Filter events to only show upcoming ones (date >= today)
            let now = Date()
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withFullDate, .withDashSeparatorInDate, .withTime, .withColonSeparatorInTime]
            
            // Simplified date check: if we can't parse it, we keep it. 
            // If we can, we only keep it if it's today or in the future.
            let upcomingEvents = eventsList.filter { event in
                if let eventDate = formatter.date(from: event.date) {
                    // Set both to start of day for inclusive "today" check
                    let calendar = Calendar.current
                    let eventDay = calendar.startOfDay(for: eventDate)
                    let currentDay = calendar.startOfDay(for: now)
                    return eventDay >= currentDay
                }
                return true
            }
            
            // Signal change before updating state
            self.objectWillChange.send()
            
            self.club = clubRes
            self.health = healthRes
            self.events = upcomingEvents
            self.lowEngagementMembers = lowEng
            self.announcements = annList
            self.pendingRequestCount = pendingList.count
            
            // Map to flattened properties
            self.totalMembers = healthRes.total_members
            self.upcomingEventsCount = upcomingEvents.count
            self.engagementRate = healthRes.club_health_score // Use health score for 0-100% percentage
            self.lowEngagementCount = lowEng.count
            
            self.lastUpdated = Date()
            print("💾 [PresidentHomeViewModel] UI state updated. Health Score: \(healthRes.club_health_score)%")
        } catch {
            print("❌ [PresidentHomeViewModel] Error: \(error.localizedDescription)")
            errorMessage = "Sync Error: \(error.localizedDescription)"
        }
        
        isLoading = false
        print("🏁 [PresidentHomeViewModel] fetchData() finished")
    }
}

// MARK: - Secretary Dashboard
final class SecretaryHomeViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var club: ClubResponse?
    @Published var announcements: [AnnouncementResponse] = []
    @Published var documents: [DocumentResponse] = []
    @Published var summary: [String: Int] = [:]
    @Published var lastUpdated = Date()
    
    @MainActor
    func fetchData(clubId: Int) async {
        if isLoading { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            async let c = ClubService.shared.getClub(id: clubId)
            async let a = AnnouncementService.shared.getAnnouncements(clubId: clubId)
            async let d = DocumentService.shared.getDocuments(clubId: clubId)
            async let s: [String: Int] = APIClient.shared.request("/analytics/club/\(clubId)")
            
            let (club, ann, docs, sum) = try await (c, a, d, s)
            self.club = club
            self.announcements = ann
            self.documents = docs
            self.summary = sum
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}


// MARK: - Student Dashboard
final class StudentHomeViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var engagement: StudentEngagementResponse?
    @Published var myClubs: [ClubResponse] = []
    @Published var events: [EventResponse] = []
    
    @MainActor
    func fetchData(studentId: Int, clubId: Int?) async {
        if isLoading { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            let eng = try await AnalyticsService.shared.getStudentEngagement(studentId: studentId)
            self.engagement = eng
            
            // If the user just joined a club, we might get the clubId from the engagement response
            let effectiveClubId = clubId ?? eng.club_id
            
            if let cid = effectiveClubId {
                // Load only the student's own club and its events
                async let c = ClubService.shared.getClub(id: cid)
                async let ev = EventService.shared.getEvents(clubId: cid)
                let (club, clubEvents) = try await (c, ev)
                self.myClubs = [club]
                self.events = clubEvents
            } else {
                // No club yet — clear lists
                self.myClubs = []
                self.events = []
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
