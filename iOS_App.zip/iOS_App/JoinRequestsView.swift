import SwiftUI

struct JoinRequestsView: View {
    let clubId: Int

    @StateObject private var vm = JoinRequestViewModel()
    @Environment(\.dismiss) private var dismiss

    // Computed safe top
    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        VStack(spacing: 0) {
            // ── Custom Header ──────────────────────────────────────────────
            ZStack(alignment: .top) {
                LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                    .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                    .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

                VStack(alignment: .leading, spacing: 0) {
                    Color.clear.frame(height: safeTop + 8)
                    HStack(alignment: .center, spacing: 12) {
                        Button(action: { dismiss() }) {
                            ZStack {
                                Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                            }
                        }
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Join Requests").font(.title3).bold().foregroundColor(.white)
                            Text("Pending membership approvals")
                                .font(.caption).foregroundColor(.white.opacity(0.80)).lineLimit(1)
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 18).padding(.bottom, 22)
                }
            }
            .frame(height: safeTop + 92)

            ZStack {
                Color(UIColor.systemGroupedBackground).ignoresSafeArea()
                
                if vm.isLoading {
                    ProgressView("Loading requests...")
                } else if let err = vm.errorMessage {
                    VStack(spacing: 12) {
                        Image(systemName: "exclamationmark.triangle")
                            .font(.system(size: 40)).foregroundColor(.orange)
                        Text(err).font(.caption).foregroundColor(.secondary).multilineTextAlignment(.center)
                    }.padding()
                } else if vm.pendingRequests.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "tray")
                            .font(.system(size: 48))
                            .foregroundColor(.gray.opacity(0.5))
                        Text("No pending requests")
                            .font(.headline)
                            .foregroundColor(.secondary)
                    }
                } else {
                    ScrollView {
                        VStack(spacing: 16) {
                            ForEach(vm.pendingRequests) { req in
                                RequestCard(request: req, onApprove: {
                                    vm.approve(requestId: req.id, clubId: clubId)
                                }, onReject: {
                                    vm.reject(requestId: req.id, clubId: clubId)
                                })
                            }
                        }
                    }
                }
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .onAppear { vm.loadPending(clubId: clubId) }
    }
}


private struct RequestCard: View {
    let request: JoinRequestResponse
    let onApprove: () -> Void
    let onReject: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                ZStack {
                    Circle()
                        .fill(LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 44, height: 44)
                    Text(String((request.student_name ?? "U").prefix(1)).uppercased())
                        .font(.headline)
                        .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(request.student_name ?? "Unknown")
                        .font(.headline)
                        .foregroundColor(.primary)
                    Text(request.student_email ?? "")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                Spacer()
            }
            
            HStack(spacing: 12) {
                Button(action: onReject) {
                    Text("Reject")
                        .font(.subheadline).bold()
                        .foregroundColor(.red)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(10)
                }
                
                Button(action: onApprove) {
                    Text("Approve")
                        .font(.subheadline).bold()
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(LinearGradient(colors: [.green, Color(red: 0.1, green: 0.65, blue: 0.1)], startPoint: .leading, endPoint: .trailing))
                        .cornerRadius(10)
                }
            }
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}
