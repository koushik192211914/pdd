import SwiftUI

// MARK: - 3-Step OTP Password Reset
struct ForgotPasswordView: View {
    @Environment(\.dismiss) private var dismiss

    // Step tracking
    @State private var step: Step = .email

    // Field values
    @State private var email           = ""
    @State private var otp             = ""
    @State private var newPassword     = ""
    @State private var confirmPassword = ""
    @State private var isPasswordVisible = false

    // UI State
    @State private var isLoading    = false
    @State private var errorMsg: String?
    @State private var successMsg: String?

    enum Step { case email, otp, newPassword }

    private let bg = Color(red: 0.97, green: 0.97, blue: 0.98)

    var body: some View {
        ZStack {
            bg.ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    Spacer().frame(height: 32)
                    header
                    Spacer().frame(height: 24)
                    stepIndicator
                    Spacer().frame(height: 24)
                    formCard
                    if let err = errorMsg {
                        Text(err).font(.caption).foregroundColor(.red).padding(.top, 8).padding(.horizontal)
                    }
                    if let ok = successMsg {
                        Text(ok).font(.caption).foregroundColor(.green).padding(.top, 8).padding(.horizontal)
                    }
                    Spacer().frame(height: 20)
                    actionButton
                    Spacer().frame(height: 20)
                    backRow
                    Spacer().frame(height: 40)
                }
                .padding(.horizontal, 24)
            }
        }
        .navigationBarBackButtonHidden(true)
    }

    // MARK: - Header
    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(stepTitle).font(.system(size: 28, weight: .bold))
                .foregroundColor(Color(red: 0.08, green: 0.08, blue: 0.10))
            Text(stepSubtitle).font(.system(size: 14))
                .foregroundColor(Color(red: 0.50, green: 0.50, blue: 0.55))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var stepTitle: String {
        switch step {
        case .email:       return "Forgot Password"
        case .otp:         return "Enter OTP"
        case .newPassword: return "New Password"
        }
    }
    private var stepSubtitle: String {
        switch step {
        case .email:       return "Enter your registered email to receive an OTP"
        case .otp:         return "Enter the 6-digit code sent to \(email)"
        case .newPassword: return "Choose a strong new password"
        }
    }

    // MARK: - Step Dots
    private var stepIndicator: some View {
        HStack(spacing: 8) {
            ForEach(0..<3) { i in
                let current = step == .email ? 0 : step == .otp ? 1 : 2
                Circle()
                    .fill(i <= current ? Color.purple : Color.gray.opacity(0.3))
                    .frame(width: i == current ? 10 : 7, height: i == current ? 10 : 7)
                    .animation(.easeInOut, value: step)
            }
        }
    }

    // MARK: - Form Card
    private var formCard: some View {
        VStack(spacing: 16) {
            switch step {
            case .email:
                AuthTextField(title: "Email", placeholder: "your@email.com", text: $email, keyboardType: .emailAddress)
            case .otp:
                VStack(alignment: .leading, spacing: 6) {
                    Text("OTP Code").font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                    TextField("6-digit code", text: $otp)
                        .keyboardType(.numberPad)
                        .padding(14)
                        .background(Color(UIColor.systemBackground))
                        .cornerRadius(12)
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray.opacity(0.2)))
                        .font(.title2.monospacedDigit()).multilineTextAlignment(.center)
                }
            case .newPassword:
                AuthPasswordField(title: "New Password", placeholder: "min 6 characters", text: $newPassword, isVisible: $isPasswordVisible)
                AuthPasswordField(title: "Confirm Password", placeholder: "repeat password", text: $confirmPassword, isVisible: $isPasswordVisible)
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 18)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.06), radius: 16, x: 0, y: 4)
        )
    }

    // MARK: - Action Button
    private var actionButton: some View {
        Button {
            Task { await handleAction() }
        } label: {
            ZStack {
                if isLoading {
                    ProgressView().tint(.white)
                } else {
                    Text(actionLabel)
                        .font(.system(size: 17, weight: .semibold)).foregroundColor(.white)
                }
            }
            .frame(maxWidth: .infinity).frame(height: 54)
            .background(LinearGradient(colors: [Color(red: 0.47, green: 0.20, blue: 0.96), Color(red: 0.25, green: 0.50, blue: 1.0)],
                                       startPoint: .leading, endPoint: .trailing))
            .cornerRadius(16)
        }
        .disabled(isLoading)
    }

    private var actionLabel: String {
        switch step {
        case .email:       return "Send OTP"
        case .otp:         return "Verify OTP"
        case .newPassword: return "Reset Password"
        }
    }

    private var backRow: some View {
        Button { dismiss() } label: {
            HStack(spacing: 6) {
                Image(systemName: "arrow.left").font(.system(size: 13, weight: .semibold))
                Text("Back to log in").font(.system(size: 14, weight: .semibold))
            }
            .foregroundColor(Color(red: 0.50, green: 0.50, blue: 0.55))
        }
    }

    // MARK: - Actions
    private func handleAction() async {
        errorMsg = nil; successMsg = nil
        isLoading = true
        defer { isLoading = false }

        switch step {
        case .email:
            guard !email.trimmingCharacters(in: .whitespaces).isEmpty else {
                errorMsg = "Please enter your email."; return
            }
            await sendOTP()

        case .otp:
            guard otp.count == 6 else {
                errorMsg = "Enter the 6-digit OTP from your email."; return
            }
            await verifyOTP()

        case .newPassword:
            guard newPassword.count >= 6 else {
                errorMsg = "Password must be at least 6 characters."; return
            }
            guard newPassword == confirmPassword else {
                errorMsg = "Passwords do not match."; return
            }
            await resetPassword()
        }
    }

    private func sendOTP() async {
        do {
            struct Payload: Encodable { let email: String }
            let _: MessageResponse = try await APIClient.shared.request(
                "/auth/forgot-password", method: "POST", body: Payload(email: email)
            )
            successMsg = "OTP sent! Check your email."
            withAnimation { step = .otp }
        } catch {
            errorMsg = "Failed to send OTP. Please check the email address."
        }
    }

    private func verifyOTP() async {
        do {
            struct Payload: Encodable { let email: String; let code: String }
            let _: MessageResponse = try await APIClient.shared.request(
                "/auth/verify-otp", method: "POST", body: Payload(email: email, code: otp)
            )
            successMsg = "OTP verified!"
            withAnimation { step = .newPassword }
        } catch {
            errorMsg = "Invalid or expired OTP. Try again."
        }
    }

    private func resetPassword() async {
        do {
            struct Payload: Encodable { let email: String; let code: String; let new_password: String }
            let _: MessageResponse = try await APIClient.shared.request(
                "/auth/reset-password", method: "POST",
                body: Payload(email: email, code: otp, new_password: newPassword)
            )
            successMsg = "Password reset successfully! Logging you in..."
            try? await Task.sleep(nanoseconds: 1_500_000_000)
            dismiss()
        } catch {
            errorMsg = "Failed to reset password. Please start over."
        }
    }
}

#Preview {
    PreviewWrapper {
        ForgotPasswordView()
    }
}
