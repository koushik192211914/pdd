from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from database import get_db
import models
import schemas
from core.permissions import require_admin, require_authority, get_current_user

router = APIRouter(
    prefix="/clubs",
    tags=["Clubs"]
)

@router.post("", response_model=schemas.ClubResponse)
def create_club(club: schemas.ClubCreate, db: Session = Depends(get_db)):
    db_club = db.query(models.Club).filter(models.Club.club_name == club.club_name).first()
    if db_club:
        raise HTTPException(status_code=400, detail="Club already exists")
    
    # Use User ID 1 for now as per instructions
    user_id = 1
    new_club = models.Club(
        club_name=club.club_name,
        category=club.category,
        description=club.description,
        created_by=user_id
    )
    db.add(new_club)
    db.commit()
    db.refresh(new_club)
    return new_club

@router.get("", response_model=List[schemas.ClubResponse])
def get_all_clubs(db: Session = Depends(get_db)):
    clubs = db.query(models.Club).all()
    return clubs

@router.get("/{club_id}", response_model=schemas.ClubResponse)
def get_club(club_id: int, db: Session = Depends(get_db)):
    club = db.query(models.Club).filter(models.Club.id == club_id).first()
    if not club:
        raise HTTPException(status_code=404, detail="Club not found")
    return club

@router.get("/{club_id}/stats")
def get_club_stats(club_id: int, db: Session = Depends(get_db)):
    club = db.query(models.Club).filter(models.Club.id == club_id).first()
    if not club:
        raise HTTPException(status_code=404, detail="Club not found")
    total_members = db.query(models.ClubMember).join(
        models.User, models.ClubMember.student_id == models.User.id
    ).filter(
        models.ClubMember.club_id == club_id,
        models.User.role == "Student"
    ).count()
    total_events = db.query(models.Event).filter(models.Event.club_id == club_id).count()

    # Calculate engagement rate (simple logic: active participants / total members)
    engagement_rate = 0.0
    if total_members > 0:
        # Get all members in this club
        members = db.query(models.ClubMember.student_id).filter(models.ClubMember.club_id == club_id).all()
        member_ids = [m[0] for m in members]
        
        engagement_sum = 0.0
        for sid in member_ids:
            reg_count = db.query(models.EventRegistration).filter(models.EventRegistration.student_id == sid).count()
            att_count = db.query(models.EventAttendance).filter(models.EventAttendance.student_id == sid, models.EventAttendance.status == "Present").count()
            engagement_sum += (reg_count + att_count)
            
        avg_engagement = engagement_sum / total_members
        # Convert to percentage and cap at 100%
        engagement_rate = min(avg_engagement * 10, 100.0)

    return {
        "total_members": total_members,
        "total_events": total_events,
        "engagement_rate": f"{int(engagement_rate)}%"
    }

@router.put("/{club_id}", response_model=schemas.ClubResponse)
def update_club(club_id: int, club_update: schemas.ClubCreate, db: Session = Depends(get_db), admin_user: models.User = Depends(require_authority)):
    club = db.query(models.Club).filter(models.Club.id == club_id).first()
    if not club:
        raise HTTPException(status_code=404, detail="Club not found")
    
    club.club_name = club_update.club_name
    club.category = club_update.category
    club.description = club_update.description
    db.commit()
    db.refresh(club)
    return club

@router.delete("/{club_id}")
def delete_club(club_id: int, db: Session = Depends(get_db), admin_user: models.User = Depends(require_admin)):
    club = db.query(models.Club).filter(models.Club.id == club_id).first()
    if not club:
        raise HTTPException(status_code=404, detail="Club not found")
    
    # Demote Club Authorities back to Student before deleting their memberships
    members = db.query(models.ClubMember).filter(models.ClubMember.club_id == club_id).all()
    member_ids = [m.student_id for m in members]
    if member_ids:
        db.query(models.User).filter(
            models.User.id.in_(member_ids),
            models.User.role.in_(["President", "VicePresident", "Secretary", "Treasurer"])
        ).update({"role": "Student"}, synchronize_session=False)

    # Manual Cascading Cleanup
    db.query(models.ClubMember).filter(models.ClubMember.club_id == club_id).delete(synchronize_session=False)
    db.query(models.ClubJoinRequest).filter(models.ClubJoinRequest.club_id == club_id).delete(synchronize_session=False)
    db.query(models.ClubDocument).filter(models.ClubDocument.club_id == club_id).delete(synchronize_session=False)
    
    # Newly added cascading deletes for new modules
    db.query(models.Announcement).filter(models.Announcement.club_id == club_id).delete(synchronize_session=False)
    db.query(models.Budget).filter(models.Budget.club_id == club_id).delete(synchronize_session=False)
    db.query(models.Expense).filter(models.Expense.club_id == club_id).delete(synchronize_session=False)
    
    sessions = db.query(models.ClubAttendanceSession).filter(models.ClubAttendanceSession.club_id == club_id).all()
    session_ids = [s.id for s in sessions]
    if session_ids:
        db.query(models.ClubAttendanceRecord).filter(models.ClubAttendanceRecord.session_id.in_(session_ids)).delete(synchronize_session=False)
        db.query(models.ClubAttendanceSession).filter(models.ClubAttendanceSession.club_id == club_id).delete(synchronize_session=False)
    
    events = db.query(models.Event).filter(models.Event.club_id == club_id).all()
    event_ids = [e.id for e in events]
    if event_ids:
        db.query(models.EventRegistration).filter(models.EventRegistration.event_id.in_(event_ids)).delete(synchronize_session=False)
        db.query(models.EventAttendance).filter(models.EventAttendance.event_id.in_(event_ids)).delete(synchronize_session=False)
        db.query(models.EventSubstitution).filter(models.EventSubstitution.event_id.in_(event_ids)).delete(synchronize_session=False)
        db.query(models.Event).filter(models.Event.club_id == club_id).delete(synchronize_session=False)

    db.delete(club)
    db.commit()
    return {"message": "Club deleted successfully"}
