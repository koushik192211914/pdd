import Foundation
import Combine

@MainActor
final class NotificationViewModel: ObservableObject {
    @Published var notifications: [UserNotification] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    func load(userId: Int, role: String = "Student") {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                notifications = try await NotificationService.shared.getNotifications(userId: userId, role: role)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func markRead(_ notification: UserNotification) {
        Task {
            try? await NotificationService.shared.markRead(notificationId: notification.id)
            if let idx = notifications.firstIndex(where: { $0.id == notification.id }) {
                notifications.remove(at: idx)
            }
        }
    }
    func clearAll(userId: Int, role: String) {
        Task {
            isLoading = true
            defer { isLoading = false }
            do {
                try await NotificationService.shared.markAllRead(userId: userId, role: role)
                notifications.removeAll()
            } catch {
                errorMessage = "Failed to clear notifications"
            }
        }
    }
}

