//
//  ClubService.swift
//  CLUB ANALYTICSs
//
//  GET /clubs  |  GET /clubs/{id}  |  POST /clubs/create
//

import Foundation

struct ClubCreateRequest: Encodable {
    let name: String
    let category: String
    let description: String
    let instagram_url: String?

    enum CodingKeys: String, CodingKey {
        case category, description, instagram_url
        case name = "club_name"
    }
}

final class ClubService {
    static let shared = ClubService()
    private init() {}

    func getClubs() async throws -> [ClubResponse] {
        return try await APIClient.shared.request("/clubs")
    }

    func getClub(id: Int) async throws -> ClubResponse {
        return try await APIClient.shared.request("/clubs/\(id)")
    }

    func deleteClub(id: Int) async throws -> MessageResponse {
        return try await APIClient.shared.request("/clubs/\(id)", method: "DELETE")
    }

    func createClub(name: String, category: String = "Technology", description: String, instagramUrl: String? = nil) async throws -> ClubResponse {
        let body = ClubCreateRequest(name: name, category: category, description: description, instagram_url: instagramUrl)
        return try await APIClient.shared.request("/clubs", method: "POST", body: body)
    }

    func getMembers(clubId: Int) async throws -> [ClubMemberItem] {
        return try await APIClient.shared.request("/club-members/\(clubId)/members")
    }

    func removeMember(studentId: Int, clubId: Int) async throws {
        let _: MessageResponse = try await APIClient.shared.request(
            "/club-members/leave/\(studentId)?club_id=\(clubId)",
            method: "DELETE"
        )
    }
}

