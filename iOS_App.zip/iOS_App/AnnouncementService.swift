//
//  AnnouncementService.swift
//  CLUB ANALYTICSs
//
//  GET /announcements/{club_id}  |  POST /announcements/
//

import Foundation

final class AnnouncementService {
    static let shared = AnnouncementService()
    private init() {}

    func getAnnouncements(clubId: Int) async throws -> [AnnouncementResponse] {
        return try await APIClient.shared.request("/announcements/\(clubId)")
    }

    func postAnnouncement(title: String, content: String, clubId: Int) async throws -> AnnouncementResponse {
        let request = AnnouncementCreate(title: title, content: content, club_id: clubId)
        return try await APIClient.shared.request("/announcements/", method: "POST", body: request)
    }
}
