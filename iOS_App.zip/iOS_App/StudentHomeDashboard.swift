//
//  StudentHomeDashboard.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Student Dashboard (view-only, no admin actions)
//

import SwiftUI

// MARK: - Student Home Dashboard
struct StudentHomeDashboard: View {
    @ObservedObject var viewModel: StudentHomeViewModel
    @EnvironmentObject private var authManager: AuthManager
    
    var onViewEvents: (() -> Void)? = nil

    @EnvironmentObject private var store: AttendanceNotificationStore
    
    @State private var successEventName: String? = nil

    var body: some View {
        ZStack(alignment: .top) {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    
                    // ── HEADER + STAT CARDS ──────────────────────────────────────
                    RoleDashboardHeader(
                        role: .student,
                        roleTitle: "Welcome, Student",
                        subtitle:  "Let's make today productive",
                        stats: [
                            DashboardStat(title: "My Score",       value: "\(viewModel.engagement?.engagement_score ?? 0)",  icon: "star.fill"),
                            DashboardStat(title: "Events Attended",value: "\(viewModel.engagement?.events_attended ?? 0)",  icon: "calendar.badge.checkmark"),
                            DashboardStat(title: "Clubs Joined",   value: "\(viewModel.engagement?.clubs_joined ?? 0)",   icon: "building.2.fill"),
                            DashboardStat(title: "Achievements",   value: "\(viewModel.engagement?.events_attended ?? 0 > 0 ? 1 : 0)",   icon: "trophy.fill")
                        ]
                    )

                    VStack(spacing: 32) {
                        if viewModel.isLoading {
                            ProgressView("Loading Dashboard...")
                                .padding(.top, 40)
                        } else if let err = viewModel.errorMessage {
                            Text(err).foregroundColor(.red).padding(.top, 40)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                        } else if let data = viewModel.engagement, data.clubs_joined == 0 {
                            // ── EMPTY STATE ───────────────────────────────────────
                            VStack(spacing: 16) {
                                Image(systemName: "person.2.slash")
                                    .font(.system(size: 54))
                                    .foregroundColor(.secondary)
                                Text("You're new here! Join a club to get started 🚀")
                                    .font(.title3).fontWeight(.semibold)
                                    .foregroundColor(.primary)
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal)
                            }
                            .padding(.vertical, 60)
                            
                        } else {
                            // ── PARTICIPATION SCORE ──────────────────────────────────
                            if let data = viewModel.engagement {
                                StudentParticipationCard(score: data.engagement_score)
                            }

                            // ── MY CLUBS ──────────────────────────────────────────────
                            StudentMyClubsSection(viewModel: viewModel)

                            // ── UPCOMING EVENTS ──────────────────────────────────────
                            StudentUpcomingEventsSection(
                                viewModel: viewModel,
                                onViewEvents: onViewEvents,
                                onRegister: { title in
                                    register(for: title)
                                }
                            )

                            // ── ACHIEVEMENTS ─────────────────────────────────────────
                            StudentAchievementsSection(engagement: viewModel.engagement)

                            // ── CLUB PARTICIPATION ───────────────────────────────────
                            if let data = viewModel.engagement {
                                StudentClubParticipationSection(
                                    eventsAttended: data.events_attended,
                                    partLevel: min(data.engagement_score, 100),
                                    clubsJoined: data.clubs_joined
                                )
                            }
                        }
                    }
                    .padding(.top, 24)
                    .padding(.bottom, 100)
                }
            }
            .ignoresSafeArea(edges: .top)
            .background(Color(UIColor.systemGroupedBackground))
            .task {
                if let studentId = authManager.userId {
                    await viewModel.fetchData(studentId: studentId, clubId: authManager.clubId)
                }
            }
            
            // ── Success toast ─────────────────────────────────────────────────
            if successEventName != nil {
                VStack {
                    Spacer()
                    HStack(spacing: 12) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 22))
                            .foregroundColor(.green)
                        Text("Successfully Registered")
                            .font(.subheadline).fontWeight(.semibold)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 14)
                    .background(.ultraThinMaterial)
                    .cornerRadius(16)
                    .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)
                    .padding(.bottom, 32)
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .zIndex(1)
            }
        }
    }
    
    
    private func register(for title: String) {
        store.registerForEvent(title)
        withAnimation(.easeInOut) { successEventName = title }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            withAnimation(.easeInOut) { successEventName = nil }
        }
    }
}


// MARK: - Participation Score Card
private struct StudentParticipationCard: View {
    let score: Int
    private var normalizedScore: Double { return min(Double(score) / 100.0, 1.0) }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Your Participation Score")
                        .font(.headline).fontWeight(.semibold)
                    Text("Keep it up! You're doing great")
                        .font(.caption).foregroundColor(.secondary)
                }
                Spacer()
                // Score badge
                ZStack {
                    Circle()
                        .trim(from: 0, to: CGFloat(normalizedScore))
                        .stroke(
                            LinearGradient(colors: [.purple, .blue],
                                           startPoint: .topLeading, endPoint: .bottomTrailing),
                            style: StrokeStyle(lineWidth: 8, lineCap: .round)
                        )
                        .rotationEffect(.degrees(-90))
                        .frame(width: 64, height: 64)
                    VStack(spacing: 0) {
                        Text("\(score)").font(.system(size: 18, weight: .bold))
                        Text("/ 100").font(.caption2).foregroundColor(.secondary)
                    }
                }
            }

            // Progress bar
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text("Engagement level").font(.caption).foregroundColor(.secondary)
                    Spacer()
                    Text("\(min(score, 100))%").font(.caption).fontWeight(.bold).foregroundColor(.purple)
                }
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        RoundedRectangle(cornerRadius: 6).fill(Color.purple.opacity(0.12)).frame(height: 10)
                        RoundedRectangle(cornerRadius: 6)
                            .fill(LinearGradient(colors: [.purple, .blue],
                                                 startPoint: .leading, endPoint: .trailing))
                            .frame(width: geo.size.width * CGFloat(normalizedScore), height: 10)
                    }
                }
                .frame(height: 10)
            }
        }
        .padding(18)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
        .padding(.horizontal)
    }
}

// MARK: - My Clubs Section
private struct StudentMyClubsSection: View {
    @ObservedObject var viewModel: StudentHomeViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeaderRow(title: "My Clubs", showViewAll: true)
            
            if viewModel.myClubs.isEmpty {
                Text("Not a member of any club yet.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .padding(.horizontal)
            } else {
                VStack(spacing: 12) {
                    ForEach(viewModel.myClubs.prefix(2)) { club in
                        StudentClubCard(
                            clubName: club.name,
                            memberRole: "Member",
                            joinDate: "Active Member",
                            color: .purple
                        )
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

private struct StudentClubCard: View {
    let clubName: String; let memberRole: String; let joinDate: String; let color: Color

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(LinearGradient(colors: [color, color.opacity(0.65)],
                                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 46, height: 46)
                Image(systemName: "building.2.fill")
                    .font(.system(size: 20)).foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(clubName).font(.subheadline).fontWeight(.semibold)
                Text(memberRole)
                    .font(.caption2).fontWeight(.semibold)
                    .foregroundColor(color)
                    .padding(.horizontal, 8).padding(.vertical, 3)
                    .background(color.opacity(0.10)).clipShape(Capsule())
                Text(joinDate).font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(Color(UIColor.tertiaryLabel))
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Upcoming Events Section (live API data)
private struct StudentUpcomingEventsSection: View {
    @ObservedObject var viewModel: StudentHomeViewModel
    var onViewEvents: (() -> Void)?
    var onRegister: ((String) -> Void)?

    @EnvironmentObject private var store: AttendanceNotificationStore

    private func parseDate(_ str: String) -> Date? {
        let f1 = ISO8601DateFormatter()
        f1.formatOptions = [.withInternetDateTime]
        if let d = f1.date(from: str) { return d }
        let f2 = DateFormatter()
        f2.locale = Locale(identifier: "en_US_POSIX")
        f2.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        return f2.date(from: str)
    }

    private var upcomingEvents: [EventResponse] {
        let now = Date()
        return viewModel.events.filter { ev in
            (parseDate(ev.date) ?? .distantPast) >= now
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeaderRow(title: "Upcoming Events", showViewAll: true)

            if upcomingEvents.isEmpty {
                Text("No upcoming events for your club.")
                    .font(.caption).foregroundColor(.secondary).padding(.horizontal)
            } else {
                VStack(spacing: 12) {
                    ForEach(Array(upcomingEvents.prefix(3))) { event in
                        eventRow(event)
                    }
                }
                .padding(.horizontal)
            }
        }
    }

    @ViewBuilder
    private func eventRow(_ event: EventResponse) -> some View {
        let dateObj = parseDate(event.date)
        
        let monthStr: String = {
            let fmt = DateFormatter()
            fmt.dateFormat = "MMM"
            return dateObj.map { fmt.string(from: $0).uppercased() } ?? "--"
        }()
        
        let dayStr: String = {
            let fmt = DateFormatter()
            fmt.dateFormat = "d"
            return dateObj.map { fmt.string(from: $0) } ?? "--"
        }()
        
        StudentEventCard(
            name: event.title,
            month: monthStr,
            day: dayStr,
            club: event.description ?? "",
            isRegistered: store.registeredEventTitles.contains(event.title),
            onRegister: { onRegister?(event.title) }
        )
    }
}


private struct StudentEventCard: View {
    let name: String; let month: String; let day: String; let club: String
    let isRegistered: Bool
    let onRegister: () -> Void

    var body: some View {
        HStack(spacing: 14) {
            // Date block
            VStack(spacing: 2) {
                Text(month).font(.caption2).fontWeight(.bold).foregroundColor(.purple)
                Text(day)
                    .font(.title3).fontWeight(.bold)
            }
            .frame(width: 50, height: 50)
            .background(Color.purple.opacity(0.09))
            .cornerRadius(12)

            VStack(alignment: .leading, spacing: 4) {
                Text(name).font(.subheadline).fontWeight(.semibold)
                HStack(spacing: 4) {
                    Image(systemName: "building.2").font(.caption2).foregroundColor(.secondary)
                    Text(club).font(.caption).foregroundColor(.secondary)
                }
            }
            Spacer()
            
            // Register button
            Button(action: onRegister) {
                if isRegistered {
                    Label("Registered", systemImage: "checkmark")
                        .font(.caption).fontWeight(.bold)
                        .foregroundColor(.green)
                        .padding(.horizontal, 10).padding(.vertical, 7)
                        .background(Color.green.opacity(0.12))
                        .clipShape(Capsule())
                } else {
                    Text("Register")
                        .font(.caption).fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.horizontal, 12).padding(.vertical, 7)
                        .background(Color.purple)
                        .clipShape(Capsule())
                }
            }
            .disabled(isRegistered)
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Achievements Section (2×2 grid)
private struct StudentAchievementsSection: View {
    let engagement: StudentEngagementResponse?

    private var items: [(String, String, String, Color)] {
        guard let eng = engagement else { return [] }
        var list: [(String, String, String, Color)] = []
        
        if eng.events_attended >= 10 {
            list.append(("trophy.fill", "Event Champion", "Attended 10+ events", .orange))
        }
        if eng.engagement_score > 60 {
            list.append(("star.fill", "Active Member", "Score > 60", .purple))
        }
        if eng.engagement_score > 85 {
            list.append(("flag.checkered", "High Achiever", "Score > 85", .green))
        }
        if eng.clubs_joined >= 2 {
            list.append(("building.2.fill", "Club Enthusiast", "Joined 2+ clubs", .blue))
        }
        
        // Add placeholders if less than 4, but grayed out
        let placeholders: [(String, String, String, Color)] = [
            ("trophy", "Event Champion", "Attend 10+ events", .gray),
            ("star", "Active Member", "Reach 60 score", .gray),
            ("flag", "High Achiever", "Reach 85 score", .gray),
            ("building.2", "Club Enthusiast", "Join 2+ clubs", .gray)
        ]
        
        var finalList = list
        for p in placeholders {
            if finalList.count < 4 && !finalList.contains(where: { $0.1 == p.1 }) {
                finalList.append(p)
            }
        }
        return Array(finalList.prefix(4))
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeaderRow(title: "Achievements")
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)],
                      spacing: 14) {
                ForEach(items, id: \.1) { item in
                    AchievementCard(icon: item.0, title: item.1, detail: item.2, color: item.3)
                }
            }
            .padding(.horizontal)
        }
    }
}

private struct AchievementCard: View {
    let icon: String; let title: String; let detail: String; let color: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(color.opacity(0.13)).frame(width: 40, height: 40)
                Image(systemName: icon).font(.system(size: 18)).foregroundColor(color)
            }
            Text(title).font(.subheadline).fontWeight(.semibold)
            Text(detail).font(.caption).foregroundColor(.secondary).lineLimit(2)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Club Participation Section
private struct StudentClubParticipationSection: View {
    let eventsAttended: Int
    let partLevel: Int
    let clubsJoined: Int

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeaderRow(title: "Club Participation")
            HStack(spacing: 14) {
                ParticipationStat(value: "\(eventsAttended)", label: "Events Attended", icon: "calendar.badge.checkmark", color: .purple)
                ParticipationStat(value: "\(clubsJoined)",  label: "Clubs Joined", icon: "folder.badge.plus",        color: .blue)
                ParticipationStat(value: "\(partLevel)%",label: "Part. Level",     icon: "chart.line.uptrend.xyaxis", color: .green)
            }
            .padding(.horizontal)
        }
    }
}

private struct ParticipationStat: View {
    let value: String; let label: String; let icon: String; let color: Color

    var body: some View {
        VStack(spacing: 8) {
            ZStack {
                Circle().fill(color.opacity(0.12)).frame(width: 44, height: 44)
                Image(systemName: icon).font(.system(size: 18)).foregroundColor(color)
            }
            Text(value).font(.title3).bold()
            Text(label).font(.caption2).foregroundColor(.secondary).multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
    NavigationStack { StudentHomeDashboard(viewModel: StudentHomeViewModel()) }
        .environmentObject(AttendanceNotificationStore())
        .environmentObject(AuthManager.shared)
    }
}
