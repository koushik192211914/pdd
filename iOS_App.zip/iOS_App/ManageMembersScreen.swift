import SwiftUI

struct ManageMembersScreen: View {
    let clubId: Int
    @Environment(\.dismiss) private var dismiss
    @State private var members: [ClubMemberItem] = []
    @State private var isLoading = true
    @State private var errorMessage: String?
    
    @State private var selectedMember: ClubMemberItem?
    @State private var showDeleteAlert = false
    @State private var isRemoving = false

    // Computed safe top
    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        VStack(spacing: 0) {
            // ── Custom Header ──────────────────────────────────────────────
            ZStack(alignment: .top) {
                LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                    .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                    .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

                VStack(alignment: .leading, spacing: 0) {
                    Color.clear.frame(height: safeTop + 8)
                    HStack(alignment: .center, spacing: 12) {
                        Button(action: { dismiss() }) {
                            ZStack {
                                Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                            }
                        }
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Manage Members").font(.title3).bold().foregroundColor(.white)
                            Text("Remove students from your club")
                                .font(.caption).foregroundColor(.white.opacity(0.80)).lineLimit(1)
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 18).padding(.bottom, 22)
                }
            }
            .frame(height: safeTop + 92)

            ZStack {
                Color(UIColor.systemGroupedBackground).ignoresSafeArea()
                
                if isLoading {
                    ProgressView("Loading members...")
                } else if let err = errorMessage {
                    VStack(spacing: 12) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.system(size: 40)).foregroundColor(.orange)
                        Text(err).font(.subheadline).foregroundColor(.secondary).multilineTextAlignment(.center)
                        Button("Retry") { Task { await loadMembers() } }
                            .padding(.top, 8)
                    }.padding()
                } else if members.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "person.2.slash.fill")
                            .font(.system(size: 48))
                            .foregroundColor(.gray.opacity(0.5))
                        Text("No members found")
                            .font(.headline)
                            .foregroundColor(.secondary)
                    }
                } else {
                    List {
                        ForEach(members) { member in
                            MemberRow(member: member) {
                                selectedMember = member
                                showDeleteAlert = true
                            }
                        }
                        .listRowBackground(Color(UIColor.secondarySystemGroupedBackground))
                    }
                    .listStyle(.insetGrouped)
                }
            }
        }
        .ignoresSafeArea(edges: .top)
        .navigationBarHidden(true)
        .alert("Remove Member?", isPresented: $showDeleteAlert, presenting: selectedMember) { member in
            Button("Cancel", role: .cancel) { }
            if member.role.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == "student" {
                Button("Remove", role: .destructive) {
                    Task { await removeMember(member) }
                }
            }
        } message: { member in
            if member.role.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == "student" {
                Text("Are you sure you want to remove \(member.name) from the club? They will be able to join other clubs after removal.")
            } else {
                Text("You cannot remove \(member.name) because they hold a leadership role (\(member.role)). Only regular students can be removed by the President.")
            }
        }
        .overlay {
            if isRemoving {
                ZStack {
                    Color.black.opacity(0.2).ignoresSafeArea()
                    ProgressView("Removing...").padding().background(.ultraThinMaterial).cornerRadius(12)
                }
            }
        }
        .task { await loadMembers() }
    }

    private func loadMembers() async {
        isLoading = true
        errorMessage = nil
        do {
            members = try await ClubService.shared.getMembers(clubId: clubId)
            // Note: If you want to filter for ONLY "Student" role as mentioned:
            // members = members.filter { $0.role == "Student" }
            // But usually the President should see ALL members to manage.
            // I'll keep all but you can filter if strictly necessary.
            isLoading = false
        } catch {
            errorMessage = error.localizedDescription
            isLoading = false
        }
    }

    private func removeMember(_ member: ClubMemberItem) async {
        // Double-check role before calling API
        guard member.role.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == "student" else {
            errorMessage = "Cannot remove leadership roles."
            return
        }
        
        isRemoving = true
        do {
            try await ClubService.shared.removeMember(studentId: member.id, clubId: clubId)
            await MainActor.run {
                members.removeAll { $0.id == member.id }
                isRemoving = false
            }
        } catch {
            await MainActor.run {
                errorMessage = "Failed to remove: \(error.localizedDescription)"
                isRemoving = false
            }
        }
    }
}

private struct MemberRow: View {
    let member: ClubMemberItem
    let onRemove: () -> Void
    
    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 44, height: 44)
                Text(String(member.name.prefix(1)).uppercased())
                    .font(.headline)
                    .foregroundColor(.white)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(member.name)
                    .font(.subheadline).bold()
                    .foregroundColor(.primary)
                Text(member.role)
                    .font(.caption).fontWeight(.semibold)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            if member.role.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == "student" {
                Button(action: onRemove) {
                    Image(systemName: "person.badge.minus.fill")
                        .font(.system(size: 20))
                        .foregroundColor(.red.opacity(0.8))
                }
                .buttonStyle(PlainButtonStyle())
            }
        }
        .padding(.vertical, 4)
    }
}
