from fastapi import FastAPI, Depends
from sqlalchemy import text
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import models
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

from database import engine, Base, get_db
from routes.auth import router as auth_router
from routes.clubs import router as clubs_router
from routes.events import router as events_router
from routes.registrations import router as registrations_router
from routes.event_attendance import router as event_attendance_router
from routes.substitutions import router as substitutions_router
from routes.club_members import router as club_members_router
from routes.club_attendance import router as club_attendance_router
from routes.analytics import router as analytics_router
from routes import notifications
from routes import documents
from routes import admin
from routes import club_requests
from routes import finance
from routes import member_management
from routes import recommendations
from routes import system_audit
from routes import engagement
from routes import announcements
from routes import users
from routes import otp as otp_router
from routes.attendance import router as attendance_router

# ── Create DB tables on startup ───────────────────────────────────────────────
print("DEBUG: Checking/Creating database tables...")
Base.metadata.create_all(bind=engine)
print("DEBUG: Database tables verified.")

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="ClubSphere AI API",
    description="Backend API for the ClubSphere AI iOS application.",
    version="1.0.0",
)

# CORS – allow all origins during development
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173", 
        "http://127.0.0.1:5173", 
        "*"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(auth_router)
app.include_router(clubs_router)
app.include_router(events_router)
app.include_router(registrations_router)
app.include_router(event_attendance_router)
app.include_router(substitutions_router)
app.include_router(club_members_router)
app.include_router(club_attendance_router)
app.include_router(analytics_router)
app.include_router(attendance_router)

@app.get("/dashboard", tags=["Dashboard"])
def get_global_dashboard(db: Session = Depends(get_db)):
    from routes.analytics import get_dashboard_data
    return get_dashboard_data(db)
app.include_router(notifications.router)
app.include_router(documents.router)
app.include_router(admin.router)
app.include_router(club_requests.router)
app.include_router(finance.router)
app.include_router(member_management.router)
app.include_router(recommendations.router)
app.include_router(system_audit.router)
app.include_router(engagement.router)
app.include_router(announcements.router)
app.include_router(users.router)
app.include_router(otp_router.router)

@app.get("/", tags=["Health"])
def root():
    return {"status": "ok", "app": "ClubSphere AI API"}

@app.get("/ping", tags=["Health"])
def ping():
    return {"status": "alive"}

@app.get("/health", tags=["Health"])
def health_check(db: Session = Depends(get_db)):
    try:
        # Execute a simple query to check DB connectivity
        db.execute(text("SELECT 1"))
        return {"status": "healthy", "database": "connected"}
    except Exception as e:
        return {"status": "unhealthy", "database": str(e)}

@app.get("/debug/all", tags=["Debug"])
def debug_all(db: Session = Depends(get_db)):
    return {
        "clubs": db.query(models.Club).all(),
        "events": db.query(models.Event).all()
    }

if __name__ == "__main__":
    import uvicorn
    print("DEBUG: Starting uvicorn on http://127.0.0.1:8000")
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
