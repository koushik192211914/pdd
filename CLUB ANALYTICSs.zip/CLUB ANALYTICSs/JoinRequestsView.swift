import SwiftUI

struct JoinRequestsView: View {
    let clubId: Int

    @StateObject private var vm = JoinRequestViewModel()
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            ZStack {
                Color(UIColor.systemGroupedBackground).ignoresSafeArea()

                if vm.isLoading {
                    ProgressView("Loading requests...")
                } else if let err = vm.errorMessage {
                    VStack(spacing: 12) {
                        Image(systemName: "exclamationmark.triangle")
                            .font(.system(size: 40)).foregroundColor(.orange)
                        Text(err).font(.caption).foregroundColor(.secondary).multilineTextAlignment(.center)
                    }.padding()
                } else if vm.pendingRequests.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "tray")
                            .font(.system(size: 48))
                            .foregroundColor(.gray.opacity(0.5))
                        Text("No pending requests")
                            .font(.headline)
                            .foregroundColor(.secondary)
                    }
                } else {
                    ScrollView {
                        VStack(spacing: 16) {
                            ForEach(vm.pendingRequests) { req in
                                RequestCard(request: req, onApprove: {
                                    vm.approve(requestId: req.id, clubId: clubId)
                                }, onReject: {
                                    vm.reject(requestId: req.id, clubId: clubId)
                                }
                                )
    }
                        }
                        .padding()
                    }
                }
            }
            .navigationTitle("Join Requests")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Close") { dismiss() }
                }
            }
            .onAppear { vm.loadPending(clubId: clubId) }
        }
    }
}


private struct RequestCard: View {
    let request: JoinRequestResponse
    let onApprove: () -> Void
    let onReject: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                ZStack {
                    Circle()
                        .fill(LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 44, height: 44)
                    Text(String((request.student_name ?? "U").prefix(1)).uppercased())
                        .font(.headline)
                        .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(request.student_name ?? "Unknown")
                        .font(.headline)
                        .foregroundColor(.primary)
                    Text(request.student_email ?? "")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                Spacer()
            }
            
            HStack(spacing: 12) {
                Button(action: onReject) {
                    Text("Reject")
                        .font(.subheadline).bold()
                        .foregroundColor(.red)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(10)
                }
                
                Button(action: onApprove) {
                    Text("Approve")
                        .font(.subheadline).bold()
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(LinearGradient(colors: [.green, Color(red: 0.1, green: 0.65, blue: 0.1)], startPoint: .leading, endPoint: .trailing))
                        .cornerRadius(10)
                }
            }
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}
