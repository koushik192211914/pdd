from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
import models, schemas
from typing import List
from core.permissions import require_authority, require_student

router = APIRouter(prefix="/club-requests", tags=["Club Requests"])

@router.post("/send", response_model=schemas.MessageResponse)
def send_join_request(payload: schemas.JoinRequestCreate, db: Session = Depends(get_db), student_user: models.User = Depends(require_student)):
    student = db.query(models.User).filter(models.User.id == payload.student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
        
    club = db.query(models.Club).filter(models.Club.id == payload.club_id).first()
    if not club:
        raise HTTPException(status_code=404, detail="Club not found")

    # One-club-per-student rule: block if already a member of any club
    already_member = db.query(models.ClubMember).filter(
        models.ClubMember.student_id == payload.student_id
    ).first()
    if already_member:
        raise HTTPException(status_code=400, detail="You are already a member of a club. A student can only belong to one club.")

    existing_req = db.query(models.ClubJoinRequest).filter(
        models.ClubJoinRequest.student_id == payload.student_id,
        models.ClubJoinRequest.club_id == payload.club_id,
        models.ClubJoinRequest.status == models.JoinRequestStatus.Pending
    ).first()
    if existing_req:
        raise HTTPException(status_code=400, detail="Pending request already exists")

    existing_member = db.query(models.ClubMember).filter(
        models.ClubMember.club_id == payload.club_id,
        models.ClubMember.student_id == payload.student_id
    ).first()
    if existing_member:
        raise HTTPException(status_code=400, detail="Student is already a member of this club")

    new_request = models.ClubJoinRequest(
        student_id=payload.student_id,
        club_id=payload.club_id,
        status=models.JoinRequestStatus.Pending
    )
    db.add(new_request)
    db.commit()
    return schemas.MessageResponse(message="Join request sent successfully")


@router.get("/{club_id}")
def get_pending_requests(club_id: int, db: Session = Depends(get_db), auth_user: models.User = Depends(require_authority)):
    # To help SwiftUI display student name and email, we return an extended dictionary.
    requests = db.query(models.ClubJoinRequest).filter(
        models.ClubJoinRequest.club_id == club_id,
        models.ClubJoinRequest.status == models.JoinRequestStatus.Pending
    ).all()
    
    response = []
    for req in requests:
        user = db.query(models.User).filter(models.User.id == req.student_id).first()
        response.append({
            "id": req.id,
            "student_id": req.student_id,
            "club_id": req.club_id,
            "status": req.status.value if hasattr(req.status, 'value') else req.status,
            "requested_at": req.requested_at,
            "student_name": user.name if user else "Unknown",
            "student_email": user.email if user else "Unknown"
        })
    return response


@router.post("/approve/{request_id}", response_model=schemas.MessageResponse)
def approve_request(request_id: int, db: Session = Depends(get_db), auth_user: models.User = Depends(require_authority)):
    req = db.query(models.ClubJoinRequest).filter(models.ClubJoinRequest.id == request_id).first()
    if not req:
        raise HTTPException(status_code=404, detail="Request not found")
        
    if req.status != models.JoinRequestStatus.Pending:
        raise HTTPException(status_code=400, detail="Request is not pending")
        
    req.status = models.JoinRequestStatus.Approved
    
    existing_member = db.query(models.ClubMember).filter(
        models.ClubMember.club_id == req.club_id,
        models.ClubMember.student_id == req.student_id
    ).first()
    if not existing_member:
        new_member = models.ClubMember(club_id=req.club_id, student_id=req.student_id)
        db.add(new_member)
        
    notif = models.Notification(title="Club Request Approved", message="You have been added to the club")
    db.add(notif)
    
    db.commit()
    return schemas.MessageResponse(message="Request approved")


@router.post("/reject/{request_id}", response_model=schemas.MessageResponse)
def reject_request(request_id: int, db: Session = Depends(get_db), auth_user: models.User = Depends(require_authority)):
    req = db.query(models.ClubJoinRequest).filter(models.ClubJoinRequest.id == request_id).first()
    if not req:
        raise HTTPException(status_code=404, detail="Request not found")
        
    if req.status != models.JoinRequestStatus.Pending:
        raise HTTPException(status_code=400, detail="Request is not pending")
        
    req.status = models.JoinRequestStatus.Rejected
    db.commit()
    return schemas.MessageResponse(message="Request rejected")
