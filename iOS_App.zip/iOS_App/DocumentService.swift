//
//  DocumentService.swift
//  CLUB ANALYTICSs
//
//  GET /documents/club/{id}
//  POST /documents/upload
//

import Foundation

final class DocumentService {
    static let shared = DocumentService()
    private init() {}

    func getDocuments(clubId: Int) async throws -> [DocumentResponse] {
        return try await APIClient.shared.request("/documents/club/\(clubId)")
    }

    func uploadDocument(clubId: Int, title: String, fileUrl: String) async throws -> DocumentResponse {
        let request = DocumentCreate(club_id: clubId, title: title, file_url: fileUrl)
        return try await APIClient.shared.request("/documents/upload", method: "POST", body: request)
    }
}
