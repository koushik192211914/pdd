from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List

from database import get_db
import models
import schemas
from core.permissions import require_authority

router = APIRouter(
    prefix="/substitutions",
    tags=["Event Substitutions"]
)

@router.get("/recommendations/{event_id}", response_model=List[schemas.SubstituteRecommendation])
def get_substitute_recommendations(event_id: int, db: Session = Depends(get_db)):
    # Calculate engagement score: 
    # score = (number of events registered) + (number of attendances marked "Present")
    
    # 1. Get all students currently registered for THIS event
    registered_student_ids = db.query(models.EventRegistration.student_id)\
        .filter(models.EventRegistration.event_id == event_id).all()
    registered_student_ids = {r[0] for r in registered_student_ids}
    
    # 2. Get all students marked in attendance for THIS event
    attended_student_ids = db.query(models.EventAttendance.student_id)\
        .filter(models.EventAttendance.event_id == event_id).all()
    attended_student_ids = {r[0] for r in attended_student_ids}
    
    exclude_ids = registered_student_ids.union(attended_student_ids)
    
    # 3. Get all students (role=Student typically, or just all users for now since requirements didn't specify role filtering, but we can assume users)
    all_users = db.query(models.User).all()
    
    recommendations = []
    
    for user in all_users:
        if user.id in exclude_ids:
            continue
            
        # Get count of registrations
        reg_count = db.query(models.EventRegistration).filter(models.EventRegistration.student_id == user.id).count()
        # Get count of present attendances
        att_count = db.query(models.EventAttendance).filter(
            models.EventAttendance.student_id == user.id,
            models.EventAttendance.status == "Present"
        ).count()
        
        score = reg_count + att_count
        recommendations.append(schemas.SubstituteRecommendation(
            student_id=user.id,
            engagement_score=score
        ))
        
    # Sort descending by engagement_score
    recommendations.sort(key=lambda x: x.engagement_score, reverse=True)
    
    return recommendations

@router.post("/assign", response_model=schemas.SubstitutionResponse)
def assign_substitute(substitution: schemas.SubstitutionCreate, assigned_by: int = None, db: Session = Depends(get_db), auth_user: models.User = Depends(require_authority)):
    # 1. Verify original student registered for event
    registration = db.query(models.EventRegistration).filter(
        models.EventRegistration.event_id == substitution.event_id,
        models.EventRegistration.student_id == substitution.original_student_id
    ).first()
    if not registration:
        raise HTTPException(status_code=400, detail="Original student not registered for this event")
        
    # 2. Verify original student marked Absent in event_attendance
    attendance = db.query(models.EventAttendance).filter(
        models.EventAttendance.event_id == substitution.event_id,
        models.EventAttendance.student_id == substitution.original_student_id
    ).first()
    if not attendance or attendance.status != "Absent":
        raise HTTPException(status_code=400, detail="Original student is not marked Absent")
        
    # 3. Verify substitute is NOT already registered for event
    substitute_reg = db.query(models.EventRegistration).filter(
        models.EventRegistration.event_id == substitution.event_id,
        models.EventRegistration.student_id == substitution.substitute_student_id
    ).first()
    if substitute_reg:
        raise HTTPException(status_code=400, detail="Substitute is already registered for this event")
        
    # Insert substitution record
    new_sub = models.EventSubstitution(
        event_id=substitution.event_id,
        original_student_id=substitution.original_student_id,
        substitute_student_id=substitution.substitute_student_id,
        assigned_by=assigned_by
    )
    db.add(new_sub)
    db.commit()
    db.refresh(new_sub)
    return new_sub

@router.get("/event/{event_id}", response_model=List[schemas.SubstitutionResponse])
def get_substitutions_for_event(event_id: int, db: Session = Depends(get_db)):
    subs = db.query(models.EventSubstitution).filter(models.EventSubstitution.event_id == event_id).all()
    return subs


@router.delete("/{substitution_id}")
def delete_substitution(substitution_id: int, db: Session = Depends(get_db)):
    sub = db.query(models.EventSubstitution).filter(models.EventSubstitution.id == substitution_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Substitution record not found")
        
    db.delete(sub)
    db.commit()
    return {"message": "Substitution record deleted"}
