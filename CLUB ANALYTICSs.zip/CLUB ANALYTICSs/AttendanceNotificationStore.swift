//
//  AttendanceNotificationStore.swift
//  CLUB ANALYTICSs
//
//  Shared state for participant attendance and event notifications.
//  Inject via .environmentObject(store) at the app root.
//

import SwiftUI
import Combine

// MARK: - Attendance Status

enum AttendanceStatus: Equatable {
    case pending
    case confirmed
    case absent
    case substituted(by: String)

    var label: String {
        switch self {
        case .pending:              return "Pending"
        case .confirmed:            return "Confirmed"
        case .absent:               return "Absent"
        case .substituted(let sub): return "Substituted by \(sub)"
        }
    }

    var color: Color {
        switch self {
        case .pending:    return Color(UIColor.tertiaryLabel)
        case .confirmed:  return .green
        case .absent:     return .red
        case .substituted: return .orange
        }
    }

    var icon: String {
        switch self {
        case .pending:    return "circle.dotted"
        case .confirmed:  return "checkmark.circle.fill"
        case .absent:     return "xmark.circle.fill"
        case .substituted: return "arrow.triangle.2.circlepath.circle.fill"
        }
    }
}

// MARK: - Participant Model

struct ParticipantAttendance: Identifiable {
    let id = UUID()
    let initials: String
    let name:     String
    let role:     String
    var status:   AttendanceStatus = .pending
}

// MARK: - Notification Model

enum NotificationType: Equatable {
    case attendance
    case eventRegistration
}

struct AttendanceNotification: Identifiable {
    let id        = UUID()
    let eventTitle: String
    let participantName: String
    let substituteName:  String?   // nil when status = confirmed
    let timestamp: Date
    var isRead:    Bool = false
    var type:      NotificationType = .attendance

    /// One-line summary shown in the badge tooltip / accessibility label
    var summary: String {
        if type == .eventRegistration {
            return "Successfully Registered for \(eventTitle)"
        }
        if let sub = substituteName {
            return "\(participantName) → Substituted by \(sub)"
        }
        // If substituteName is nil, we check the global state (this is a hack, usually we'd store the status in Notification directly).
        // Let's modify the view to handle it, but for summary we'll just say "Status Updated"
        return "\(participantName) → Status Updated"
    }
}

// MARK: - Substitute Member

struct SubstituteMember: Identifiable {
    let id = UUID()
    let name: String
    let engagementScore: Int
    let attendanceRate: Int
}

// MARK: - Store

final class AttendanceNotificationStore: ObservableObject {

    // MARK: Published state
    @Published var participantsByEvent: [String: [ParticipantAttendance]] = [:]
    @Published var isAttendanceLocked: [String: Bool] = [:]
    @Published var notifications: [AttendanceNotification] = []
    @Published var substitutePool: [SubstituteMember] = []
    
    // For tracking student event registrations
    @Published var registeredEventTitles: Set<String> = []

    // MARK: Computed
    var unreadCount: Int { notifications.filter { !$0.isRead }.count }

    // MARK: - Initialiser with seed data

    init() {
        // Seed mock data
        seedParticipants()
        seedSubstitutePool()
        seedNotifications()
    }

    // MARK: - Seed Data Methods
    private func seedParticipants() {
        // App is using live API now, no mock participants seeded.
    }
    
    private func seedSubstitutePool() {
        // App is using live API now, no mock substitutes seeded.
    }
    
    private func seedNotifications() {
        // App is using live API now, no mock notifications seeded.
    }

    // MARK: - Participants accessor

    func participants(for event: String) -> [ParticipantAttendance] {
        participantsByEvent[event] ?? []
    }

    // MARK: - Actions

    func registerForEvent(_ title: String) {
        // Idempotent check
        guard !registeredEventTitles.contains(title) else { return }
        
        registeredEventTitles.insert(title)
        
        let newNotification = AttendanceNotification(
            eventTitle: title,
            participantName: "Student User",
            substituteName: nil,
            timestamp: Date(),
            isRead: false,
            type: .eventRegistration
        )
        notifications.insert(newNotification, at: 0)
    }

    /// Confirms attendance. Fires a notification only if not already confirmed.
    func confirm(participantName: String, event: String) {
        guard !(isAttendanceLocked[event] ?? false) else { return }
        guard var list = participantsByEvent[event],
              let idx  = list.firstIndex(where: { $0.name == participantName }) else { return }

        // Guard: don't fire duplicate notifications
        guard list[idx].status != .confirmed else { return }

        list[idx].status = .confirmed
        participantsByEvent[event] = list

        notifications.append(AttendanceNotification(
            eventTitle:     event,
            participantName: participantName,
            substituteName:  nil,
            timestamp:       Date()
        ))
    }

    /// Marks a participant absent (no notification — substitute is required). -> Wait, new rule: log absences
    func markAbsent(participantName: String, event: String) {
        guard !(isAttendanceLocked[event] ?? false) else { return }
        guard var list = participantsByEvent[event],
              let idx  = list.firstIndex(where: { $0.name == participantName }) else { return }
        list[idx].status = .absent
        participantsByEvent[event] = list

        notifications.append(AttendanceNotification(
            eventTitle:      event,
            participantName: participantName,
            substituteName:  nil,
            timestamp:       Date()
        ))
    }

    /// Assigns a substitute. Fires a notification only once per assignment.
    func assignSubstitute(participantName: String, substitute: String, event: String) {
        guard !(isAttendanceLocked[event] ?? false) else { return }
        guard var list = participantsByEvent[event],
              let idx  = list.firstIndex(where: { $0.name == participantName }) else { return }

        // Guard: don't fire duplicate notifications for same substitute
        if case .substituted(let existing) = list[idx].status, existing == substitute { return }

        list[idx].status = .substituted(by: substitute)
        participantsByEvent[event] = list

        notifications.append(AttendanceNotification(
            eventTitle:     event,
            participantName: participantName,
            substituteName:  substitute,
            timestamp:       Date()
        ))
    }

    /// Marks all notifications as read.
    func markAllRead() {
        for i in notifications.indices { notifications[i].isRead = true }
    }

    /// Submits attendance for an event based on toggled inputs, updating statuses and locking the event.
    func submitAttendance(for event: String, updates: [String: Bool]) {
        guard !(isAttendanceLocked[event] ?? false) else { return }
        
        var list = participantsByEvent[event] ?? []
        
        for (name, isPresent) in updates {
            if let idx = list.firstIndex(where: { $0.name == name }) {
                list[idx].status = isPresent ? .confirmed : .absent
            } else {
                let initials = String(name.prefix(2)).uppercased()
                list.append(ParticipantAttendance(initials: initials, name: name, role: "Member", status: isPresent ? .confirmed : .absent))
            }
        }
        
        participantsByEvent[event] = list
        isAttendanceLocked[event] = true
    }
    
    // MARK: - Substitute Suggestions
    
    /// Returns the active participant names for the given event, to exclude them from the substitute pool
    private func getActiveParticipants(for event: String) -> Set<String> {
        let list = participantsByEvent[event] ?? []
        let names = list.compactMap { p -> String? in
            switch p.status {
            case .pending, .confirmed:
                return p.name
            case .substituted(let subName):
                // Original missing, but substitute is now attending
                return subName
            case .absent:
                return nil
            }
        }
        return Set(names)
    }

    /// Returns the single best substitute eligible for the given event.
    func getSuggestedSubstitute(for event: String) -> SubstituteMember? {
        let active = getActiveParticipants(for: event)
        let eligible = substitutePool.filter { !active.contains($0.name) }
        
        // Sort by attendance * engagement score (composite metric)
        return eligible.max(by: { a, b in
            (a.engagementScore + a.attendanceRate) < (b.engagementScore + b.attendanceRate)
        })
    }

    /// Returns the rest of the eligible substitutes for the given event.
    func getOtherSubstitutes(for event: String, excluding suggestedName: String? = nil) -> [SubstituteMember] {
        let active = getActiveParticipants(for: event)
        var eligible = substitutePool.filter { !active.contains($0.name) }
        
        if let suggested = suggestedName {
            eligible.removeAll { $0.name == suggested }
        }
        
        return eligible.sorted { $0.name < $1.name }
    }
}
