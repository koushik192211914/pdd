//
//  FinanceService.swift
//  CLUB ANALYTICSs
//
//  GET /finance/budget/{club_id}
//  GET /finance/expenses/{club_id}
//  POST /finance/expense/add
//

import Foundation

final class FinanceService {
    static let shared = FinanceService()
    private init() {}

    func getFinancialReport(clubId: Int) async throws -> FinancialReportResponse {
        return try await APIClient.shared.request("/finance/reports/\(clubId)")
    }

    func getBudget(clubId: Int) async throws -> BudgetStatusResponse {
        return try await APIClient.shared.request("/finance/budget/\(clubId)")
    }

    func getExpenses(clubId: Int) async throws -> [ExpenseResponse] {
        return try await APIClient.shared.request("/finance/expenses/\(clubId)")
    }

    func addExpense(clubId: Int, title: String, amount: Double, description: String?) async throws -> ExpenseResponse {
        let request = ExpenseCreate(club_id: clubId, title: title, amount: amount, description: description)
        return try await APIClient.shared.request("/finance/expense/add", method: "POST", body: request)
    }
}
