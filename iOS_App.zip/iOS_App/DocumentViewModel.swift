//
//  DocumentViewModel.swift
//  CLUB ANALYTICSs
//

import Foundation
import Combine

@MainActor
final class DocumentViewModel: ObservableObject {
    @Published var documents: [DocumentResponse] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var successMessage: String?

    func load(clubId: Int) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                documents = try await DocumentService.shared.getDocuments(clubId: clubId)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func upload(clubId: Int, title: String, fileUrl: String) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                let doc = try await DocumentService.shared.uploadDocument(clubId: clubId, title: title, fileUrl: fileUrl)
                documents.insert(doc, at: 0)
                successMessage = "Document uploaded."
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
