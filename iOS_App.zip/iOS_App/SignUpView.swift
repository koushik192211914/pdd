import SwiftUI

struct SignUpView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var fullName         = ""
    @State private var email            = ""
    @State private var password         = ""
    @State private var confirmPassword  = ""

    @State private var isPasswordVisible        = false
    @State private var isConfirmPasswordVisible = false

    @State private var showAlert    = false
    @State private var alertMessage = ""
    @State private var isLoading    = false
    @State private var didSucceed   = false

    // Light-theme background matching LoginView
    private let bg = Color(red: 0.97, green: 0.97, blue: 0.98)

    var body: some View {
        ZStack {
            bg.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    Spacer().frame(height: 32)
                    header
                    Spacer().frame(height: 32)
                    formCard
                    Spacer().frame(height: 24)
                    GradientButton("Create Account", action: attemptSignUp)
                    Spacer().frame(height: 28)
                    backToLoginRow
                    Spacer().frame(height: 40)
                }
                .padding(.horizontal, 24)
            }
        }
        .navigationBarBackButtonHidden(true)
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text(didSucceed ? "Success" : "Error"),
                message: Text(alertMessage),
                dismissButton: .default(Text("OK")) {
                    if didSucceed { dismiss() }
                }
            )
    }
    }

    // MARK: – Header
    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Create Account")
                .font(.system(size: 32, weight: .bold))
                .foregroundColor(Color(red: 0.08, green: 0.08, blue: 0.10))
            Text("Sign up to get started with ClubSphere AI")
                .font(.system(size: 15, weight: .regular))
                .foregroundColor(Color(red: 0.50, green: 0.50, blue: 0.55))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: – Form Card
    private var formCard: some View {
        VStack(spacing: 18) {
            AuthTextField(title: "Full Name", placeholder: "John Doe", text: $fullName)
            
            AuthTextField(title: "Email", placeholder: "your@email.com", text: $email, keyboardType: .emailAddress)
            
            AuthPasswordField(title: "Password", placeholder: "••••••••", text: $password, isVisible: $isPasswordVisible)
            
            AuthPasswordField(title: "Confirm Password", placeholder: "••••••••", text: $confirmPassword, isVisible: $isConfirmPasswordVisible)
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 18)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.06), radius: 16, x: 0, y: 4)
        )
    }
    
    // MARK: - Back to Login
    private var backToLoginRow: some View {
        HStack(spacing: 4) {
            Text("Already have an account?")
                .font(.system(size: 14))
                .foregroundColor(Color(red: 0.50, green: 0.50, blue: 0.55))
            Button {
                dismiss()
            } label: {
                Text("Log In")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Color(red: 0.55, green: 0.18, blue: 0.95))
            }
        }
    }

    // MARK: – Validation
    private func attemptSignUp() {
        if fullName.trimmingCharacters(in: .whitespaces).isEmpty {
            alertMessage = "Please enter your full name."; showAlert = true; return
        }
        
        let trimmedEmail = email.trimmingCharacters(in: .whitespaces)
        let emailRegex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        if trimmedEmail.isEmpty || !NSPredicate(format:"SELF MATCHES %@", emailRegex).evaluate(with: trimmedEmail) {
            alertMessage = "Please enter a valid email address."; showAlert = true; return
        }
        
        if password.count < 8 {
            alertMessage = "Password must be at least 8 characters long."; showAlert = true; return
        }
        
        if password != confirmPassword {
            alertMessage = "Passwords do not match."; showAlert = true; return
        }
        Task {
            isLoading = true
            defer { isLoading = false }
            do {
                let response = try await AuthService.shared.signup(
                    name: fullName.trimmingCharacters(in: .whitespaces),
                    email: email.trimmingCharacters(in: .whitespaces),
                    password: password
                )
                await MainActor.run {
                    didSucceed = true
                    alertMessage = response.message
                    showAlert = true
                }
            } catch {
                await MainActor.run {
                    didSucceed = false
                    alertMessage = error.localizedDescription
                    showAlert = true
                }
            }
        }
    }
}

// MARK: - Shared Auth Field Components
struct AuthTextField: View {
    let title: String
    let placeholder: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default

    private let bg     = Color(red: 0.95, green: 0.95, blue: 0.97)
    private let border = Color(red: 0.88, green: 0.88, blue: 0.92)
    private let gray   = Color(red: 0.40, green: 0.40, blue: 0.45)

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(gray)
            TextField(
                "",
                text: $text,
                prompt: Text(placeholder).foregroundColor(Color(red: 0.70, green: 0.70, blue: 0.75))
            )
            .keyboardType(keyboardType)
            .autocapitalization(.none)
            .disableAutocorrection(true)
            .foregroundColor(Color(red: 0.10, green: 0.10, blue: 0.12))
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(bg)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(border, lineWidth: 1))
            )
        }
    }
}

struct AuthPasswordField: View {
    let title: String
    let placeholder: String
    @Binding var text: String
    @Binding var isVisible: Bool

    private let bg     = Color(red: 0.95, green: 0.95, blue: 0.97)
    private let border = Color(red: 0.88, green: 0.88, blue: 0.92)
    private let gray   = Color(red: 0.40, green: 0.40, blue: 0.45)

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(gray)
            HStack {
                passwordInput
                Button {
                    isVisible.toggle()
                } label: {
                    Image(systemName: isVisible ? "eye.fill" : "eye.slash.fill")
                        .foregroundColor(Color(red: 0.60, green: 0.60, blue: 0.65))
                        .frame(width: 24)
                }
            }
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(bg)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(border, lineWidth: 1))
            )
        }
    }

    @ViewBuilder
    private var passwordInput: some View {
        let dots = Text(placeholder).foregroundColor(Color(red: 0.70, green: 0.70, blue: 0.75))
        if isVisible {
            TextField("", text: $text, prompt: dots)
                .autocapitalization(.none)
                .disableAutocorrection(true)
                .foregroundColor(Color(red: 0.10, green: 0.10, blue: 0.12))
        } else {
            SecureField("", text: $text, prompt: dots)
                .foregroundColor(Color(red: 0.10, green: 0.10, blue: 0.12))
        }
    }
}

#Preview {
    PreviewWrapper {
    SignUpView()

    }
}
