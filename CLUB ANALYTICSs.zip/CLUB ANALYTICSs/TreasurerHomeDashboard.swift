//
//  TreasurerHomeDashboard.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Treasurer Dashboard home tab
//

import SwiftUI

// MARK: - Treasurer Home Dashboard
struct TreasurerHomeDashboard: View {
    @StateObject private var viewModel = TreasurerHomeViewModel()
    @EnvironmentObject private var authManager: AuthManager
    
    var onViewAnalytics: (() -> Void)? = nil
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // ── HEADER + STAT CARDS ──────────────────────────────────────
                RoleDashboardHeader(
                    role: .treasurer,
                    roleTitle: "Treasurer Dashboard",
                    subtitle: authManager.clubId != nil ? "Club #\(authManager.clubId!)" : "Loading...",
                    stats: [
                        DashboardStat(title: "Total Budget",      value: "₹\(Int(viewModel.financialReport?.total_budget ?? 0))",  icon: "indianrupeesign.circle.fill"),
                        DashboardStat(title: "Expenses",          value: "₹\(Int(viewModel.financialReport?.total_expenses ?? 0))",  icon: "cart.fill"),
                        DashboardStat(title: "Remaining",         value: "₹\(Int((viewModel.financialReport?.total_budget ?? 0) - (viewModel.financialReport?.total_expenses ?? 0)))",  icon: "chart.line.downtrend.xyaxis"),
                        DashboardStat(title: "Recent Exp.",       value: "\(viewModel.expenses.count)",     icon: "doc.text.fill", isWarning: false)
                    ]
                )

                VStack(spacing: 32) {
                    // ── QUICK ACTIONS ────────────────────────────────────────
                    TreasurerQuickActionsSection(onViewAnalytics: onViewAnalytics)

                    // ── BUDGET OVERVIEW ──────────────────────────────────────
                    TreasurerBudgetOverviewSection(viewModel: viewModel)

                    // ── RECENT EXPENSES ──────────────────────────────────────
                    TreasurerRecentExpensesSection(viewModel: viewModel)

                    // ── FINANCIAL REPORTS ────────────────────────────────────
                    TreasurerFinancialReportsSection()
                }
                .padding(.top, 24)
                .padding(.bottom, 100)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .task {
            if let clubId = authManager.clubId {
                await viewModel.fetchData(clubId: clubId)
            }
        }
    }
}

// MARK: - Quick Actions
private struct TreasurerQuickActionsSection: View {
    var onViewAnalytics: (() -> Void)? = nil
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionHeaderRow(title: "Quick Actions")
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 16) {
                
                NavigationLink(destination: AddExpenseView()) {
                    TrQuickActionItemContent(title: "Add Expense", icon: "plus.circle.fill", color: .purple)
                }
                
                NavigationLink(destination: BudgetApprovalView()) {
                    TrQuickActionItemContent(title: "Approve Budget", icon: "checkmark.seal.fill", color: .green)
                }
                
                NavigationLink(destination: UpdateBudgetView()) {
                    TrQuickActionItemContent(title: "Update Budget", icon: "arrow.triangle.2.circlepath", color: .orange)
                }

                if let onViewAnalytics {
                    RoleQuickActionButton(title: "View Analytics", icon: "chart.pie.fill", color: .blue, action: onViewAnalytics)
                }
            }
            .padding(.horizontal)
        }
    }
}

private struct TrQuickActionItemContent: View {
    let title: String
    let icon: String
    let color: Color

    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle().fill(color.opacity(0.15)).frame(width: 50, height: 50)
                Image(systemName: icon).font(.system(size: 24)).foregroundColor(color)
            }
            Text(title)
                .font(.subheadline).fontWeight(.semibold)
                .foregroundColor(.primary)
                .multilineTextAlignment(.center)
                .lineLimit(2)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

// MARK: - Budget Overview
private struct TreasurerBudgetOverviewSection: View {
    @ObservedObject var viewModel: TreasurerHomeViewModel

    private var allocated: Double { viewModel.financialReport?.total_budget ?? 0 }
    private var used:      Double { viewModel.financialReport?.total_expenses ?? 0 }

    private var remaining: Double { allocated - used }
    private var usedFraction: Double { allocated > 0 ? (used / allocated) : 0 }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionHeaderRow(title: "Budget Overview")

            VStack(spacing: 18) {
                // Progress bar
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Budget Used").font(.subheadline).fontWeight(.semibold)
                        Spacer()
                        Text("\(Int(usedFraction * 100))%").font(.subheadline).fontWeight(.bold).foregroundColor(.purple)
                    }
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            RoundedRectangle(cornerRadius: 8).fill(Color.purple.opacity(0.12)).frame(height: 12)
                            RoundedRectangle(cornerRadius: 8)
                                .fill(LinearGradient(colors: [.purple, .blue], startPoint: .leading, endPoint: .trailing))
                                .frame(width: geo.size.width * usedFraction, height: 12)
                        }
                    }
                    .frame(height: 12)
                }

                Divider()

                // Three budget rows
                BudgetRow(label: "Budget Allocated", amount: "₹\(Int(allocated))", color: .purple)
                BudgetRow(label: "Budget Used",       amount: "₹\(Int(used))", color: .blue)
                BudgetRow(label: "Budget Remaining",  amount: "₹\(Int(remaining))", color: .green)
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(16)
            .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
            .padding(.horizontal)
        }
    }
}

private struct BudgetRow: View {
    let label: String; let amount: String; let color: Color
    var body: some View {
        HStack {
            HStack(spacing: 8) {
                Circle().fill(color).frame(width: 10, height: 10)
                Text(label).font(.subheadline).foregroundColor(.primary)
            }
            Spacer()
            Text(amount).font(.subheadline).fontWeight(.bold).foregroundColor(color)
        }
    }
}

// MARK: - Recent Expenses
private struct TreasurerRecentExpensesSection: View {
    @ObservedObject var viewModel: TreasurerHomeViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionHeaderRow(title: "Recent Expenses", showViewAll: true)
            
            if viewModel.expenses.isEmpty {
                Text("No Recent Expenses")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(16)
                    .padding(.horizontal)
            } else {
                VStack(spacing: 12) {
                    ForEach(viewModel.expenses) { expense in
                        TrExpenseCard(
                            title: expense.title,
                            amount: "₹\(Int(expense.amount))",
                            date: String(expense.created_at.prefix(10)),
                            category: "General",
                            categoryColor: .blue
                        )
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

private struct TrExpenseCard: View {
    let title: String; let amount: String; let date: String; let category: String; let categoryColor: Color

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(categoryColor.opacity(0.13)).frame(width: 44, height: 44)
                Image(systemName: "indianrupeesign").font(.system(size: 18, weight: .semibold)).foregroundColor(categoryColor)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.subheadline).fontWeight(.semibold).lineLimit(1)
                Text(date).font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 4) {
                Text(amount).font(.subheadline).fontWeight(.bold).foregroundColor(.primary)
                Text(category)
                    .font(.caption2).fontWeight(.semibold)
                    .foregroundColor(categoryColor)
                    .padding(.horizontal, 8).padding(.vertical, 2)
                    .background(categoryColor.opacity(0.10))
                    .clipShape(Capsule())
            }
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Financial Reports
private struct TreasurerFinancialReportsSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionHeaderRow(title: "Financial Reports")
            VStack(spacing: 12) {
                TrReportCard(title: "Monthly Budget Report",  subtitle: "March 2026 summary",  icon: "doc.chart.fill",   iconColor: .purple)
                TrReportCard(title: "Event Expense Report",  subtitle: "Tech Workshop, Mar 10", icon: "list.bullet.rectangle.fill", iconColor: .blue)
            }
            .padding(.horizontal)
        }
    }
}

private struct TrReportCard: View {
    let title: String; let subtitle: String; let icon: String; let iconColor: Color

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(iconColor.opacity(0.12)).frame(width: 44, height: 44)
                Image(systemName: icon).font(.system(size: 20)).foregroundColor(iconColor)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.subheadline).fontWeight(.semibold)
                Text(subtitle).font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            Button {
            } label: {
                HStack(spacing: 4) {
                    Image(systemName: "arrow.down.circle.fill").font(.system(size: 14))
                    Text("Download").font(.caption).fontWeight(.bold)
                }
                .foregroundColor(.white)
                .padding(.horizontal, 10).padding(.vertical, 6)
                .background(iconColor)
                .clipShape(Capsule())
            }
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
    NavigationStack { TreasurerHomeDashboard() }
        .environmentObject(AttendanceNotificationStore())

    }
}
