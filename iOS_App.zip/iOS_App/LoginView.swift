//
//  LoginView.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Login Screen (light theme, Apple-style)
//
//  Navigation:
//    Sign In (valid)  → DashboardView
//    Sign Up          → RegisterView
//

import SwiftUI

// MARK: – Root view
struct LoginView: View {
    @EnvironmentObject private var authManager: AuthManager

    @State private var email            = ""
    @State private var password         = ""
    @State private var isPasswordVisible = false
    @State private var showAlert         = false
    @State private var alertMessage      = ""
    @State private var alertTitle        = "Error"
    @State private var goSignUp          = false
    @State private var goForgotPassword  = false
    @State private var isLoading         = false


    // Light-theme background
    private let bg = Color(red: 0.97, green: 0.97, blue: 0.98)

    var body: some View {
        ZStack {
            bg.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    Spacer().frame(height: 56)
                    LoginHeader()
                    Spacer().frame(height: 32)
                    formCard
                    Spacer().frame(height: 24)
                    SignInCTA(action: attemptSignIn)
                    Spacer().frame(height: 28)
                    signUpRow
                    Spacer().frame(height: 40)
                }
                .padding(.horizontal, 24)
            }
        }
        .navigationDestination(isPresented: $goSignUp) {
            SignUpView()
        }
        .navigationDestination(isPresented: $goForgotPassword) {
            ForgotPasswordView()
        }
        .toolbar(.hidden, for: .navigationBar)
        .alert(alertTitle, isPresented: $showAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(alertMessage)
        }
    }

    // MARK: – Form card
    private var formCard: some View {
        VStack(spacing: 18) {
            LoginEmailField(email: $email)
            LoginPasswordField(password: $password, isVisible: $isPasswordVisible)
            forgotPassword
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 18)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.06), radius: 16, x: 0, y: 4)
        )
        .overlay(
            Group {
                if isLoading {
                    RoundedRectangle(cornerRadius: 18)
                        .fill(Color.white.opacity(0.7))
                    ProgressView()
                }
            }
        )
    }

    private var forgotPassword: some View {
        HStack {
            Button {
                goForgotPassword = true
            } label: {
                Text("Forgot Password?")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(Color(red: 0.55, green: 0.18, blue: 0.95))
            }
            Spacer()
        }
    }

    // MARK: – Sign Up row
    private var signUpRow: some View {
        HStack(spacing: 4) {
            Text("Don't have an account?")
                .font(.system(size: 14))
                .foregroundColor(Color(red: 0.50, green: 0.50, blue: 0.55))
            Button {
                goSignUp = true
            } label: {
                Text("Sign Up")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Color(red: 0.55, green: 0.18, blue: 0.95))
            }
        }
    }

    // MARK: – Validation
    private func attemptSignIn() {
        let trimmedEmail = email.trimmingCharacters(in: .whitespaces)
        let emailRegex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        if trimmedEmail.isEmpty || !NSPredicate(format:"SELF MATCHES %@", emailRegex).evaluate(with: trimmedEmail) {
            alertTitle = "Invalid Email"
            alertMessage = "Please enter a valid email address."
            showAlert = true
            return
        }
        if password.isEmpty {
            alertTitle = "Missing Fields"
            alertMessage = "Please enter your password."
            showAlert = true
            return
        }
        Task {
            isLoading = true
            defer { isLoading = false }
            do {
                let response = try await AuthService.shared.login(
                    email: email.trimmingCharacters(in: .whitespaces),
                    password: password
                )
                await MainActor.run {
                    authManager.saveSession(user: response.user)
                }
            } catch let error as APIError {
                await MainActor.run {
                    switch error {
                    case .unauthorized:
                        alertTitle = "Login Error"
                        alertMessage = "Invalid email or password."
                    case .networkError(let e):
                        alertTitle = "Network Failure"
                        alertMessage = "Could not reach server: \(e.localizedDescription)"
                    default:
                        print("⚠️ [LoginView] Invalid Response / Debug: \(error)")
                        alertTitle = "Login Failed"
                        alertMessage = error.localizedDescription
                    }
                    showAlert = true
                }
            } catch {
                await MainActor.run {
                    print("⚠️ [LoginView] Unknown Error: \(error)")
                    alertTitle = "Login Error"
                    alertMessage = "An unexpected error occurred."
                    showAlert = true
                }
            }
        }
    }
}

// MARK: – Header
private struct LoginHeader: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Welcome Back")
                .font(.system(size: 32, weight: .bold))
                .foregroundColor(Color(red: 0.08, green: 0.08, blue: 0.10))
            Text("Sign in to continue to ClubAI")
                .font(.system(size: 15, weight: .regular))
                .foregroundColor(Color(red: 0.50, green: 0.50, blue: 0.55))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

// MARK: – Email field
private struct LoginEmailField: View {
    @Binding var email: String

    private let bg     = Color(red: 0.95, green: 0.95, blue: 0.97)
    private let border = Color(red: 0.88, green: 0.88, blue: 0.92)
    private let gray   = Color(red: 0.40, green: 0.40, blue: 0.45)

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Email")
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(gray)
            TextField(
                "",
                text: $email,
                prompt: Text("your@email.com").foregroundColor(Color(red: 0.70, green: 0.70, blue: 0.75))
            )
            .keyboardType(.emailAddress)
            .autocapitalization(.none)
            .disableAutocorrection(true)
            .foregroundColor(Color(red: 0.10, green: 0.10, blue: 0.12))
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(bg)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(border, lineWidth: 1))
            )
        }
    }
}

// MARK: – Password field
private struct LoginPasswordField: View {
    @Binding var password: String
    @Binding var isVisible: Bool

    private let bg     = Color(red: 0.95, green: 0.95, blue: 0.97)
    private let border = Color(red: 0.88, green: 0.88, blue: 0.92)
    private let gray   = Color(red: 0.40, green: 0.40, blue: 0.45)

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Password")
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(gray)
            HStack {
                passwordInput
                Button {
                    isVisible.toggle()
                } label: {
                    Image(systemName: isVisible ? "eye.fill" : "eye.slash.fill")
                        .foregroundColor(Color(red: 0.60, green: 0.60, blue: 0.65))
                        .frame(width: 24)
                }
            }
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(bg)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(border, lineWidth: 1))
            )
        }
    }

    @ViewBuilder
    private var passwordInput: some View {
        let dots = Text("••••••••").foregroundColor(Color(red: 0.70, green: 0.70, blue: 0.75))
        if isVisible {
            TextField("", text: $password, prompt: dots)
                .autocapitalization(.none)
                .disableAutocorrection(true)
                .foregroundColor(Color(red: 0.10, green: 0.10, blue: 0.12))
        } else {
            SecureField("", text: $password, prompt: dots)
                .foregroundColor(Color(red: 0.10, green: 0.10, blue: 0.12))
        }
    }
}

// MARK: – Sign In CTA (wraps GradientButton)
private struct SignInCTA: View {
    let action: () -> Void
    var body: some View {
        GradientButton("Sign In", action: action)
    }
}

// MARK: – OR divider row
private struct OrDividerRow: View {
    private let lineColor = Color(red: 0.85, green: 0.85, blue: 0.88)
    var body: some View {
        HStack(spacing: 12) {
            Rectangle().fill(lineColor).frame(height: 1)
            Text("or continue with")
                .font(.system(size: 13, weight: .regular))
                .foregroundColor(Color(red: 0.60, green: 0.60, blue: 0.65))
                .fixedSize()
            Rectangle().fill(lineColor).frame(height: 1)
        }
    }
}

// MARK: – Preview
#Preview {
    PreviewWrapper {
    NavigationStack {
        LoginView()
    }
    }
}
