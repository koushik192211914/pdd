import SwiftUI

struct BudgetRequest: Identifiable {
    let id = UUID()
    let eventName: String
    let amount: String
    let requestedBy: String
    let date: String
}

struct BudgetApprovalView: View {
    @Environment(\.dismiss) private var dismiss
    
    @State private var requests = [
        BudgetRequest(eventName: "Spring Hackathon", amount: "₹15,000", requestedBy: "Tech Innovation Club", date: "Mar 11, 2026"),
        BudgetRequest(eventName: "Guest Speaker Series", amount: "₹8,000", requestedBy: "Business Leaders", date: "Mar 09, 2026"),
        BudgetRequest(eventName: "Robotics Workshop", amount: "₹5,500", requestedBy: "Robotics Society", date: "Mar 08, 2026")
    ]
    
    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        VStack(spacing: 0) {
            // ── Header ───────────────────────────────────────────────
            headerView
            
            // ── List ─────────────────────────────────────────────────
            ScrollView {
                VStack(spacing: 16) {
                    if requests.isEmpty {
                        VStack(spacing: 20) {
                            Image(systemName: "checkmark.seal.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.green.opacity(0.8))
                            Text("All Caught Up!")
                                .font(.headline)
                            Text("No pending budget approvals.")
                                .font(.subheadline).foregroundColor(.secondary)
                        }
                        .padding(.top, 100)
                    } else {
                        ForEach(requests) { req in
                            BudgetRequestCard(request: req) { 
                                removeRequest(req)
                            }
                        }
                    }
                }
                .padding(20)
                .padding(.bottom, 40)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
    }

    private var headerView: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 8)
                HStack(alignment: .center, spacing: 12) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Approve Budget").font(.title3).bold().foregroundColor(.white)
                        Text("Review pending financial requests")
                            .font(.caption).foregroundColor(.white.opacity(0.80))
                    }
                    Spacer()
                }
                .padding(.horizontal, 18).padding(.bottom, 22)
            }
        }
        .frame(height: safeTop + 92)
    }
    
    private func removeRequest(_ req: BudgetRequest) {
        withAnimation {
            requests.removeAll(where: { $0.id == req.id })
            if requests.isEmpty {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                    dismiss()
                }
            }
        }
    }
}

struct BudgetRequestCard: View {
    let request: BudgetRequest
    let onAction: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(request.eventName)
                        .font(.headline)
                    Text("Requested by " + request.requestedBy)
                        .font(.caption).foregroundColor(.secondary)
                    Text(request.date)
                        .font(.caption2).foregroundColor(.secondary).padding(.top, 2)
                }
                Spacer()
                Text(request.amount)
                    .font(.title3).bold().foregroundColor(.purple)
            }
            
            Divider()
            
            HStack(spacing: 12) {
                Button(action: onAction) {
                    Text("Reject")
                        .font(.subheadline).fontWeight(.semibold)
                        .foregroundColor(.red)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(10)
                }
                
                Button(action: onAction) {
                    Text("Approve")
                        .font(.subheadline).fontWeight(.semibold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Color.green)
                        .cornerRadius(10)
                        .shadow(color: .green.opacity(0.3), radius: 4, x: 0, y: 2)
                }
            }
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.04), radius: 5, x: 0, y: 2)
    }
}

#Preview {
    PreviewWrapper {
    BudgetApprovalView()

    }
}
