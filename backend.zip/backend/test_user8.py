import sys
sys.path.append("/Users/sail/Desktop/CLUB ANALYTICSs/backend")

from database import SessionLocal
from models import User, ClubMember, Club
from schemas import UserResponse
from fastapi.encoders import jsonable_encoder

def test():
    db = SessionLocal()
    user = db.query(User).filter(User.id == 8).first()
    if user:
        print(f"User 8: {user.name}")
        memberships = db.query(ClubMember).filter(ClubMember.student_id == 8).all()
        print(f"Memberships: {[(m.id, m.club_id) for m in memberships]}")
        club = db.query(Club).filter(Club.created_by == 8).first()
        print(f"Created club: {club.id if club else None}")
        
        # calculate
        membership = db.query(ClubMember).filter(ClubMember.student_id == user.id).first()
        club_id = membership.club_id if membership else None
        if not club_id:
            club = db.query(Club).filter(Club.created_by == user.id).first()
            club_id = club.id if club else None
            
        print(f"Calculated club_id: {club_id}")
    else:
        print("User 8 not found")

test()
