//
//  MockData.swift
//  CLUB ANALYTICSs
//
//  Centralized mock data for the ClubSphere AI application.
//  Matching structures in AppModels.swift.
//

import Foundation

struct MockData {
    
    // MARK: - Auth
    static let mockUser = UserResponseModel(
        id: 1,
        name: "Test User",
        email: "test@example.com",
        role: "President", // Change this to test different dashboards
        created_at: "2024-03-20T10:00:00Z",
        club_id: 1
    )
    
    static let adminUser = UserResponseModel(
        id: 2,
        name: "Admin User",
        email: "admin@clubsphere.ai",
        role: "Admin",
        created_at: "2024-01-01T08:00:00Z",
        club_id: nil
    )

    static let allUsers: [AdminUserResponse] = [
        AdminUserResponse(id: 1, name: "Test User", email: "test@example.com", role: "President", created_at: "2024-03-20T10:00:00Z"),
        AdminUserResponse(id: 2, name: "Admin User", email: "admin@clubsphere.ai", role: "Admin", created_at: "2024-01-01T08:00:00Z"),
        AdminUserResponse(id: 3, name: "Alice Smith", email: "alice@example.com", role: "Student", created_at: "2024-03-22T14:30:00Z"),
        AdminUserResponse(id: 4, name: "Bob Johnson", email: "bob@example.com", role: "Secretary", created_at: "2024-03-21T09:15:00Z")
    ]

    // MARK: - Clubs
    static let clubs: [ClubResponse] = [
        ClubResponse(id: 1, name: "AI Enthusiasts", category: "Technology", description: "Exploring the future of intelligence.", created_by: 2, created_at: "2024-01-15T12:00:00Z", occupied_roles: [], instagram_url: nil, has_award: false),
        ClubResponse(id: 2, name: "Code Crafters", category: "Engineering", description: "Building elegant software solutions.", created_by: 2, created_at: "2024-02-10T11:00:00Z", occupied_roles: [], instagram_url: nil, has_award: false)
    ]

    // MARK: - Events
    static let events: [EventResponse] = [
        EventResponse(id: 1, title: "AI Workshop", description: "Hands-on intro to ML.", club_id: 1, date: "2024-04-10T15:00:00Z", created_by: 1, created_at: "2024-03-01T10:00:00Z"),
        EventResponse(id: 2, title: "Hackathon 2024", description: "48 hours of coding.", club_id: 2, date: "2024-04-20T09:00:00Z", created_by: 4, created_at: "2024-03-05T09:00:00Z")
    ]

    // MARK: - Analytics
    static let healthScore = ClubHealthResponse(
        club_id: 1,
        club_health_score: 85.5,
        average_engagement: 4.2,
        total_members: 120,
        event_participation_rate: 0.75,
        total_events: 5,
        has_award: false
    )

    static let engagement = StudentEngagementResponse(
        student_id: 1,
        events_registered: 5,
        events_attended: 4,
        club_attendance: 12,
        engagement_score: 88,
        clubs_joined: 3,
        club_id: 1
    )

    // MARK: - Finance
    static let expenses: [ExpenseResponse] = [
        ExpenseResponse(id: 1, club_id: 1, added_by: 1, title: "Pizza for Workshop", amount: 150.0, description: "Refreshments", created_at: "2024-03-10T18:00:00Z"),
        ExpenseResponse(id: 2, club_id: 1, added_by: 1, title: "Stickers", amount: 25.0, description: "Marketing materials", created_at: "2024-03-12T10:00:00Z")
    ]
    
    static let budget = BudgetStatusResponse(total_budget: 1000.0, remaining_budget: 825.0)

    // MARK: - Announcements
    static let announcements: [AnnouncementResponse] = [
        AnnouncementResponse(id: 1, title: "Welcome!", content: "Happy to have everyone here.", club_id: 1, author_id: 1, created_at: "2024-03-20T08:00:00Z", priority: "Normal", author_name: "Admin User", club_name: "Tech Innovation")
    ]

    // MARK: - Notifications
    static let notifications: [NotificationResponseModel] = [
        NotificationResponseModel(id: 1, title: "New Event", message: "AI Workshop is coming up!", created_at: "2024-03-23T09:00:00Z")
    ]
    
    // MARK: - Documents
    static let documents: [DocumentResponse] = [
        DocumentResponse(id: 1, club_id: 1, title: "Constitution", file_url: "https://example.com/doc.pdf", uploaded_by: 1, created_at: "2024-01-01T00:00:00Z")
    ]
}
