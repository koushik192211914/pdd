import Foundation

func runTestExistential() {
    let body: Encodable = LoginRequest(email: "test@example.com", password: "password123")
    let encoder = JSONEncoder()

    // This simulates what APIClient was doing!
    let bodyData = try! encoder.encode(body)
    print("Original Encoding: " + (String(data: bodyData, encoding: .utf8) ?? "ERROR"))
}
