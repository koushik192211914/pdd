//
//  CLUB_ANALYTICSsApp.swift
//  CLUB ANALYTICSs
//
//  Created by SAIL on 06/03/26.
//

import SwiftUI

@main
struct CLUB_ANALYTICSsApp: App {
    @StateObject private var store       = AttendanceNotificationStore()
    @StateObject private var authManager = AuthManager.shared

    @State private var isSplashScreenDone = false

    var body: some Scene {
        WindowGroup {
            Group {
                if !isSplashScreenDone {
                    // 1. Initial Loading Splash
                    SplashScreenView {
                        print("🚀 [App] Splash done. isLoggedIn: \(authManager.isLoggedIn). Role: \(authManager.userRole)")
                        withAnimation(.easeInOut(duration: 0.5)) { 
                            isSplashScreenDone = true 
                        }
                    }
                } else {
                    // Splash is done: Choose between Auth and Main App
                    if !authManager.isLoggedIn {
                        // 2. Auth Flow (Onboarding -> Login)
                        NavigationStack {
                            if authManager.hasSeenOnboarding {
                                LoginView()
                            } else {
                                OnboardingView()
                            }
                        }
                        .transition(.opacity)
                    } else {
                        // 3. Main Application Dashboard
                        // Directly enters the dashboard based on the LAST SAVED role.
                        // If you are 'directly entering admin', it's because your session role is Admin.
                        PresidentDashboardView(role: authManager.clubRole)
                            .transition(.slide)
                    }
                }
            }
            .environmentObject(store)
            .environmentObject(authManager)
        }
    }
}
