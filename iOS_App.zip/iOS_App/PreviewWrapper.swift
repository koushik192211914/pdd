import SwiftUI

struct PreviewWrapper<Content: View>: View {
    @StateObject var authManager = AuthManager.shared
    @StateObject var store = AttendanceNotificationStore()
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .environmentObject(authManager)
            .environmentObject(store)
    }
}
