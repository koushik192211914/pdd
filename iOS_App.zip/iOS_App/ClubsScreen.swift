//
//  ClubsScreen.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Shared Clubs screen (all roles)
//  Permissions:
//    Admin               → Add Club (+) visible, can manage
//    President/VP/Sec → View only, no join
//    Student             → View + Join Club button in detail
//

import SwiftUI

// MARK: - Color hex helper
extension Color {
    init(hex: String) {
        let scanner = Scanner(string: hex)
        var rgb: UInt64 = 0
        scanner.scanHexInt64(&rgb)
        let r = Double((rgb >> 16) & 0xFF) / 255.0
        let g = Double((rgb >> 8)  & 0xFF) / 255.0
        let b = Double(rgb & 0xFF)         / 255.0
        self.init(red: r, green: g, blue: b)
    }
}

// MARK: - Club data model
// Removed legacy ClubItem

// MARK: - Clubs Screen
struct ClubsScreen: View {
    let role: ClubRole

    @StateObject private var vm = ClubsViewModel()
    @State private var searchText = ""

    private var canAddClub: Bool { role == .admin }
    private var canJoin:    Bool { role == .student }

    @State private var safeTop: CGFloat = 54

    private var filtered: [ClubResponse] {
        searchText.isEmpty ? vm.clubs : vm.clubs.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {

                // ── HEADER ───────────────────────────────────────────────────
                clubsHeader

                VStack(spacing: 16) {
                    // ── SEARCH BAR ───────────────────────────────────────────
                    searchBar

                    // ── LOADING / ERROR ──────────────────────────────────
                    if vm.isLoading {
                        ProgressView("Loading clubs...")
                            .padding()
                    } else if let err = vm.errorMessage {
                        Text("⚠️ \(err)").font(.caption).foregroundColor(.red).padding()
                    } else if filtered.isEmpty {
                        emptyState
                    } else {
                        // ── CLUB CARDS ───────────────────────────────────────────
                        ForEach(filtered) { club in
                            NavigationLink(destination: ClubDetailScreen(club: club, canJoin: canJoin, role: role)) {
                                APIClubCard(club: club)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                }
                .padding(.top, 16)
                .padding(.horizontal)
                .padding(.bottom, 100)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .onAppear {
            let top = UIApplication.shared.connectedScenes
                .compactMap { $0 as? UIWindowScene }
                .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
            if top > 0 { self.safeTop = top }
        }
        .task { 
            await vm.load()
        }
        .refreshable { await vm.load() }
    }

    // MARK: – Header
    private var clubsHeader: some View {
        ZStack(alignment: .top) {
            LinearGradient(
                colors: [Color.purple, Color.blue],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 16)

                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Clubs")
                            .font(.title2).bold().foregroundColor(.white)
                        Text("\(vm.clubs.count) active clubs")
                            .font(.subheadline).fontWeight(.medium)
                            .foregroundColor(.white.opacity(0.80))
                    }
                    Spacer()
                    // Add Club — Admin only
                    if canAddClub {
                        NavigationLink(destination: CreateClubScreen()) {
                            ZStack {
                                Circle().fill(Color.white.opacity(0.22)).frame(width: 44, height: 44)
                                Image(systemName: "plus")
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(.white)
                            }
                        }
                    }
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 24)
            }
        }
        .frame(height: safeTop + 110)
    }

    // MARK: – Search bar
    private var searchBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.secondary)
            TextField("Search clubs...", text: $searchText)
                .font(.subheadline)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }

    // MARK: – Empty state
    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "building.2")
                .font(.system(size: 48)).foregroundColor(.purple.opacity(0.4))
            Text("No clubs match your search")
                .font(.headline).foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity).padding(40)
    }
}

// MARK: - Club card (list item)
// Removed legacy ClubCard




// MARK: - API Club card (uses ClubResponse from backend)
private struct APIClubCard: View {
    let club: ClubResponse

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 14)
                    .fill(LinearGradient(colors: [.purple, .purple.opacity(0.65)],
                                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 52, height: 52)
                Image(systemName: "building.2.fill")
                    .font(.system(size: 22)).foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: 5) {
                Text(club.name)
                    .font(.subheadline).fontWeight(.semibold)
                    .foregroundColor(.primary).lineLimit(1)
                Text(club.description ?? "No description")
                    .font(.caption).foregroundColor(.secondary).lineLimit(2)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(Color(UIColor.tertiaryLabel))
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

// MARK: - Club Detail Screen (API / ClubResponse version)
struct ClubDetailScreen: View {
    let club:    ClubResponse
    let canJoin: Bool
    let role:    ClubRole

    @StateObject private var joinVM = JoinRequestViewModel()
    @StateObject private var detailVM = ClubDetailViewModel()
    @Environment(\.dismiss) private var dismiss
    @State private var joined = false
    
    @State private var deleteMessage: String?
    @State private var isDeleting = false

    @State private var safeTop: CGFloat = 54

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {
                detailHeader
                    .zIndex(0)

                VStack(alignment: .leading, spacing: 24) {
                    
                    // Stats / Details Card
                    VStack(spacing: 0) {
                        if detailVM.isLoading {
                            ProgressView().frame(maxWidth: .infinity).padding()
                        } else if let health = detailVM.health {
                            ClubInfoRow(icon: "person.2.fill", color: .purple, label: "Total Members", value: "\(health.total_members)")
                            Divider().padding(.leading, 50)
                            ClubInfoRow(icon: "calendar", color: .blue, label: "Total Events", value: "\(detailVM.events.count)")
                            Divider().padding(.leading, 50)
                            ClubInfoRow(icon: "chart.line.uptrend.xyaxis", color: .green, label: "Engagement Rate", value: "\(Int(health.average_engagement))%")
                        } else {
                            ClubInfoRow(icon: "person.2.fill", color: .purple, label: "Total Members", value: "--")
                        }
                    }
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
                    .offset(y: -30)
                    .padding(.bottom, -30)
                    .zIndex(1)

                    // About Card
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Club Description")
                            .font(.headline)
                            .foregroundColor(.primary)
                        
                        Text(club.description ?? "Join us for an exciting experience where students collaborate to build innovative tech solutions. We compete for prizes, network with industry professionals, and showcase creativity.")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                            .lineSpacing(4)
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)

                    // Instagram Card (only shown if url exists)
                    if let instaUrl = club.instagram_url, !instaUrl.isEmpty {
                        Button(action: {
                            if let url = URL(string: instaUrl) {
                                UIApplication.shared.open(url)
                            }
                        }) {
                            HStack(spacing: 14) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(LinearGradient(colors: [Color(hex: "E1306C"), Color(hex: "833AB4")],
                                                             startPoint: .topLeading, endPoint: .bottomTrailing))
                                        .frame(width: 44, height: 44)
                                    Image(systemName: "camera.fill")
                                        .font(.system(size: 20)).foregroundColor(.white)
                                }
                                VStack(alignment: .leading, spacing: 3) {
                                    Text("Follow on Instagram")
                                        .font(.subheadline).fontWeight(.semibold)
                                        .foregroundColor(.primary)
                                    Text("See past activities & reels")
                                        .font(.caption).foregroundColor(.secondary)
                                }
                                Spacer()
                                Image(systemName: "arrow.up.right.square.fill")
                                    .foregroundColor(Color(hex: "E1306C"))
                            }
                            .padding(16)
                            .background(Color(UIColor.secondarySystemGroupedBackground))
                            .cornerRadius(18)
                            .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
                        }
                    }

                    // Events Card
                    VStack(alignment: .leading, spacing: 14) {
                        HStack {
                            Text("Club Events")
                                .font(.headline)
                                .foregroundColor(.primary)
                            Spacer()
                            Text("\(detailVM.events.count)")
                                .font(.caption).foregroundColor(.secondary)
                                .padding(.horizontal, 10).padding(.vertical, 4)
                                .background(Color.purple.opacity(0.10))
                                .clipShape(Capsule())
                        }

                        if detailVM.events.isEmpty {
                            Text("No upcoming events scheduled currently.")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .padding(.top, 4)
                        } else {
                            VStack(spacing: 16) {
                                ForEach(detailVM.events.prefix(3), id: \.id) { event in
                                    HStack(spacing: 14) {
                                        ZStack {
                                            Circle().fill(Color.blue.opacity(0.10)).frame(width: 40, height: 40)
                                            Image(systemName: "calendar")
                                                .font(.system(size: 16, weight: .semibold))
                                                .foregroundColor(.blue)
                                        }
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(event.title).font(.subheadline).fontWeight(.semibold).lineLimit(1)
                                            Text("Scheduled Event").font(.caption).foregroundColor(.secondary)
                                        }
                                        Spacer()
                                        Image(systemName: "chevron.right")
                                            .font(.caption).foregroundColor(Color(UIColor.tertiaryLabel))
                                    }
                                    if event.id != detailVM.events.prefix(3).last?.id {
                                        Divider().padding(.leading, 54)
                                    }
                                }
                            }
                        }
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)

                    if canJoin {
                        let isMemberOfThisClub = AuthManager.shared.clubId == club.id
                        let isMemberOfOtherClub = AuthManager.shared.clubId != nil && AuthManager.shared.clubId != club.id
                        let buttonDisabled = joined || joinVM.isLoading || isMemberOfThisClub || isMemberOfOtherClub

                        Button {
                            joined = true
                            joinVM.sendRequest(clubId: club.id)
                        } label: {
                            HStack(spacing: 10) {
                                if isMemberOfThisClub {
                                    Image(systemName: "checkmark.circle.fill").font(.system(size: 18, weight: .semibold))
                                    Text("Already a Member").font(.system(size: 17, weight: .semibold))
                                } else if isMemberOfOtherClub {
                                    Image(systemName: "xmark.circle.fill").font(.system(size: 18, weight: .semibold))
                                    Text("Already in another club").font(.system(size: 17, weight: .semibold))
                                } else {
                                    Image(systemName: joined ? "checkmark.circle.fill" : "plus.circle.fill")
                                        .font(.system(size: 18, weight: .semibold))
                                    Text(joined ? "Request Sent!" : "Join Club")
                                        .font(.system(size: 17, weight: .semibold))
                                }
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(
                                buttonDisabled
                                ? LinearGradient(colors: [.gray, Color(UIColor.systemGray2)], startPoint: .leading, endPoint: .trailing)
                                : LinearGradient(colors: [.purple, .blue], startPoint: .leading, endPoint: .trailing)
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                            .shadow(color: buttonDisabled ? .clear : Color.purple.opacity(0.30), radius: 8, x: 0, y: 4)
                        }
                        .disabled(buttonDisabled)
                    }

                    if let msg = joinVM.errorMessage {
                        Text("⚠️ \(msg)").font(.caption).foregroundColor(.red)
                    }
                    if let msg = joinVM.successMessage {
                        Text("✅ \(msg)").font(.caption).foregroundColor(.green)
                    }
                    if let msg = deleteMessage {
                        Text("🗑️ \(msg)").font(.caption).foregroundColor(msg.contains("Failed") ? .red : .green)
                    }

                    if role == .admin {
                        Button(action: { Task { await deleteClub() } }) {
                            if isDeleting {
                                ProgressView().tint(.white).frame(maxWidth: .infinity).padding(.vertical, 16)
                                    .background(Color.red).cornerRadius(16)
                            } else {
                                Text("Delete Club")
                                    .font(.system(size: 17, weight: .semibold)).foregroundColor(.white)
                                    .frame(maxWidth: .infinity).padding(.vertical, 16)
                                    .background(Color.red).cornerRadius(16)
                            }
                        }
                        .disabled(isDeleting)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 80)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .onAppear {
            let top = UIApplication.shared.connectedScenes
                .compactMap { $0 as? UIWindowScene }
                .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
            if top > 0 { self.safeTop = top }
        }
        .task {
            await detailVM.load(clubId: club.id)
        }
    }

    private func deleteClub() async {
        isDeleting = true
        do {
            _ = try await ClubService.shared.deleteClub(id: club.id)
            deleteMessage = "Club Deleted Successfully!"
            try? await Task.sleep(nanoseconds: 1_000_000_000)
            dismiss()
        } catch {
            deleteMessage = "Failed: \(error.localizedDescription)"
            isDeleting = false
        }
    }

    private var detailHeader: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [Color.purple, Color.blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)
            
            VStack(spacing: 0) {
                Color.clear.frame(height: safeTop + 4)
                HStack {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    Spacer()
                }
                .padding(.horizontal, 20)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text(club.name)
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.leading)
                    
                    Text("Established")
                        .font(.caption)
                        .fontWeight(.bold)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.white.opacity(0.25))
                        .clipShape(Capsule())
                        .foregroundColor(.white)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 20)
                .padding(.top, 16)
                .padding(.bottom, 50)
            }
        }
    }
}

private struct ClubInfoRow: View {
    let icon: String
    let color: Color
    let label: String
    let value: String

    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 20))
                .foregroundColor(color)
                .frame(width: 24)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(label)
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text(value)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
            }
            Spacer()
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 16)
    }
}

// MARK: - Stat pill used on detail screen
private struct ClubStatPill: View {
    let value: String; let label: String; let icon: String; let color: Color

    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon).font(.system(size: 16)).foregroundColor(color)
            Text(value).font(.subheadline).fontWeight(.bold)
            Text(label).font(.caption2).foregroundColor(.secondary).lineLimit(1)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
    NavigationStack { ClubsScreen(role: .student) }
    }
}
