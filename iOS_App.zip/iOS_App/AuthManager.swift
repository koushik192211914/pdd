//
//  AuthManager.swift
//  CLUB ANALYTICSs
//
//  Manages authentication state across the app.
//  Persists userId, role, and name in UserDefaults.
//

import Foundation
import SwiftUI
import Combine

typealias User = UserResponseModel

final class AuthManager: ObservableObject {
    static let shared = AuthManager()

    // MARK: - Published State
    @Published var user: User? = nil {
        didSet {
            if let u = user {
                UserDefaults.standard.set(u.id, forKey: Keys.userId)
                UserDefaults.standard.set(u.role, forKey: Keys.role)
                UserDefaults.standard.set(u.name, forKey: Keys.name)
                UserDefaults.standard.set(u.email, forKey: Keys.email)
                if let cid = u.club_id {
                    UserDefaults.standard.set(cid, forKey: Keys.clubId)
                }
                if let picUrl = u.profile_picture_url {
                    UserDefaults.standard.set(picUrl, forKey: Keys.profilePic)
                }
            } else {
                UserDefaults.standard.removeObject(forKey: Keys.userId)
                UserDefaults.standard.removeObject(forKey: Keys.role)
                UserDefaults.standard.removeObject(forKey: Keys.name)
                UserDefaults.standard.removeObject(forKey: Keys.email)
                UserDefaults.standard.removeObject(forKey: Keys.clubId)
                UserDefaults.standard.removeObject(forKey: Keys.profilePic)
                UserDefaults.standard.removeObject(forKey: Keys.token) // Added this
            }
        }
    }

    @Published var hasSeenOnboarding: Bool {
        didSet {
            UserDefaults.standard.set(hasSeenOnboarding, forKey: Keys.onboarding)
        }
    }

    // Toggle this to false to disable auto-login during development/testing.
    @Published var isAutoLoginEnabled: Bool = true

    var token: String?   { UserDefaults.standard.string(forKey: Keys.token) }
    var userId: Int?     { user?.id }
    var userRole: String { user?.role ?? "Student" }
    var userName: String { user?.name ?? "" }
    var userEmail: String{ user?.email ?? "" }
    var clubId: Int?     { user?.club_id }
    var profilePictureURL: String? { user?.profile_picture_url }

    var isLoggedIn: Bool { user != nil }

    // MARK: - Keys
    private enum Keys {
        static let userId = "cs_userId"
        static let role   = "cs_role"
        static let name   = "cs_name"
        static let email  = "cs_email"
        static let clubId = "cs_clubId"
        static let profilePic = "cs_profilePic"
        static let token  = "cs_token"
        static let onboarding = "cs_hasSeenOnboarding"
    }

    // MARK: - Init (restore from UserDefaults)
    private init() {
        // --- MANDATORY RESET FOR TESTING ---
        // Force onboarding to false so it always appears on next launch
        self.hasSeenOnboarding = false
        print("🔍 [AuthManager] DEBUG: FORCING hasSeenOnboarding to FALSE for flow testing")
        
        // --- DISABLE AUTO-LOGIN ---
        // We comment this out so the app always starts at LoginView after onboarding
        /*
        if let storedId = UserDefaults.standard.object(forKey: Keys.userId) as? Int {
            let role  = UserDefaults.standard.string(forKey: Keys.role)  ?? "Student"
            let name  = UserDefaults.standard.string(forKey: Keys.name)  ?? ""
            let email = UserDefaults.standard.string(forKey: Keys.email) ?? ""
            let cId   = UserDefaults.standard.object(forKey: Keys.clubId) as? Int
            
            self.user = User(id: storedId, name: name, email: email, role: role, created_at: "", club_id: cId)
            print("👤 [AuthManager] auto-login restored session for \(name) (\(role))")
        } else {
            self.user = nil
            print("👤 [AuthManager] auto-login disabled or no session found.")
        }
        */
        self.user = nil
        print("👤 [AuthManager] Session restoration DISABLED. Manual login required.")
    }

    // MARK: - Session Actions
    @MainActor
    func saveSession(user: User, token: String) { // Updated signature
        withAnimation(.easeInOut) {
            UserDefaults.standard.set(token, forKey: Keys.token)
            self.user = user
        }
    }

    @MainActor
    func logout() {
        print("👤 [AuthManager] logout initiated")
        withAnimation(.easeInOut) {
            self.user = nil
        }
        
        // Clear session keys but PRESERVE onboarding state
        let sessionKeys = [Keys.userId, Keys.role, Keys.name, Keys.email, Keys.clubId, Keys.token]
        sessionKeys.forEach { UserDefaults.standard.removeObject(forKey: $0) }
        
        UserDefaults.standard.synchronize()
        print("✅ [AuthManager] session cleared (Onboarding state preserved)")
    }

    @MainActor
    func resetOnboarding() {
        print("👤 [AuthManager] resetting onboarding state for testing")
        withAnimation(.easeInOut) {
            self.hasSeenOnboarding = false
            UserDefaults.standard.set(false, forKey: Keys.onboarding)
        }
    }

    // MARK: - Role helpers
    var clubRole: ClubRole {
        let normalized = userRole.lowercased()
        print("🔐 [AuthManager] mapping userRole: '\(userRole)' (normalized: '\(normalized)') to ClubRole")
        
        switch normalized {
        case "admin":         return .admin
        case "president":     return .president
        case "vicepresident": return .vicePresident
        case "secretary":     return .secretary
        case "student":       return .student
        default:
            print("⚠️ [AuthManager] unknown mapping for '\(userRole)', defaulting to .student")
            return .student
        }
    }
}
