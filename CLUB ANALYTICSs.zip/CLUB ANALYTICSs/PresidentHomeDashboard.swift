import SwiftUI

// MARK: - Main Dashboard View
struct PresidentHomeDashboard: View {
    @StateObject private var viewModel = PresidentHomeViewModel()
    @EnvironmentObject private var authManager: AuthManager
    
    /// Role-specific header title.
    var roleTitle: String = "President Dashboard"
    /// Called when the user taps "View Analytics" in Quick Actions to switch the parent tab.
    var onViewAnalytics: (() -> Void)? = nil

    var body: some View {
        ScrollView {
            VStack(spacing: 0) { // 0 spacing because header has built-in padding
                // 1️⃣ TOP HEADER & 2️⃣ DASHBOARD SUMMARY CARDS
                DashboardHeaderSection(roleTitle: roleTitle, viewModel: viewModel)
                
                VStack(spacing: 32) {
                    QuickActionsSection(viewModel: viewModel, onViewAnalytics: onViewAnalytics)
                    
                    // 4️⃣ UPCOMING EVENTS SECTION
                    UpcomingEventsSection(viewModel: viewModel)
                    
                    // 5️⃣ LOW ENGAGEMENT MEMBERS SECTION
                    LowEngagementMembersSection(viewModel: viewModel)
                    
                    // 6️⃣ RECENT ANNOUNCEMENTS SECTION
                    RecentAnnouncementsSection(viewModel: viewModel)
                }
                .padding(.top, 24)
                .padding(.bottom, 100)
            }
        }
        .ignoresSafeArea(edges: .top) // Let header reach the top of the screen
        .background(Color(UIColor.systemGroupedBackground))
        .task {
            if let clubId = authManager.clubId {
                await viewModel.fetchData(clubId: clubId)
            }
        }
    }
}

// MARK: - Dashboard Header Section
struct DashboardHeaderSection: View {
    /// Dynamic header title ("President Dashboard" or "Vice President Dashboard")
    var roleTitle: String = "President Dashboard"
    
    @ObservedObject var viewModel: PresidentHomeViewModel

    @EnvironmentObject private var store: AttendanceNotificationStore
    @State private var showNotificationPanel = false

    /// Reads the true top safe-area inset at render time (works on all iOS 15+ devices,
    /// including Dynamic Island models) without depending on GeometryReader frame timing.
    private var safeTop: CGFloat {
        UIApplication.shared
            .connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?
            .safeAreaInsets.top ?? 50
    }

    var body: some View {
        ZStack(alignment: .top) {
            // ── Gradient background ───────────────────────────────────────────
            LinearGradient(
                colors: [Color.purple, Color.blue],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)

            // ── Content stack ─────────────────────────────────────────────────
            VStack(alignment: .leading, spacing: 0) {

                // ROW 0 – Invisible spacer that pushes content below Dynamic Island / camera
                Color.clear.frame(height: safeTop + 16)

                // ROW 1 – Title (left) + Notification bell (right)
                HStack(alignment: .center) {
                    Text(roleTitle)
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)

                    Spacer()

                    Button(action: { showNotificationPanel = true }) {
                        ZStack {
                            Circle()
                                .fill(Color.white.opacity(0.15))
                                .frame(width: 44, height: 44)
                            Image(systemName: "bell.badge.fill")
                                .font(.system(size: 20))
                                .foregroundColor(.white)
                            
                            if store.unreadCount > 0 {
                                Circle()
                                    .fill(Color.red)
                                    .frame(width: 12, height: 12)
                                    .offset(x: 12, y: -12)
                            }
                        }
                    }
                    .sheet(isPresented: $showNotificationPanel) {
                        NavigationStack {
                            NotificationsView(role: .president)
                                .environmentObject(store)
                        }
                    }
                }
                .padding(.horizontal, 18)

                // ROW 2 – Club subtitle
                Text(viewModel.club?.name ?? "Loading Club...")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.white.opacity(0.80))
                    .padding(.horizontal, 18)
                    .padding(.top, 4)
                    .padding(.bottom, 20)

                // ROW 3 – Dashboard Summary Cards
                LazyVGrid(columns: [
                    GridItem(.flexible(), spacing: 16),
                    GridItem(.flexible(), spacing: 16)
                ], spacing: 16) {
                    StatCardView(title: "Total Members",   value: "\(viewModel.health?.total_members ?? 0)",        icon: "person.3.fill")
                    StatCardView(title: "Upcoming Events", value: "\(viewModel.events.count)",         icon: "calendar")
                    StatCardView(title: "Engagement Rate", value: "\(Int(viewModel.health?.average_engagement ?? 0))%",    icon: "chart.line.uptrend.xyaxis")
                    StatCardView(title: "Low Engagement",  value: "\(viewModel.lowEngagementMembers.count)", icon: "exclamationmark.triangle.fill", isWarning: true)
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 26)
            }
        }
        // Height = safe area + fixed content height so the rounded card always looks full
        .frame(height: safeTop + 280)
    }
}

// Reusable Stat Card Component
struct StatCardView: View {
    let title: String
    let value: String
    let icon: String
    var isWarning: Bool = false
    
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(isWarning ? Color.red.opacity(0.2) : Color.white.opacity(0.2))
                    .frame(width: 40, height: 40)
                
                Image(systemName: icon)
                    .foregroundColor(isWarning ? .red : .white)
                    .font(.system(size: 18, weight: .semibold))
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(value)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                Text(title)
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.white.opacity(0.8))
                    .lineLimit(1)
            }
            
            Spacer(minLength: 0)
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.white.opacity(0.15))
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(.ultraThinMaterial)
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.white.opacity(0.3), lineWidth: 1)
        )
    }
}

// Extension to smooth selected corners (needed for iOS 14+, but useful anyway)
struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

// MARK: - Quick Actions Section
struct QuickActionsSection: View {
    @ObservedObject var viewModel: PresidentHomeViewModel
    var onViewAnalytics: (() -> Void)? = nil
    @EnvironmentObject private var authManager: AuthManager
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Quick Actions")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.horizontal)
            
            LazyVGrid(columns: [
                GridItem(.flexible(), spacing: 16),
                GridItem(.flexible(), spacing: 16)
            ], spacing: 16) {
                QuickActionButton(
                    title: "Create Event",
                    icon: "plus.circle.fill",
                    color: .purple,
                    destination: AnyView(EventCreationScreen())
                )
                
                QuickActionButton(
                    title: "Mark Attendance",
                    icon: "checkmark.seal.fill",
                    color: .blue,
                    destination: AnyView(MarkAttendanceView(eventId: ""))
                )
                
                QuickActionButton(
                    title: "Post Announcement",
                    icon: "megaphone.fill",
                    color: .orange,
                    destination: AnyView(AnnouncementCreationScreen())
                )
                
                QuickActionButton(
                    title: "View Analytics",
                    icon: "chart.pie.fill",
                    color: .green,
                    action: onViewAnalytics
                )
                
                QuickActionButton(
                    title: "Join Requests",
                    icon: "person.badge.plus",
                    color: .teal,
                    destination: AnyView(JoinRequestsView(clubId: authManager.clubId ?? 0)),
                    count: viewModel.pendingRequestCount // Pass the count
                )
            }
            .padding(.horizontal)
        }
    }
}

struct QuickActionButton: View {
    let title: String
    let icon: String
    let color: Color
    var destination: AnyView? = nil
    var action: (() -> Void)? = nil
    var count: Int = 0 // Added this
    
    var body: some View {
        Group {
            if let action {
                Button(action: action) { buttonContent }
                    .buttonStyle(PlainButtonStyle())
            } else if let destination {
                NavigationLink(destination: destination) { buttonContent }
            } else {
                buttonContent
            }
        }
    }
    
    private var buttonContent: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(color.opacity(0.15))
                    .frame(width: 50, height: 50)
                
                Image(systemName: icon)
                    .font(.system(size: 24))
                    .foregroundColor(color)
                
                if count > 0 {
                    ZStack {
                        Circle()
                            .fill(Color.red)
                            .frame(width: 22, height: 22)
                        Text("\(count)")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .offset(x: 18, y: -18)
                }
            }
            
            Text(title)
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
                .multilineTextAlignment(.center)
                .lineLimit(2)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

// MARK: - Upcoming Events Section
struct UpcomingEventsSection: View {
    @ObservedObject var viewModel: PresidentHomeViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Upcoming Events")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Spacer()
                
                Button(action: {
                    // View all action
                }) {
                    Text("View All")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.purple)
                }
            }
            .padding(.horizontal)
            
            Group {
                if viewModel.events.isEmpty {
                    Text("No Upcoming Events")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(16)
                } else {
                    VStack(spacing: 16) {
                        ForEach(viewModel.events) { event in
                            DashboardEventCard(
                                event: event,
                                destination: AnyView(EventDetailsScreen())
                            )
                        }
                    }
                }
            }
            .padding(.horizontal)
        }
    }
}

struct DashboardEventCard: View {
    let event: EventResponse
    let destination: AnyView
    
    private var dateComponents: [String] {
        // Simple splitter for format like "2026-03-10T10:00:00"
        let datePart = event.date.split(separator: "T").first ?? ""
        return datePart.split(separator: "-").map { String($0) }
    }
    
    var body: some View {
        NavigationLink(destination: destination) {
            HStack(spacing: 16) {
                // Calendar Icon block
                VStack(spacing: 4) {
                    Text(dateComponents.count > 1 ? monthAbbreviation(dateComponents[1]) : "EVENT")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(.purple)
                    Text(dateComponents.count > 2 ? dateComponents[2] : "??")
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                }
                .frame(width: 50, height: 50)
                .padding(8)
                .background(Color.purple.opacity(0.1))
                .cornerRadius(12)
                
                VStack(alignment: .leading, spacing: 6) {
                    Text(event.title)
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    HStack {
                        Image(systemName: "calendar")
                            .foregroundColor(.secondary)
                        Text(event.date.prefix(10))
                            .foregroundColor(.secondary)
                    }
                    .font(.caption)
                }
                
                Spacer()
                
                // Upload Media Button inside the card
                Button(action: {
                    // Action handled implicitly via NavigationLink wrap or separate action
                }) {
                    VStack {
                        Image(systemName: "icloud.and.arrow.up.fill")
                            .font(.system(size: 20))
                            .foregroundColor(.blue)
                        Text("Upload")
                            .font(.caption2)
                            .foregroundColor(.blue)
                    }
                    .padding(8)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(8)
                }
            }
            .padding()
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(16)
            .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Low Engagement Members Section
struct LowEngagementMembersSection: View {
    @ObservedObject var viewModel: PresidentHomeViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Low Engagement Members")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.horizontal)
            
            Group {
                if viewModel.lowEngagementMembers.isEmpty {
                    Text("All Members Highly Engaged!")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(16)
                } else {
                    VStack(spacing: 16) {
                        ForEach(viewModel.lowEngagementMembers) { member in
                            MemberCard(
                                member: member
                            )
                        }
                    }
                }
            }
            .padding(.horizontal)
        }
    }
}

struct MemberCard: View {
    let member: LowEngagementMember
    
    var body: some View {
        HStack(spacing: 16) {
            // Avatar
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [Color.gray.opacity(0.3), Color.gray.opacity(0.1)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 50, height: 50)
                
                Text("\(member.student_id)")
                    .font(.caption)
                    .foregroundColor(.primary)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Student #\(member.student_id)")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                HStack(spacing: 12) {
                    Label("Score: \(member.engagement_score)", systemImage: "star.fill")
                        .foregroundColor(.orange)
                }
                .font(.caption)
            }
            
            Spacer()
        }
        .padding()
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

// MARK: - Recent Announcements Section
struct RecentAnnouncementsSection: View {
    @ObservedObject var viewModel: PresidentHomeViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Recent Announcements")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Spacer()
                
                Button(action: {
                    // View All
                }) {
                    Text("View All")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.purple)
                }
            }
            .padding(.horizontal)
            
            Group {
                if viewModel.announcements.isEmpty {
                    Text("No Recent Announcements")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(16)
                } else {
                    VStack(spacing: 16) {
                        ForEach(viewModel.announcements) { announcement in
                            AnnouncementCard(
                                announcement: announcement,
                                priority: .normal
                            )
                        }
                    }
                }
            }
            .padding(.horizontal)
        }
    }
}

enum AnnouncementPriority: String {
    case high = "High Priority"
    case medium = "Medium Priority"
    case normal = "Normal Priority"
    
    var color: Color {
        switch self {
        case .high: return .red
        case .medium: return .orange
        case .normal: return .blue
        }
    }
}

struct AnnouncementCard: View {
    let announcement: AnnouncementResponse
    let priority: AnnouncementPriority
    
    var body: some View {
        NavigationLink(destination: AnnouncementDetailsScreen()) {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Image(systemName: "megaphone.fill")
                        .foregroundColor(.purple)
                        .font(.title3)
                    
                    Text(announcement.title)
                        .font(.headline)
                        .foregroundColor(.primary)
                        .lineLimit(2)
                        .multilineTextAlignment(.leading)
                    
                    Spacer()
                }
                
                HStack {
                    Text(priority.rawValue)
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(priority.color)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(priority.color.opacity(0.1))
                        .cornerRadius(8)
                    
                    Spacer()
                    
                    Text(announcement.created_at.prefix(10))
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .padding()
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(16)
            .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Event Reports Section
struct EventReportsSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Auto Generated Event Reports")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.horizontal)
            
            VStack(alignment: .leading, spacing: 16) {
                Text("Upload event photos and videos to automatically generate reports using AI.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                
                HStack(spacing: 16) {
                    NavigationLink(destination: MediaUploadScreen()) {
                        HStack {
                            Image(systemName: "photo.badge.plus")
                            Text("Upload Media")
                        }
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(12)
                    }
                    
                    NavigationLink(destination: EventReportsScreen()) {
                        HStack {
                            Image(systemName: "doc.text.image")
                            Text("View Reports")
                        }
                        .font(.headline)
                        .foregroundColor(.blue)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue.opacity(0.1))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.blue, lineWidth: 1)
                        )
                        .cornerRadius(12)
                    }
                }
            }
            .padding()
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(16)
            .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
            .padding(.horizontal)
        }
    }
}

// MARK: - Helpers
func monthAbbreviation(_ month: String) -> String {
    let months = ["", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]
    if let idx = Int(month), idx < months.count {
        return months[idx]
    }
    return "MT"
}

struct PresidentHomeDashboard_Previews: PreviewProvider {
    static var previews: some View {
        PreviewWrapper {
        Group {
            NavigationStack {
                PresidentHomeDashboard(roleTitle: "President Dashboard")
            }
            .previewDisplayName("President")

            NavigationStack {
                PresidentHomeDashboard(roleTitle: "Vice President Dashboard")
            }
            .previewDisplayName("Vice President")
        }
        .environmentObject(AttendanceNotificationStore())
    
        }
    }
}
