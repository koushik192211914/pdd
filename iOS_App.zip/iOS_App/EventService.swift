//
//  EventService.swift
//  CLUB ANALYTICSs
//
//  GET /events  |  GET /events/club/{club_id}  |  POST /events/create
//

import Foundation

struct EventCreateRequest: Encodable {
    let title: String
    let description: String
    let club_id: Int
    let date: String   // ISO 8601: "2026-04-01T09:00:00"

    enum CodingKeys: String, CodingKey {
        case description, club_id
        case title = "event_name"
        case date = "event_date"
    }
}



final class EventService {
    static let shared = EventService()
    private init() {}

    func getEvents() async throws -> [EventResponse] {
        return try await APIClient.shared.request("/events")
    }

    func getEvents(clubId: Int) async throws -> [EventResponse] {
        return try await APIClient.shared.request("/events/club/\(clubId)")
    }

    func deleteEvent(eventId: Int) async throws -> MessageResponse {
        return try await APIClient.shared.request("/events/\(eventId)", method: "DELETE")
    }

    func createEvent(title: String, description: String,
                     clubId: Int, date: Date) async throws -> EventResponse {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        let body = EventCreateRequest(
            title: title,
            description: description,
            club_id: clubId,
            date: formatter.string(from: date)
        )
        return try await APIClient.shared.request("/events", method: "POST", body: body)
    }

    func registerForEvent(eventId: Int) async throws -> EventRegistrationResponse {
        let body = EventRegistrationCreate(event_id: eventId)
        return try await APIClient.shared.request("/registrations/register", method: "POST", body: body)
    }
}

