//
//  RecommendationService.swift
//  CLUB ANALYTICSs
//

import Foundation

final class RecommendationService {
    static let shared = RecommendationService()
    private init() {}

    func getSubstituteRecommendations(eventId: Int) async throws -> [SubstituteRecommendation] {
        return try await APIClient.shared.request("/recommendations/substitute/\(eventId)")
    }
}
