import SwiftUI
import Combine

extension AdminUserResponse {
    var toClubUser: ClubUser {
        ClubUser(
            id: UUID(),
            dbId: self.id,
            name: self.name,
            role: self.role,
            club: self.club_name ?? "Not registered in any club",
            eventsAttended: self.events_attended,
            attendance: self.attendance_rate,
            engagement: self.engagement_score,
            profile_picture_url: self.profile_picture_url
        )
    }
}

// MARK: - User Model
// Removed legacy ClubUser sample data

@MainActor
final class ManageUsersViewModel: ObservableObject {
    @Published var users: [AdminUserResponse] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    func load() async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            let fetchedUsers = try await AdminService.shared.getAllUsers()
            users = fetchedUsers.filter { $0.role.lowercased() != "admin" }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func getInitials(_ name: String) -> String {
        let parts = name.split(separator: " ")
        if parts.count >= 2 {
            return "\(parts[0].prefix(1))\(parts[1].prefix(1))".uppercased()
        }
        return String(name.prefix(2)).uppercased()
    }
}

// MARK: - Manage Users Screen
struct ManageUsersScreen: View {
    @StateObject private var vm = ManageUsersViewModel()
    @State private var searchText: String         = ""
    @State private var showSearch: Bool           = false
    @State private var selectedUser: AdminUserResponse? = nil
    @State private var profileNavActive: Bool     = false
    @State private var promoteNavActive: Bool     = false

    private var filteredUsers: [AdminUserResponse] {
        if searchText.isEmpty { return vm.users }
        return vm.users.filter {
            $0.name.localizedCaseInsensitiveContains(searchText) ||
            $0.role.localizedCaseInsensitiveContains(searchText)
        }
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // ── Header ──────────────────────────────────────────────
                ManageUsersHeader(showSearch: $showSearch, searchText: $searchText, userCount: vm.users.count)

                VStack(spacing: 28) {
                    if vm.isLoading {
                        ProgressView("Loading users...")
                    } else if let err = vm.errorMessage {
                        Text("⚠️ \(err)").foregroundColor(.red).padding()
                    } else {
                        // ── All Users ───────────────────────────────────────
                        AllUsersSection(
                            users: filteredUsers,
                            vm: vm,
                            onPromote: { user in
                                selectedUser    = user
                                promoteNavActive = true
                            },
                            onViewProfile: { user in
                                selectedUser    = user
                                profileNavActive = true
                            }
                        )
                    }
                }
                .padding(.top, 24)
                .padding(.bottom, 100)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .task {
            await vm.load()
        }
        .navigationDestination(isPresented: $profileNavActive) {
            if let user = selectedUser {
                UserProfileScreen(
                    user:          user.toClubUser,
                    onProfileUpdated: { newRole, newClub in updateRole(for: user, newRole: newRole, newClub: newClub) },
                    dismissToRoot: dismissToRoot
                )
            }
        }
        .navigationDestination(isPresented: $promoteNavActive) {
            if let user = selectedUser {
                SelectClubScreen(
                    user:          user.toClubUser,
                    onRoleUpdated: { newRole, newClub in updateRole(for: user, newRole: newRole, newClub: newClub) },
                    dismissToRoot: dismissToRoot
                )
            }
        }
    }

    private func updateRole(for user: AdminUserResponse, newRole: String, newClub: String) {
        Task { await vm.load() }
    }

    private func dismissToRoot() {
        profileNavActive = false
        promoteNavActive = false
    }
}

// MARK: - Gradient Header
struct ManageUsersHeader: View {
    @Binding var showSearch: Bool
    @Binding var searchText: String
    let userCount: Int
    @Environment(\.dismiss) private var dismiss

    @State private var safeTop: CGFloat = 54

    var body: some View {
        ZStack(alignment: .top) {
            LinearGradient(
                colors: [Color.purple, Color.blue],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 16)

                // Back + Title + Search icon
                HStack(alignment: .center) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle()
                                .fill(Color.white.opacity(0.20))
                                .frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                        }
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Manage Users")
                            .font(.title2).bold()
                            .foregroundColor(.white)
                            .lineLimit(1)
                        Text("Assign club leadership roles")
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.80))
                    }
                    .padding(.leading, 8)

                    Spacer()

                    Button(action: { withAnimation { showSearch.toggle() } }) {
                        ZStack {
                            Circle()
                                .fill(Color.white.opacity(0.20))
                                .frame(width: 40, height: 40)
                            Image(systemName: showSearch ? "xmark" : "magnifyingglass")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                        }
                    }
                }
                .padding(.horizontal, 18)

                // Inline search bar
                if showSearch {
                    HStack(spacing: 10) {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.white.opacity(0.7))
                        TextField("", text: $searchText,
                                  prompt: Text("Search by name, role or club…")
                                    .foregroundColor(.white.opacity(0.6)))
                            .foregroundColor(.white)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(Color.white.opacity(0.18))
                    .cornerRadius(12)
                    .padding(.horizontal, 18)
                    .padding(.top, 12)
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }

                // Summary badge
                HStack(spacing: 6) {
                    Image(systemName: "person.3.fill")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                    Text("\(userCount) registered users")
                        .font(.caption).fontWeight(.medium)
                        .foregroundColor(.white.opacity(0.80))
                }
                .padding(.horizontal, 18)
                .padding(.top, 12)
                .padding(.horizontal)
            }
        }
        .frame(minHeight: safeTop + (showSearch ? 180 : 140))
        .animation(.easeInOut(duration: 0.2), value: showSearch)
        .onAppear {
            let top = UIApplication.shared.connectedScenes
                .compactMap { $0 as? UIWindowScene }
                .first?.windows.first?.safeAreaInsets.top ?? 50
            if top > 0 { self.safeTop = top }
        }
    }
}

// MARK: - All Users Section
struct AllUsersSection: View {
    let users:         [AdminUserResponse]
    let vm:            ManageUsersViewModel
    let onPromote:     (AdminUserResponse) -> Void
    let onViewProfile: (AdminUserResponse) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeaderRow(title: "All Users")

            if users.isEmpty {
                Text("No users found.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity)
                    .padding()
            } else {
                VStack(spacing: 14) {
                    ForEach(users) { user in
                        UserCard(
                            user: user,
                            initials: vm.getInitials(user.name),
                            onPromote:     { onPromote(user) },
                            onViewProfile: { onViewProfile(user) }
                        )
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

// MARK: - User Card
struct UserCard: View {
    let user:          AdminUserResponse
    let initials:      String
    let onPromote:     () -> Void
    let onViewProfile: () -> Void

    // Role badge colours
    private var roleColor: Color {
        switch user.role {
        case "President":      return .purple
        case "Vice President": return .blue
        case "Secretary":      return .teal
        default:               return Color(UIColor.systemGray)
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            // ── Top Row: Avatar + Info + Role Badge ────────────────────
            HStack(spacing: 14) {
                UserAvatarView(
                    url: user.profile_picture_url,
                    name: user.name,
                    size: 52
                )

                VStack(alignment: .leading, spacing: 4) {
                    Text(user.name)
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    if ["President", "Vice President", "VicePresident", "Secretary"].contains(user.role) {
                        // For leaders, show club name instead of email
                        HStack(spacing: 4) {
                            Image(systemName: "building.2.fill")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                            Text(user.club_name ?? "Assigned Club")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .lineLimit(1)
                        }
                    } else {
                        // For regular students, keep email
                        HStack(spacing: 4) {
                            Image(systemName: "envelope.fill")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                            Text(user.email)
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .lineLimit(1)
                        }
                    }
                }

                Spacer(minLength: 0)

                // Role badge
                Text(user.role)
                    .font(.caption2).fontWeight(.bold)
                    .foregroundColor(roleColor)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(roleColor.opacity(0.12))
                    .clipShape(Capsule())
            }



            // ── Action Buttons ────────────────────────────────────────
            HStack(spacing: 12) {
                Button(action: onViewProfile) {
                    HStack(spacing: 6) {
                        Image(systemName: "person.text.rectangle.fill")
                        Text("View Profile")
                    }
                    .font(.subheadline).fontWeight(.semibold)
                    .foregroundColor(.purple)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(Color.purple.opacity(0.10))
                    .cornerRadius(10)
                }

                Button(action: onPromote) {
                    HStack(spacing: 6) {
                        Image(systemName: "arrow.up.circle.fill")
                        Text("Promote")
                    }
                    .font(.subheadline).fontWeight(.semibold)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(
                        LinearGradient(colors: [Color.purple, Color.blue],
                                       startPoint: .leading, endPoint: .trailing)
                    )
                    .cornerRadius(10)
                }
            }
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.06), radius: 6, x: 0, y: 3)
    }
}

// MARK: - Top Performers Section
struct TopPerformersSection: View {
    let topUsers: [ClubUser]
    let onPromote: (ClubUser) -> Void

    private let medals = ["🥇", "🥈", "🥉"]

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeaderRow(title: "Top Active Students")

            VStack(spacing: 10) {
                ForEach(Array(topUsers.enumerated()), id: \.element.id) { idx, user in
                    TopPerformerRow(
                        medal:   medals[safe: idx] ?? "⭐",
                        rank:    idx + 1,
                        user:    user,
                        onPromote: { onPromote(user) }
                    )
                }
            }
            .padding(.horizontal)
        }
    }
}

struct TopPerformerRow: View {
    let medal:    String
    let rank:     Int
    let user:     ClubUser
    let onPromote: () -> Void

    var body: some View {
        HStack(spacing: 14) {
            // Medal / rank
            Text(medal)
                .font(.title2)
                .frame(width: 36)

            // Avatar
            UserAvatarView(
                url: user.profile_picture_url,
                name: user.name,
                size: 44
            )

            // Info
            VStack(alignment: .leading, spacing: 3) {
                Text(user.name)
                    .font(.subheadline).fontWeight(.semibold)
                    .foregroundColor(.primary)
                HStack(spacing: 4) {
                    Image(systemName: "flame.fill")
                        .font(.caption2)
                        .foregroundColor(.orange)
                    Text("Engagement \(user.engagement)%")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }

            Spacer(minLength: 0)

            // Promote button
            Button(action: onPromote) {
                Text("Promote")
                    .font(.caption).fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 7)
                    .background(
                        LinearGradient(colors: [Color.purple, Color.blue],
                                       startPoint: .leading, endPoint: .trailing)
                    )
                    .clipShape(Capsule())
            }
        }
        .padding(12)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

// MARK: - Safe Array Subscript
private extension Array {
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}

// Compact stat cell used inside a card
struct UserStatPill: View {
    let icon:  String
    let color: Color
    let label: String
    let value: String

    var body: some View {
        VStack(spacing: 3) {
            HStack(spacing: 3) {
                Image(systemName: icon)
                    .font(.caption2)
                    .foregroundColor(color)
                Text(value)
                    .font(.subheadline).fontWeight(.bold)
                    .foregroundColor(.primary)
            }
            Text(label)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}




struct ProfileStatCard: View {
    let icon:  String
    let color: Color
    let label: String
    let value: String

    var body: some View {
        VStack(spacing: 8) {
            ZStack {
                Circle().fill(color.opacity(0.12)).frame(width: 44, height: 44)
                Image(systemName: icon).font(.system(size: 18)).foregroundColor(color)
            }
            Text(value)
                .font(.title3).bold()
                .foregroundColor(.primary)
            Text(label)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

struct ProfileInfoRow: View {
    let icon:  String
    let color: Color
    let title: String
    let value: String

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 8)
                    .fill(color)
                    .frame(width: 32, height: 32)
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.white)
            }
            Text(title)
                .font(.body)
                .foregroundColor(.primary)
            Spacer()
            Text(value)
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(.secondary)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }
}

// MARK: - Preview
struct ManageUsersScreen_Previews: PreviewProvider {
    static var previews: some View {
        PreviewWrapper {
        NavigationStack {
            ManageUsersScreen()
        }
        .previewDisplayName("Manage Users")
    
        }
    }
}
