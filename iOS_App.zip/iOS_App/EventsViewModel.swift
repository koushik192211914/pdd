//
//  EventsViewModel.swift
//  CLUB ANALYTICSs
//

import Foundation
import Combine

@MainActor
final class EventsViewModel: ObservableObject {
    @Published var events: [EventResponse] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    func load() {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                events = try await EventService.shared.getEvents()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func loadForClub(clubId: Int) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                events = try await EventService.shared.getEvents(clubId: clubId)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
