from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import User, UserRole
from pydantic import BaseModel
from core.permissions import require_admin
from schemas import UserResponse

router = APIRouter(prefix="/admin", tags=["Admin"])

class PromoteRequest(BaseModel):
    role: str

@router.get("/users", response_model=List[UserResponse])
def get_all_users(db: Session = Depends(get_db), admin_user: User = Depends(require_admin)):
    users = db.query(User).all()
    return users

@router.post("/promote/{user_id}")
def promote_user(user_id: int, payload: PromoteRequest, db: Session = Depends(get_db), admin_user: User = Depends(require_admin)):
    valid_roles = [
        UserRole.President.value,
        UserRole.VicePresident.value,
        UserRole.Secretary.value,
        UserRole.Treasurer.value
    ]
    if payload.role not in valid_roles:
        raise HTTPException(status_code=400, detail="Invalid role")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.role = UserRole(payload.role)
    db.commit()
    return {"message": f"User promoted to {payload.role}"}

@router.post("/demote/{user_id}")
def demote_user(user_id: int, db: Session = Depends(get_db), admin_user: User = Depends(require_admin)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.role = UserRole.Student
    db.commit()
    return {"message": "User demoted to Student"}

class ChangeLeadershipRequest(BaseModel):
    new_leader_id: int

@router.post("/change-leadership/{user_id}")
def change_leadership(user_id: int, payload: ChangeLeadershipRequest, db: Session = Depends(get_db), admin_user: User = Depends(require_admin)):
    current_leader = db.query(User).filter(User.id == user_id).first()
    new_leader = db.query(User).filter(User.id == payload.new_leader_id).first()

    if not current_leader or not new_leader:
        raise HTTPException(status_code=404, detail="User not found")

    if current_leader.role == UserRole.Student:
        raise HTTPException(status_code=400, detail="Current user is not a leader")

    # Swap roles: new leader gets current leader's role, current leader becomes student
    old_role = current_leader.role
    current_leader.role = UserRole.Student
    new_leader.role = old_role

    db.commit()
    return {"message": f"Leadership changed. {new_leader.name} is now {old_role.value if hasattr(old_role, 'value') else old_role}."}
