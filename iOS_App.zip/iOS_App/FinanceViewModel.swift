//
//  FinanceViewModel.swift
//  CLUB ANALYTICSs
//

import Foundation
import Combine

@MainActor
final class FinanceViewModel: ObservableObject {
    @Published var budget: BudgetStatusResponse?
    @Published var expenses: [ExpenseResponse] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var successMessage: String?

    func load(clubId: Int) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                async let b = FinanceService.shared.getBudget(clubId: clubId)
                async let e = FinanceService.shared.getExpenses(clubId: clubId)
                let (budget, expenses) = try await (b, e)
                self.budget   = budget
                self.expenses = expenses
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func addExpense(clubId: Int, title: String, amount: Double, description: String?, onComplete: @escaping () -> Void) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                _ = try await FinanceService.shared.addExpense(
                    clubId: clubId,
                    title: title,
                    amount: amount,
                    description: description
                )
                successMessage = "Expense added successfully."
                load(clubId: clubId)
                onComplete()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
