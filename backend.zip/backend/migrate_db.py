import sys
import os
sys.path.append("/Users/sail/Desktop/CLUB ANALYTICSs/backend")

try:
    from database import engine
    from sqlalchemy import text

    with engine.connect() as connection:
        # 1. Add category column to clubs
        print("Adding 'category' column to 'clubs' table...")
        try:
            connection.execute(text("ALTER TABLE clubs ADD COLUMN category VARCHAR(100) AFTER club_name;"))
            connection.commit()
            print("Successfully added 'category' column.")
        except Exception as e:
            if "Duplicate column name" in str(e):
                print("Column 'category' already exists.")
            else:
                print(f"Error adding category column: {e}")

    print("\nMigration completed.")

except Exception as e:
    print(f"Migration failed: {e}")
