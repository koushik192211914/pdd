import SwiftUI
import Combine


// MARK: ─────────────────────────────────────────────────────────────
// ADMIN SCREENS
// • CreateClubScreen   — form with fields + success confirmation
// • CreateEventScreen  — form with fields + success confirmation
// • EventDetailsScreen — full event detail with participants list
// All screens share the app's gradient-header design system.
// ─────────────────────────────────────────────────────────────────

// MARK: - Reusable form field wrapper
private struct FormField: View {
    let icon:    String
    let color:   Color
    let label:   String
    let content: AnyView

    init(icon: String, color: Color, label: String, @ViewBuilder content: () -> some View) {
        self.icon = icon; self.color = color; self.label = label
        self.content = AnyView(content())
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: icon).font(.caption).foregroundColor(color)
                Text(label).font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
            }
            content
        }
    }
}

private struct StyledTextField: View {
    let placeholder: String
    @Binding var text: String
    var axis: Axis = .horizontal

    var body: some View {
        TextField(placeholder, text: $text, axis: axis)
            .font(.subheadline)
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .background(Color(UIColor.tertiarySystemGroupedBackground))
            .cornerRadius(12)
            .lineLimit(axis == .vertical ? 4 : 1)
    }
}

// MARK: - CREATE CLUB — ViewModel
@MainActor
final class AdminCreateClubViewModel: ObservableObject {
    @Published var isLoading  = false
    @Published var errorMsg:  String? = nil
    @Published var didSucceed = false
    @Published var createdName = ""

    func createClub(name: String, description: String, instagramUrl: String?) async {
        isLoading = true
        errorMsg  = nil
        do {
            let result = try await ClubService.shared.createClub(name: name, description: description, instagramUrl: instagramUrl.flatMap { $0.isEmpty ? nil : $0 })
            createdName = result.name
            didSucceed  = true
        } catch {
            errorMsg = error.localizedDescription
        }
        isLoading = false
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - CREATE CLUB SCREEN
// ─────────────────────────────────────────────────────────────────
struct CreateClubScreen: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = AdminCreateClubViewModel()

    @State private var clubName:    String = ""
    @State private var category:    String = ""
    @State private var description: String = ""
    @State private var instagramUrl: String = ""
    @State private var showValidationMsg = false

    private let categories = ["Technology","Engineering","Business","Arts & Design",
                               "Science","Leadership","Sports","Social","Music","Other"]

    private var isFormValid: Bool {
        !clubName.trimmingCharacters(in: .whitespaces).isEmpty
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                AdminWorkflowHeader(title: "Create Club",
                                    subtitle: "Register a new club on the platform")

                VStack(spacing: 22) {
                    // Error / success banners
                    if let err = viewModel.errorMsg {
                        HStack(spacing: 10) {
                            Image(systemName: "xmark.octagon.fill").foregroundColor(.red)
                            Text(err).font(.caption).foregroundColor(.red)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(14)
                        .background(Color.red.opacity(0.09))
                        .cornerRadius(12)
                    }

                    // Form card
                    VStack(spacing: 18) {
                        FormField(icon: "building.2.fill", color: .purple, label: "Club Name") {
                            StyledTextField(placeholder: "e.g. Tech Innovation Club",
                                            text: $clubName)
                        }

                        FormField(icon: "tag.fill", color: .blue, label: "Category") {
                            Menu {
                                ForEach(categories, id: \.self) { cat in
                                    Button(cat) { category = cat }
                                }
                            } label: {
                                HStack {
                                    Text(category.isEmpty ? "Select a category" : category)
                                        .font(.subheadline)
                                        .foregroundColor(category.isEmpty ? Color(UIColor.placeholderText) : .primary)
                                    Spacer()
                                    Image(systemName: "chevron.up.chevron.down")
                                        .font(.caption).foregroundColor(.secondary)
                                }
                                .padding(.horizontal, 14).padding(.vertical, 12)
                                .background(Color(UIColor.tertiarySystemGroupedBackground))
                                .cornerRadius(12)
                            }
                        }

                        FormField(icon: "text.alignleft", color: .teal, label: "Description") {
                            StyledTextField(placeholder: "Describe the club's purpose and activities…",
                                            text: $description, axis: .vertical)
                        }

                        FormField(icon: "camera.fill", color: .pink, label: "Instagram URL (Optional)") {
                            StyledTextField(placeholder: "https://instagram.com/yourclub",
                                            text: $instagramUrl)
                        }
                    }
                    .padding(18)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 3)

                    if showValidationMsg {
                        HStack(spacing: 8) {
                            Image(systemName: "exclamationmark.circle.fill")
                                .foregroundColor(.red).font(.caption)
                            Text("Club Name is required.")
                                .font(.caption).foregroundColor(.red)
                        }
                        .padding(.horizontal, 4)
                    }

                    // Submit
                    Button(action: {
                        guard isFormValid else { withAnimation { showValidationMsg = true }; return }
                        showValidationMsg = false
                        Task { await viewModel.createClub(name: clubName.trimmingCharacters(in: .whitespaces),
                                                          description: description.trimmingCharacters(in: .whitespaces),
                                                          instagramUrl: instagramUrl.trimmingCharacters(in: .whitespaces)) }
                    }) {
                        HStack(spacing: 8) {
                            if viewModel.isLoading {
                                ProgressView().tint(.white)
                            } else {
                                Image(systemName: "building.2.crop.circle.fill")
                                    .font(.system(size: 18, weight: .semibold))
                            }
                            Text(viewModel.isLoading ? "Creating…" : "Create Club").font(.headline)
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity).padding(.vertical, 16)
                        .background(LinearGradient(colors: [Color.purple, Color.blue],
                                                   startPoint: .leading, endPoint: .trailing))
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .shadow(color: Color.purple.opacity(0.30), radius: 8, x: 0, y: 4)
                    }
                    .disabled(viewModel.isLoading)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 48)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .alert("Club Created Successfully 🎉", isPresented: $viewModel.didSucceed) {
            Button("Done", role: .cancel) { dismiss() }
        } message: {
            Text("\"\(viewModel.createdName)\" has been registered on the platform.")
        }
    }
}

// MARK: - CREATE EVENT — ViewModel
@MainActor
final class AdminCreateEventViewModel: ObservableObject {
    @Published var clubs:     [ClubResponse] = []
    @Published var isLoadingClubs = true
    @Published var clubsError: String? = nil

    @Published var isSubmitting = false
    @Published var errorMsg:    String? = nil
    @Published var didSucceed   = false
    @Published var createdName  = ""
    @Published var createdClubName = ""

    func loadClubs() async {
        isLoadingClubs = true
        clubsError = nil
        do {
            clubs = try await ClubService.shared.getClubs()
        } catch {
            clubsError = "Failed to load clubs: \(error.localizedDescription)"
        }
        isLoadingClubs = false
    }

    func createEvent(name: String, description: String,
                     clubId: Int, date: Date) async {
        isSubmitting = true
        errorMsg = nil
        do {
            let result = try await EventService.shared.createEvent(
                title: name, description: description, clubId: clubId, date: date)
            createdName  = result.title
            createdClubName = clubs.first { $0.id == clubId }?.name ?? ""
            didSucceed = true
        } catch {
            errorMsg = error.localizedDescription
        }
        isSubmitting = false
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - CREATE EVENT SCREEN
// ─────────────────────────────────────────────────────────────────
struct CreateEventScreen: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = AdminCreateEventViewModel()

    @State private var eventName:    String = ""
    @State private var selectedClubId: Int? = nil
    @State private var eventDate:    Date   = Date().addingTimeInterval(86400)
    @State private var eventTime:    Date   = Date()
    @State private var location:     String = ""
    @State private var description:  String = ""
    @State private var showValidationMsg = false

    private var combinedDate: Date {
        let cal = Calendar.current
        let dc  = cal.dateComponents([.hour, .minute], from: eventTime)
        return cal.date(bySettingHour: dc.hour ?? 0, minute: dc.minute ?? 0,
                        second: 0, of: eventDate) ?? eventDate
    }

    private var isFormValid: Bool {
        !eventName.trimmingCharacters(in: .whitespaces).isEmpty &&
        selectedClubId != nil &&
        !location.trimmingCharacters(in: .whitespaces).isEmpty
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                AdminWorkflowHeader(title: "Create Event",
                                    subtitle: "Schedule a new event for a club")

                VStack(spacing: 22) {
                    // Error banner
                    if let err = viewModel.errorMsg ?? viewModel.clubsError {
                        HStack(spacing: 10) {
                            Image(systemName: "xmark.octagon.fill").foregroundColor(.red)
                            Text(err).font(.caption).foregroundColor(.red)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(14)
                        .background(Color.red.opacity(0.09))
                        .cornerRadius(12)
                    }

                    VStack(spacing: 18) {
                        FormField(icon: "calendar.badge.plus", color: .purple, label: "Event Name") {
                            StyledTextField(placeholder: "e.g. Spring Hackathon 2026",
                                            text: $eventName)
                        }

                        // ── Club Picker — populated from API ───────────────
                        FormField(icon: "building.2.fill", color: .blue, label: "Select Club") {
                            if viewModel.isLoadingClubs {
                                HStack {
                                    ProgressView().scaleEffect(0.8)
                                    Text("Loading clubs…").font(.subheadline).foregroundColor(.secondary)
                                }
                                .padding(.horizontal, 14).padding(.vertical, 12)
                                .background(Color(UIColor.tertiarySystemGroupedBackground))
                                .cornerRadius(12)
                            } else if viewModel.clubs.isEmpty {
                                Text("No clubs available. Create one first.")
                                    .font(.subheadline).foregroundColor(.secondary)
                                    .padding(.horizontal, 14).padding(.vertical, 12)
                                    .background(Color(UIColor.tertiarySystemGroupedBackground))
                                    .cornerRadius(12)
                            } else {
                                Menu {
                                    ForEach(viewModel.clubs) { club in
                                        Button(club.name) { selectedClubId = club.id }
                                    }
                                } label: {
                                    HStack {
                                        Text(viewModel.clubs.first { $0.id == selectedClubId }?.name
                                             ?? "Choose a club")
                                            .font(.subheadline)
                                            .foregroundColor(selectedClubId == nil
                                                             ? Color(UIColor.placeholderText) : .primary)
                                        Spacer()
                                        Image(systemName: "chevron.up.chevron.down")
                                            .font(.caption).foregroundColor(.secondary)
                                    }
                                    .padding(.horizontal, 14).padding(.vertical, 12)
                                    .background(Color(UIColor.tertiarySystemGroupedBackground))
                                    .cornerRadius(12)
                                }
                            }
                        }

                        HStack(spacing: 14) {
                            FormField(icon: "calendar", color: .orange, label: "Event Date") {
                                DatePicker("", selection: $eventDate, displayedComponents: .date)
                                    .datePickerStyle(.compact)
                                    .labelsHidden()
                                    .padding(.horizontal, 14).padding(.vertical, 10)
                                    .background(Color(UIColor.tertiarySystemGroupedBackground))
                                    .cornerRadius(12)
                            }
                            FormField(icon: "clock.fill", color: .teal, label: "Time") {
                                DatePicker("", selection: $eventTime, displayedComponents: .hourAndMinute)
                                    .datePickerStyle(.compact)
                                    .labelsHidden()
                                    .padding(.horizontal, 14).padding(.vertical, 10)
                                    .background(Color(UIColor.tertiarySystemGroupedBackground))
                                    .cornerRadius(12)
                            }
                        }

                        FormField(icon: "mappin.circle.fill", color: .red, label: "Location") {
                            StyledTextField(placeholder: "e.g. Main Auditorium or Room 204",
                                            text: $location)
                        }

                        FormField(icon: "text.alignleft", color: .indigo, label: "Description") {
                            StyledTextField(placeholder: "What will happen at this event?",
                                            text: $description, axis: .vertical)
                        }
                    }
                    .padding(18)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 3)

                    if showValidationMsg {
                        HStack(spacing: 8) {
                            Image(systemName: "exclamationmark.circle.fill")
                                .foregroundColor(.red).font(.caption)
                            Text("Event Name, Club, and Location are required.")
                                .font(.caption).foregroundColor(.red)
                        }.padding(.horizontal, 4)
                    }

                    Button(action: {
                        guard isFormValid else { withAnimation { showValidationMsg = true }; return }
                        guard let cid = selectedClubId else { return }
                        showValidationMsg = false
                        Task {
                            await viewModel.createEvent(
                                name: eventName.trimmingCharacters(in: .whitespaces),
                                description: description.trimmingCharacters(in: .whitespaces),
                                clubId: cid,
                                date: combinedDate
                            )
                        }
                    }) {
                        HStack(spacing: 8) {
                            if viewModel.isSubmitting {
                                ProgressView().tint(.white)
                            } else {
                                Image(systemName: "calendar.badge.plus")
                                    .font(.system(size: 18, weight: .semibold))
                            }
                            Text(viewModel.isSubmitting ? "Scheduling…" : "Create Event").font(.headline)
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity).padding(.vertical, 16)
                        .background(
                            LinearGradient(colors: viewModel.clubs.isEmpty
                                           ? [Color.gray, Color.gray.opacity(0.8)]
                                           : [Color.purple, Color.blue],
                                           startPoint: .leading, endPoint: .trailing))
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .shadow(color: Color.purple.opacity(0.30), radius: 8, x: 0, y: 4)
                    }
                    .disabled(viewModel.isSubmitting || viewModel.clubs.isEmpty)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 48)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .task { await viewModel.loadClubs() }
        .alert("Event Created Successfully 🎉", isPresented: $viewModel.didSucceed) {
            Button("Done", role: .cancel) { dismiss() }
        } message: {
            Text("\"\(viewModel.createdName)\" has been scheduled for \(viewModel.createdClubName).")
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - EVENT DETAILS SCREEN (full — replaces placeholder)
// ─────────────────────────────────────────────────────────────────
struct EventDetailScreen: View {
    // Accept event details
    let eventId:   Int
    let clubId:    Int
    let title:     String
    let club:      String
    let day:       String
    let month:     String
    let time:      String
    let location:  String
    let registered:Int

    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: AttendanceNotificationStore
    @EnvironmentObject private var authManager: AuthManager
    
    @State private var substituteTarget: String? = nil
    @State private var showSubPicker: Bool = false

    // RSVP + Join Request states
    @State private var isSubmitting = false
    @State private var joinMessage: String?

    // Live participants from API
    @State private var liveRegisteredCount: Int = 0
    @State private var liveParticipantNames: [String] = []
    @State private var isUserRegistered: Bool = false
    @State private var isAttendanceSubmitted: Bool = false

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // ── Gradient header ───────────────────────────────────────
                eventDetailHeader

                VStack(alignment: .leading, spacing: 24) {
                    // ── Event info rows ───────────────────────────────────
                    infoSection

                    // ── Description ───────────────────────────────────────
                    aboutSection

                    // ── Participants ──────────────────────────────────────
                    participantsSection

                    // ── Smart Substitute Picker ───────────────────────────
                    if let target = substituteTarget, showSubPicker {
                        smartSubstitutePicker(for: target)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .padding(20)
                .padding(.bottom, 80)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .onAppear {
            Task { await fetchParticipants() }
        }
    }

    private func fetchParticipants() async {
        guard eventId > 0 else { return }
        struct ParticipantItem: Decodable {
            let student_id: Int
            let name: String
        }
        if let url = URL(string: "http://127.0.0.1:8000/registrations/event/\(eventId)/participants"),
           let (data, _) = try? await URLSession.shared.data(from: url),
           let items = try? JSONDecoder().decode([ParticipantItem].self, from: data) {
            await MainActor.run {
                liveRegisteredCount = items.count
                liveParticipantNames = items.map { $0.name }
                
                // If current user is in the list, mark as registered
                if let currentId = authManager.userId {
                    isUserRegistered = items.contains(where: { $0.student_id == currentId })
                }
            }
        }
        
        // Check if attendance is already submitted
        if let submitted = try? await EventAttendanceService.shared.hasSubmittedAttendance(eventId: eventId) {
            await MainActor.run { isAttendanceSubmitted = submitted }
        }
    }

    // MARK: Header
    private var eventDetailHeader: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [Color.purple, Color.blue],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)

            VStack(spacing: 0) {
                Color.clear.frame(height: safeTop + 4)
                HStack {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.22)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    Spacer()
                    // Date badge
                    VStack(spacing: 0) {
                        Text(month).font(.caption2).fontWeight(.bold).foregroundColor(.white.opacity(0.8))
                        Text(day).font(.title3).fontWeight(.bold).foregroundColor(.white)
                    }
                    .frame(width: 52, height: 52)
                    .background(Color.white.opacity(0.20))
                    .cornerRadius(14)
                }
                .padding(.horizontal, 18)

                VStack(spacing: 8) {
                    Text(title)
                        .font(.title3).bold().foregroundColor(.white)
                        .multilineTextAlignment(.center)
                    Text(club).font(.subheadline).foregroundColor(.white.opacity(0.85))
                }
                .padding(.top, 12).padding(.bottom, 24)
            }
        }
        .frame(height: safeTop + 180)
    }

    // MARK: Info rows
    private var infoSection: some View {
        VStack(spacing: 0) {
            EventInfoRow(icon: "clock.fill",       color: .purple,  label: "Date & Time",  value: "\(day) \(month) · \(time)")
            Divider().padding(.leading, 50)
            EventInfoRow(icon: "mappin.circle.fill",color: .blue,    label: "Location",     value: location)
            Divider().padding(.leading, 50)
            EventInfoRow(icon: "building.2.fill",  color: .orange,  label: "Organised By", value: club)
            Divider().padding(.leading, 50)
            EventInfoRow(icon: "person.2.fill",    color: .green,   label: "Registered",   value: "\(liveRegisteredCount) participants")
        }
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
    }

    // MARK: About
    private var aboutSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("About This Event").font(.headline)
            Text("Join us for an exciting session of \(title) organised by \(club). This event is a great opportunity to learn, network, and collaborate with fellow students and industry professionals. Don't miss out — spots are limited!")
                .font(.subheadline).foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                
            if let msg = joinMessage {
                Text(msg)
                    .font(.caption).foregroundColor(msg.contains("Failed") ? .red : .green)
                    .padding(.top, 4)
            }
                
            if authManager.clubRole == .student {
                if authManager.clubId == clubId {
                    Button(action: { Task { await rsvpToEvent() } }) {
                        if isSubmitting {
                            ProgressView().tint(.white).frame(maxWidth: .infinity).padding()
                                .background(Color.purple).cornerRadius(12)
                        } else if isUserRegistered {
                            Label("Already Registered", systemImage: "checkmark.circle.fill")
                                .font(.headline).foregroundColor(.white)
                                .frame(maxWidth: .infinity).padding()
                                .background(Color.green).cornerRadius(12)
                        } else {
                            Text("Register Now")
                                .font(.headline).foregroundColor(.white)
                                .frame(maxWidth: .infinity).padding()
                                .background(Color.purple).cornerRadius(12)
                        }
                    }
                    .disabled(isSubmitting || isUserRegistered)
                    .padding(.top, 10)
                } else {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("You must be a member of this club to join.").font(.caption).foregroundColor(.red)
                        Button(action: { Task { await requestJoin() } }) {
                            if isSubmitting {
                                ProgressView().tint(.white).frame(maxWidth: .infinity).padding()
                                    .background(Color.orange).cornerRadius(12)
                            } else {
                                Text("Request to Join Club")
                                    .font(.headline).foregroundColor(.white)
                                    .frame(maxWidth: .infinity).padding()
                                    .background(Color.orange).cornerRadius(12)
                            }
                        }
                        .disabled(isSubmitting)
                    }
                    .padding(.top, 10)
                }
            } else {
                Text("Administrators do not need to RSVP to view events.")
                    .font(.caption).italic().foregroundColor(.secondary).padding(.top, 4)
            }
            
            if authManager.clubRole == .admin {
                Button(action: { Task { await deleteEvent() } }) {
                    if isSubmitting {
                        ProgressView().tint(.white).frame(maxWidth: .infinity).padding()
                            .background(Color.red).cornerRadius(12)
                    } else {
                        Text("Delete Event")
                            .font(.headline).foregroundColor(.white)
                            .frame(maxWidth: .infinity).padding()
                            .background(Color.red).cornerRadius(12)
                    }
                }
                .disabled(isSubmitting)
                .padding(.top, 10)
            }
        }
    }
    
    private func deleteEvent() async {
        isSubmitting = true
        do {
            _ = try await EventService.shared.deleteEvent(eventId: eventId)
            joinMessage = "Event Deleted Successfully!"
        } catch {
            joinMessage = "Failed: \(error.localizedDescription)"
        }
        isSubmitting = false
    }
    
    private func rsvpToEvent() async {
        isSubmitting = true
        do {
            _ = try await EventService.shared.registerForEvent(eventId: eventId)
            joinMessage = "Successfully Registered for Event!"
            isUserRegistered = true
            await fetchParticipants()
        } catch {
            joinMessage = "Failed: \(error.localizedDescription)"
        }
        isSubmitting = false
    }
    
    private func requestJoin() async {
        // Only valid if user id is available
        guard let studentId = authManager.userId else { return }
        isSubmitting = true
        do {
            _ = try await JoinRequestService.shared.sendRequest(studentId: studentId, clubId: clubId)
            joinMessage = "Request Sent Successfully! Pending Approval."
        } catch {
            joinMessage = "Failed: \(error.localizedDescription)"
        }
        isSubmitting = false
    }

    // MARK: Participants
    private var participantsSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Participants").font(.headline)
                Spacer()
                Text("\(liveRegisteredCount) registered")
                    .font(.caption).foregroundColor(.secondary)
                    .padding(.horizontal, 10).padding(.vertical, 4)
                    .background(Color.purple.opacity(0.10))
                    .clipShape(Capsule())
            }
            VStack(spacing: 16) {
                if liveParticipantNames.isEmpty {
                    Text("No registered participants yet.")
                        .font(.caption).foregroundColor(.secondary)
                } else {
                    ForEach(liveParticipantNames, id: \.self) { name in
                        HStack(spacing: 12) {
                            ZStack {
                                Circle().fill(Color.purple.opacity(0.10)).frame(width: 36, height: 36)
                                Text(String(name.prefix(1)).uppercased()).font(.subheadline).fontWeight(.semibold).foregroundColor(.purple)
                            }
                            Text(name).font(.subheadline)
                            Spacer()
                        }
                        .padding(.horizontal, 4)
                    }
                }
            }
            
            // Mark Attendance Button for Leaders
            if authManager.clubRole == .president || authManager.clubRole == .vicePresident || authManager.clubRole == .secretary || authManager.clubRole == .admin {
                if isAttendanceSubmitted {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.seal.fill")
                        Text("Attendance Submitted")
                    }
                    .font(.headline).foregroundColor(.white)
                    .frame(maxWidth: .infinity).padding()
                    .background(Color.green).cornerRadius(12)
                    .padding(.top, 16)
                } else {
                    NavigationLink(destination: MarkAttendanceView(eventId: "\(eventId)", eventName: title, clubName: club).environmentObject(AttendanceNotificationStore())) {
                        HStack(spacing: 8) {
                            Image(systemName: "checkmark.seal.fill")
                            Text("Mark Attendance")
                        }
                        .font(.headline).foregroundColor(.white)
                        .frame(maxWidth: .infinity).padding()
                        .background(Color.blue).cornerRadius(12)
                    }
                    .padding(.top, 16)
                }
            }
        }
    }
    
    // MARK: - Interactive Participant Card
    private func participantCard(for p: ParticipantAttendance) -> some View {
        VStack(spacing: 0) {
            HStack(spacing: 14) {
                // Avatar
                ZStack {
                    Circle().fill(LinearGradient(
                        colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.5)],
                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 40, height: 40)
                    Text(p.initials).font(.system(size: 13, weight: .bold)).foregroundColor(.white)
                }
                
                // Name & State
                VStack(alignment: .leading, spacing: 4) {
                    Text(p.name).font(.subheadline).fontWeight(.semibold)
                    
                    // Status Badge
                    HStack(spacing: 4) {
                        Circle()
                            .fill(p.status.color)
                            .frame(width: 8, height: 8)
                        Text("Status: \(p.status.label)")
                            .font(.caption2)
                            .fontWeight(.medium)
                            .foregroundColor(p.status == .pending ? .secondary : p.status.color)
                    }
                }
                
                Spacer()
                
                // Static Icon (only if confirmed or substituted)
                if p.status == .confirmed {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.green).font(.title3)
                } else if case .substituted = p.status {
                    Image(systemName: "arrow.triangle.2.circlepath.circle.fill")
                        .foregroundColor(.orange).font(.title3)
                } else if p.status == .absent {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.red).font(.title3)
                }
            }
            
            // Action Buttons (Only when Pending)
            if p.status == .pending {
                Divider().padding(.vertical, 12)
                
                HStack(spacing: 12) {
                    Button(action: {
                        withAnimation { store.confirm(participantName: p.name, event: title) }
                    }) {
                        Text("Confirm")
                            .font(.caption).fontWeight(.bold)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity).padding(.vertical, 8)
                            .background(Color.green)
                            .cornerRadius(8)
                    }
                    
                    Button(action: {
                        withAnimation {
                            store.markAbsent(participantName: p.name, event: title)
                            substituteTarget = p.name
                            showSubPicker = true
                        }
                    }) {
                        Text("Absent")
                            .font(.caption).fontWeight(.bold)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity).padding(.vertical, 8)
                            .background(Color.red)
                            .cornerRadius(8)
                    }
                }
            }
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
    
    // MARK: - Smart Substitute Picker
    private func smartSubstitutePicker(for participantName: String) -> some View {
        let suggested = store.getSuggestedSubstitute(for: title)
        let others = store.getOtherSubstitutes(for: title, excluding: suggested?.name)
        
        return VStack(alignment: .leading, spacing: 14) {
            Text("Select Substitute").font(.subheadline).fontWeight(.bold)
            
            // Section 1: Suggested
            if let best = suggested {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Suggested Substitute ⭐")
                        .font(.caption).fontWeight(.bold)
                        .foregroundColor(.orange)
                    
                    substituteRow(member: best, target: participantName, isSuggested: true)
                }
            }
            
            // Section 2: Others
            if !others.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Other Available Members")
                        .font(.caption).fontWeight(.semibold)
                        .foregroundColor(.secondary)
                    
                    ForEach(others) { member in
                        substituteRow(member: member, target: participantName, isSuggested: false)
                    }
                }
            }
        }
        .padding(14)
        .background(Color.orange.opacity(0.08))
        .cornerRadius(14)
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.orange.opacity(0.3), lineWidth: 1))
        .padding(.horizontal, 8)
    }
    
    private func substituteRow(member: AttendanceNotificationStore.SubstituteMember, target: String, isSuggested: Bool) -> some View {
        Button(action: {
            withAnimation {
                store.assignSubstitute(participantName: target, substitute: member.name, event: title)
                showSubPicker = false
                substituteTarget = nil
            }
        }) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(member.name)
                        .font(.subheadline).fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    if isSuggested {
                        HStack(spacing: 8) {
                            Text("Engagement: \(member.engagementScore)%").font(.caption2).foregroundColor(.secondary)
                            Text("Attendance: \(member.attendanceRate)%").font(.caption2).foregroundColor(.secondary)
                        }
                    }
                }
                Spacer()
                Image(systemName: "plus.circle.fill")
                    .foregroundColor(isSuggested ? .orange : .blue)
            }
            .padding(12)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(10)
            .shadow(color: .black.opacity(0.03), radius: 2, x: 0, y: 1)
        }
    }
    

}

// MARK: - Event info row helper
private struct EventInfoRow: View {
    let icon:  String; let color: Color; let label: String; let value: String

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 8).fill(color)
                    .frame(width: 32, height: 32)
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .medium)).foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(label).font(.caption).foregroundColor(.secondary)
                Text(value).font(.subheadline).fontWeight(.semibold)
            }
            Spacer()
        }
        .padding(.horizontal, 16).padding(.vertical, 12)
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - CLUB DETAILS SCREEN (Admin view — adds Authorities + Events)
// ─────────────────────────────────────────────────────────────────
struct AdminClubDetailScreen: View {
    let club: ClubItem
    @Environment(\.dismiss) private var dismiss

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    // Sample leadership data for this club
    private let authorities: [(role: String, name: String, initials: String, color: Color, icon: String)] = [
        ("President",     "Alex Johnson",   "AJ", Color.purple, "star.fill"),
        ("Vice President","Emma Wilson",    "EW", Color.blue,   "star.leadinghalf.filled"),
        ("Secretary",     "Ryan Lee",       "RL", Color.teal,   "doc.fill"),
    ]

    // Sample events for this club
    private let clubEvents: [(day: String, month: String, title: String, time: String, location: String, registered: Int)] = [
        ("15","MAR","Hackathon 2026",       "9:00 AM",  "Main Auditorium",156),
        ("20","MAR","Tech Talk: AI Ethics", "2:00 PM",  "Room 204",       89),
        ("25","MAR","React Basics Workshop","3:00 PM",  "Lab 3",          45),
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // ── Header (reuses existing ClubDetailScreen header style) ─
                clubDetailHeader

                VStack(alignment: .leading, spacing: 24) {
                    // About
                    VStack(alignment: .leading, spacing: 8) {
                        Text("About").font(.headline)
                        Text(club.description)
                            .font(.subheadline).foregroundColor(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    // Stats
                    HStack(spacing: 14) {
                        AdminClubStat(value: "\(club.members)",     label: "Members",    icon: "person.2.fill",                color: .purple)
                        AdminClubStat(value: "\(club.engagement)%", label: "Engagement", icon: "chart.line.uptrend.xyaxis",   color: .blue)
                        AdminClubStat(value: club.category,          label: "Category",   icon: "tag.fill",                   color: club.iconColor)
                    }

                    // ── Authorities ───────────────────────────────────────
                    authoritiesSection

                    // ── Events ────────────────────────────────────────────
                    clubEventsSection
                }
                .padding(20)
                .padding(.bottom, 80)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
    }

    // MARK: Header
    private var clubDetailHeader: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [club.iconColor, .blue],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)

            VStack(spacing: 0) {
                Color.clear.frame(height: safeTop + 4)
                HStack {
                    Button { dismiss() } label: {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.22)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    Spacer()
                    // Admin badge
                    Text("Admin View")
                        .font(.caption2).fontWeight(.bold).foregroundColor(.white)
                        .padding(.horizontal, 10).padding(.vertical, 5)
                        .background(Color.white.opacity(0.22))
                        .clipShape(Capsule())
                }
                .padding(.horizontal, 18)

                VStack(spacing: 12) {
                    ZStack {
                        Circle().fill(Color.white.opacity(0.22)).frame(width: 80, height: 80)
                        Image(systemName: club.icon)
                            .font(.system(size: 34)).foregroundColor(.white)
                    }
                    Text(club.name).font(.title2).bold().foregroundColor(.white).multilineTextAlignment(.center)
                    Text(club.category).font(.subheadline).foregroundColor(.white.opacity(0.80))
                }
                .padding(.top, 8).padding(.bottom, 28)
            }
        }
        .frame(height: safeTop + 210)
    }

    // MARK: Authorities
    private var authoritiesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Club Authorities").font(.headline)
            VStack(spacing: 10) {
                ForEach(authorities, id: \.name) { auth in
                    HStack(spacing: 14) {
                        // Role icon
                        ZStack {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(LinearGradient(colors: [auth.color, auth.color.opacity(0.7)],
                                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                                .frame(width: 40, height: 40)
                            Image(systemName: auth.icon)
                                .font(.system(size: 16, weight: .medium)).foregroundColor(.white)
                        }
                        // Avatar + name
                        ZStack {
                            Circle().fill(LinearGradient(
                                colors: [Color.purple.opacity(0.6), Color.blue.opacity(0.4)],
                                startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: 36, height: 36)
                            Text(auth.initials).font(.system(size: 12, weight: .bold)).foregroundColor(.white)
                        }
                        VStack(alignment: .leading, spacing: 2) {
                            Text(auth.name).font(.subheadline).fontWeight(.semibold)
                            Text(auth.role).font(.caption).foregroundColor(auth.color)
                        }
                        Spacer()
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green).font(.caption)
                    }
                    .padding(12)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(14)
                    .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
                }
            }
        }
    }

    // MARK: Club events
    private var clubEventsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Club Events").font(.headline)
                Spacer()
                Text("\(clubEvents.count) events")
                    .font(.caption).foregroundColor(.secondary)
                    .padding(.horizontal, 10).padding(.vertical, 4)
                    .background(Color.purple.opacity(0.10)).clipShape(Capsule())
            }
            VStack(spacing: 10) {
                ForEach(clubEvents, id: \.title) { ev in
                    NavigationLink(destination: EventDetailScreen(
                        eventId: 0, clubId: 0,
                        title: ev.title, club: club.name,
                        day: ev.day, month: ev.month,
                        time: ev.time, location: ev.location,
                        registered: ev.registered
                    )) {
                        HStack(spacing: 14) {
                            VStack(spacing: 2) {
                                Text(ev.month).font(.caption2).fontWeight(.bold).foregroundColor(.purple)
                                Text(ev.day).font(.title3).fontWeight(.bold).foregroundColor(.primary)
                            }
                            .frame(width: 48, height: 48)
                            .background(Color.purple.opacity(0.09)).cornerRadius(12)

                            VStack(alignment: .leading, spacing: 4) {
                                Text(ev.title).font(.subheadline).fontWeight(.semibold).lineLimit(1)
                                HStack(spacing: 8) {
                                    Label(ev.time, systemImage: "clock")
                                    Label(ev.location, systemImage: "mappin")
                                }
                                .font(.caption).foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(Color(UIColor.tertiaryLabel))
                        }
                        .padding(14)
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(14)
                        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
        }
    }
}

private struct AdminClubStat: View {
    let value: String; let label: String; let icon: String; let color: Color
    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon).font(.system(size: 16)).foregroundColor(color)
            Text(value).font(.subheadline).fontWeight(.bold)
            Text(label).font(.caption2).foregroundColor(.secondary).lineLimit(1)
        }
        .frame(maxWidth: .infinity).padding(.vertical, 12)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14).shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - Shared Admin Workflow Header (gradient + back button)
// ─────────────────────────────────────────────────────────────────
struct AdminWorkflowHeader: View {
    let title: String
    let subtitle: String
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [Color.purple, Color.blue],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 8)
                HStack(alignment: .center, spacing: 12) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title).font(.title3).bold().foregroundColor(.white).lineLimit(1)
                        Text(subtitle).font(.caption).foregroundColor(.white.opacity(0.80)).lineLimit(1)
                    }
                    Spacer()
                }
                .padding(.horizontal, 18).padding(.bottom, 22)
            }
        }
        .frame(minHeight: safeTop + 92)
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - Previews
// ─────────────────────────────────────────────────────────────────
struct AdminScreens_Previews: PreviewProvider {
    static var previews: some View {
        PreviewWrapper {
        Group {
            NavigationStack { CreateClubScreen() }
                .previewDisplayName("Create Club")
            NavigationStack { CreateEventScreen() }
                .previewDisplayName("Create Event")
            NavigationStack {
                EventDetailScreen(eventId: 0, clubId: 0, title: "Hackathon 2026", club: "Tech Innovation Club",
                                  day: "15", month: "MAR", time: "9:00 AM",
                                  location: "Main Auditorium", registered: 156)
            }
            .environmentObject(AttendanceNotificationStore())
            .previewDisplayName("Event Detail")
            NavigationStack {
                AdminClubDetailScreen(club: ClubItem(
                    name: "Tech Innovation Club", category: "Technology",
                    icon: "cpu.fill", iconColor: .purple, members: 245,
                    engagement: 94,
                    description: "Exploring cutting-edge technology through hackathons, workshops, and collaborative projects."
                ))
            }
            .previewDisplayName("Admin Club Detail")
        }
    
        }
    }
}
