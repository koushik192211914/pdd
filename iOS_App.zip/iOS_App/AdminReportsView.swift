import SwiftUI
import Combine
import Foundation

@MainActor
final class AdminReportsViewModel: ObservableObject {
    @Published var reports: [ReportResponse] = []
    @Published var isLoading = false
    @Published var errorMsg: String? = nil
    
    func fetchReports() async {
        isLoading = true
        errorMsg = nil
        do {
            let fetched = try await ReportService.shared.getReports()
            // Sort by latest submitted
            self.reports = fetched.sorted { 
                let d1 = isoFormatter.date(from: $0.submitted_at) ?? Date()
                let d2 = isoFormatter.date(from: $1.submitted_at) ?? Date()
                return d1 > d2
            }
        } catch {
            self.errorMsg = error.localizedDescription
        }
        isLoading = false
    }
    
    private let isoFormatter: ISO8601DateFormatter = {
        let fmt = ISO8601DateFormatter()
        fmt.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return fmt
    }()
}

struct AdminReportsView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = AdminReportsViewModel()
    
    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // Header
                ZStack(alignment: .top) {
                    LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                        .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                        .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

                    VStack(alignment: .leading, spacing: 0) {
                        Color.clear.frame(height: safeTop + 8)
                        HStack(alignment: .center, spacing: 12) {
                            Button(action: { dismiss() }) {
                                ZStack {
                                    Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                                    Image(systemName: "chevron.left")
                                        .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                                }
                            }
                            VStack(alignment: .leading, spacing: 2) {
                                Text("View Reports").font(.title3).bold().foregroundColor(.white)
                                Text("Submitted Event & Meeting Reports")
                                    .font(.caption).foregroundColor(.white.opacity(0.80)).lineLimit(1)
                            }
                            Spacer()
                        }
                        .padding(.horizontal, 18).padding(.bottom, 22)
                    }
                }
                .frame(height: safeTop + 92)

                // List
                VStack(spacing: 20) {
                    if viewModel.isLoading {
                        ProgressView().scaleEffect(1.2).padding(.top, 40)
                    } else if let error = viewModel.errorMsg {
                        Text("Failed to load reports: \(error)")
                            .foregroundColor(.red).padding(.top, 40)
                    } else if viewModel.reports.isEmpty {
                        Text("No reports found.")
                            .foregroundColor(.secondary).padding(.top, 40)
                    } else {
                        ForEach(viewModel.reports) { report in
                            ReportCardView(report: report)
                        }
                    }
                }
                .padding(20)
                .padding(.bottom, 60)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .task {
            await viewModel.fetchReports()
        }
    }
}

// Custom Card for Reports
private struct ReportCardView: View {
    let report: ReportResponse
    
    var imageUrl: URL? {
        guard let path = report.file_url, !path.isEmpty else { return nil }
        return URL(string: "http://127.0.0.1:8000\(path)")
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Top Row
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(report.title)
                        .font(.headline)
                        .foregroundColor(.primary)
                        .lineLimit(1)
                    Text(report.club_name ?? "Unknown Club")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.purple)
                }
                Spacer()
                Text(report.report_type)
                    .font(.caption2).fontWeight(.bold)
                    .padding(.horizontal, 8).padding(.vertical, 4)
                    .background(Color.blue.opacity(0.1))
                    .foregroundColor(.blue)
                    .cornerRadius(8)
            }
            
            Divider()
            
            // Details
            HStack(spacing: 6) {
                Image(systemName: "calendar.badge.clock")
                    .foregroundColor(.secondary).font(.caption)
                Text("Event: \(report.event_name ?? "Unknown Event")")
                    .font(.caption).foregroundColor(.secondary)
            }
            
            if let desc = report.description, !desc.isEmpty {
                Text(desc)
                    .font(.subheadline)
                    .foregroundColor(.primary)
                    .lineLimit(4)
                    .padding(.top, 2)
            }
            
            // Image
            if let url = imageUrl {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        ProgressView().frame(height: 150).frame(maxWidth: .infinity)
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                            .frame(height: 180)
                            .frame(maxWidth: .infinity)
                            .clipped()
                            .cornerRadius(12)
                    case .failure:
                        Image(systemName: "photo")
                            .font(.system(size: 40))
                            .foregroundColor(.gray)
                            .frame(height: 150)
                            .frame(maxWidth: .infinity)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(12)
                    @unknown default:
                        EmptyView()
                    }
                }
                .padding(.top, 8)
            }
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.04), radius: 6, x: 0, y: 3)
    }
}
