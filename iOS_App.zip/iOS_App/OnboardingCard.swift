//
//  OnboardingCard.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Reusable onboarding page card (light-theme)
//

import SwiftUI

struct OnboardingCard: View {
    let model: OnboardingCardModel
    @State private var iconAppeared = false

    var body: some View {
        VStack(spacing: 0) {

            Spacer()

            // ── Icon circle ───────────────────────────────────────────────
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(red: 0.92, green: 0.88, blue: 1.0),
                                Color(red: 0.85, green: 0.78, blue: 1.0)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 120, height: 120)

                Image(systemName: model.iconName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 52, height: 52)
                    .foregroundColor(Color(red: 0.55, green: 0.18, blue: 0.95))
            }
            .scaleEffect(iconAppeared ? 1.0 : 0.6)
            .opacity(iconAppeared ? 1.0 : 0.0)

            Spacer().frame(height: 40)

            // ── Title ─────────────────────────────────────────────────────
            Text(model.title)
                .font(.system(size: 26, weight: .bold))
                .foregroundColor(Color(red: 0.10, green: 0.10, blue: 0.12))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
                .opacity(iconAppeared ? 1.0 : 0.0)

            Spacer().frame(height: 14)

            // ── Description ───────────────────────────────────────────────
            Text(model.description)
                .font(.system(size: 15, weight: .regular))
                .foregroundColor(Color(red: 0.45, green: 0.45, blue: 0.50))
                .multilineTextAlignment(.center)
                .lineSpacing(4)
                .padding(.horizontal, 36)
                .opacity(iconAppeared ? 1.0 : 0.0)

            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear {
            withAnimation(.spring(response: 0.55, dampingFraction: 0.72).delay(0.08)) {
                iconAppeared = true
            }
        }
        .onDisappear {
            // Reset so the animation replays when the user swipes back
            iconAppeared = false
        }
    }
}

// ── Data model ────────────────────────────────────────────────────────────────
struct OnboardingCardModel: Identifiable {
    let id: Int
    let iconName: String
    let title: String
    let description: String
}

// ── Preview ───────────────────────────────────────────────────────────────────
#Preview {
    PreviewWrapper {
    OnboardingCard(model: OnboardingCardModel(
        id: 0,
        iconName: "brain.head.profile",
        title: "Welcome to ClubSphere AI",
        description: "Manage clubs, track engagement, and organize events intelligently using AI-powered analytics."
    ))
    .background(Color(red: 0.97, green: 0.97, blue: 0.98))

    }
}
