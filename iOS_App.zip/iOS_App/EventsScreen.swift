//
//  EventsScreen.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Shared Events screen (all roles)
//  Role permissions:
//    President / VP / Secretary → can see + tap Add Event (+)
//    Student             → view-only
//

import SwiftUI

// MARK: - Events Screen
struct EventsScreen: View {
    let role: ClubRole

    @State private var selectedTab: EventFilter = .upcoming
    @State private var showSearch = false
    @State private var showNotificationPanel = false
    @StateObject private var vm = NotificationViewModel()
    @EnvironmentObject private var authManager: AuthManager

    // Roles that can create events
    private var canCreateEvents: Bool {
        [ClubRole.president, .vicePresident, .admin].contains(role)
    }

    @State private var safeTop: CGFloat = 54

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {

                // ── HEADER ───────────────────────────────────────────────────
                eventsHeader

                VStack(spacing: 20) {
                    // ── FILTER TABS ──────────────────────────────────────────
                    EventFilterBar(selected: $selectedTab)

                    // ── EVENT LIST ───────────────────────────────────────────
                    EventListSection(role: role, filter: selectedTab, canCreate: canCreateEvents)
                }
                .padding(.top, 20)
                .padding(.bottom, 100)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .onAppear {
            let top = UIApplication.shared.connectedScenes
                .compactMap { $0 as? UIWindowScene }
                .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
            if top > 0 { self.safeTop = top }
        }
    }

    // MARK: – Header
    private var eventsHeader: some View {
        ZStack(alignment: .top) {
            LinearGradient(
                colors: [Color.purple, Color.blue],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 16)

                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Events")
                            .font(.title2).bold()
                            .foregroundColor(.white)
                        Text("Manage your club events")
                            .font(.subheadline).fontWeight(.medium)
                            .foregroundColor(.white.opacity(0.80))
                    }
                    Spacer()
                    // Add button — visible only for President / VP / Secretary
                    if canCreateEvents {
                        NavigationLink(destination: CreateEventScreen()) {
                            ZStack {
                                Circle().fill(Color.white.opacity(0.22)).frame(width: 44, height: 44)
                                Image(systemName: "plus")
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(.white)
                            }
                        }
                    } else {
                        // Bell for non-admin roles
                        Button(action: { showNotificationPanel = true }) {
                            ZStack {
                                Circle()
                                    .fill(Color.white.opacity(0.2))
                                    .frame(width: 44, height: 44)
                                Image(systemName: "bell.badge.fill")
                                    .foregroundColor(.white)
                            }
                        }
                        .sheet(isPresented: $showNotificationPanel) {
                            NavigationStack {
                                NotificationsView(role: role, vm: vm)
                                    .onAppear {
                                        if let uid = authManager.userId {
                                            vm.load(userId: uid, role: role.rawValue)
                                        }
                                    }
                            }
                        }
                    }
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 24)
            }
        }
        .frame(height: safeTop + 110)
    }
}

// MARK: - Filter enum
enum EventFilter: String, CaseIterable {
    case upcoming = "Upcoming"
    case past     = "Past"
}

// MARK: - Filter bar
private struct EventFilterBar: View {
    @Binding var selected: EventFilter

    var body: some View {
        HStack(spacing: 0) {
            ForEach(EventFilter.allCases, id: \.self) { filter in
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { selected = filter }
                } label: {
                    Text(filter.rawValue)
                        .font(.subheadline).fontWeight(.semibold)
                        .foregroundColor(selected == filter ? .white : .secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(
                            selected == filter
                            ? AnyView(
                                LinearGradient(colors: [.purple, .blue],
                                               startPoint: .leading, endPoint: .trailing)
                                    .clipShape(Capsule())
                            )
                            : AnyView(Color.clear)
                        )
                }
            }
        }
        .padding(4)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .clipShape(Capsule())
        .shadow(color: .black.opacity(0.06), radius: 4, x: 0, y: 2)
        .padding(.horizontal)
    }
}

// MARK: - Event data model
// Removed legacy EventItem

// MARK: - Event list
private struct EventListSection: View {
    let role:      ClubRole
    let filter:    EventFilter
    let canCreate: Bool

    @StateObject private var vm = EventsViewModel()

    private func parseDate(_ str: String) -> Date? {
        // Try ISO8601 with timezone first
        let f1 = ISO8601DateFormatter()
        f1.formatOptions = [.withInternetDateTime]
        if let d = f1.date(from: str) { return d }
        
        // Try with fractional seconds
        f1.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let d = f1.date(from: str) { return d }
        
        // Try without timezone (backend may not include Z)
        let f2 = DateFormatter()
        f2.locale = Locale(identifier: "en_US_POSIX")
        f2.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        return f2.date(from: str)
    }

    private var filtered: [EventResponse] {
        let now = Date()
        return vm.events.filter { event in
            let eventDate = parseDate(event.date) ?? Date.distantPast
            switch filter {
            case .upcoming: return eventDate >= now
            case .past:     return eventDate < now
            }
        }
    }

    var body: some View {
        VStack(spacing: 14) {
            if vm.isLoading {
                ProgressView("Loading events...").padding()
            } else if let err = vm.errorMessage {
                Text("⚠️ \(err)").font(.caption).foregroundColor(.red).padding()
            } else if filtered.isEmpty {
                emptyState
            } else {
                ForEach(filtered) { event in
                    NavigationLink(destination: EventDetailScreen(
                        eventId: event.id,
                        clubId: event.club_id,
                        title: event.title,
                        club: "Club \(event.club_id)",
                        day: parseEventDay(event.date),
                        month: parseEventMonth(event.date),
                        time: parseEventTime(event.date),
                        location: "TBD",
                        registered: 0
                    )) {
                        APIEventCard(role: role, event: event, canCreate: canCreate)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
        }
        .padding(.horizontal)
        .onAppear { vm.load() }
    }

    private func parseEventDay(_ str: String) -> String {
        guard let d = parseDate(str) else { return "—" }
        return "\(Calendar.current.component(.day, from: d))"
    }
    private func parseEventMonth(_ str: String) -> String {
        guard let d = parseDate(str) else { return "—" }
        let f = DateFormatter(); f.dateFormat = "MMM"
        return f.string(from: d).uppercased()
    }
    private func parseEventTime(_ str: String) -> String {
        guard let d = parseDate(str) else { return "—" }
        let f = DateFormatter(); f.timeStyle = .short
        return f.string(from: d)
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "calendar.badge.exclamationmark")
                .font(.system(size: 48)).foregroundColor(.purple.opacity(0.4))
            Text("No \(filter.rawValue) Events")
                .font(.headline).foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity).padding(40)
    }
}

// MARK: - API Event card
private struct APIEventCard: View {
    let role:      ClubRole
    let event:     EventResponse
    let canCreate: Bool

    @EnvironmentObject private var store: AttendanceNotificationStore

    private func parseEventDate(_ str: String) -> Date? {
        let f1 = ISO8601DateFormatter()
        f1.formatOptions = [.withInternetDateTime]
        if let d = f1.date(from: str) { return d }
        f1.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let d = f1.date(from: str) { return d }
        let f2 = DateFormatter()
        f2.locale = Locale(identifier: "en_US_POSIX")
        f2.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        return f2.date(from: str)
    }

    private var dayMonth: (String, String) {
        if let unwrappedDate = parseEventDate(event.date) {
            let cal = Calendar.current
            let day = "\(cal.component(.day, from: unwrappedDate))"
            let monthFmt = DateFormatter(); monthFmt.dateFormat = "MMM"
            return (day, monthFmt.string(from: unwrappedDate).uppercased())
        }
        return ("—", "—")
    }

    var body: some View {
        let (day, month) = dayMonth
        HStack(spacing: 16) {
            VStack(spacing: 2) {
                Text(month).font(.caption2).fontWeight(.bold).foregroundColor(.purple)
                Text(day).font(.title3).fontWeight(.bold).foregroundColor(.primary)
            }
            .frame(width: 52, height: 52)
            .background(Color.purple.opacity(0.09))
            .cornerRadius(12)

            VStack(alignment: .leading, spacing: 5) {
                Text(event.title)
                    .font(.subheadline).fontWeight(.semibold).lineLimit(1)
                Text(event.description ?? "")
                    .font(.caption).foregroundColor(.secondary).lineLimit(2)
            }
            Spacer()
            if canCreate {
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(Color(UIColor.tertiaryLabel))
            }
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}


// MARK: - Event card
// Removed legacy EventCard

#Preview("President (+ button)") {
    NavigationStack { EventsScreen(role: .president) }
        .environmentObject(AttendanceNotificationStore())
}

#Preview("Student (view-only)") {
    NavigationStack { EventsScreen(role: .student) }
        .environmentObject(AttendanceNotificationStore())
}
