//
//  AnalyticsViewModel.swift
//  CLUB ANALYTICSs
//

import Foundation
import Combine

// MARK: - Admin Platform Analytics ViewModel
@MainActor
final class AdminAnalyticsViewModel: ObservableObject {
    // Platform Overview stats
    @Published var totalClubs: Int = 0
    @Published var totalMembers: Int = 0
    @Published var totalEvents: Int = 0
    @Published var avgEngagement: Double = 0.0
    @Published var lastUpdated: Date = Date()
    
    // New Platform Health & Trends
    @Published var healthScore: Double = 0.0
    @Published var improvement: String = ""
    @Published var trendLabels: [String] = []
    @Published var trendData: [Int] = []
    @Published var alerts: [AIAlert] = []

    // Rankings
    @Published var rankings: [ClubRankingItem] = []
    @Published var lowEngagementClubs: [ClubRankingItem] = []

    // State
    @Published var isLoading = false
    @Published var errorMessage: String?

    func fetchPlatformAnalytics() async {
        print("🔍 [AdminAnalyticsViewModel] fetchPlatformAnalytics() started")
        self.objectWillChange.send()
        isLoading = true
        errorMessage = nil
        
        // Use a task group or concurrent tasks for faster loading if desired, 
        // but sequential is safer for debugging now.
        do {
            let summary = try await AnalyticsService.shared.fetchPlatformSummary()
            print("📊 [AdminAnalyticsViewModel] Received Summary: Clubs=\(summary.total_clubs)")
            
            self.totalClubs   = summary.total_clubs
            print("✅ [AdminAnalyticsViewModel] Set totalClubs = \(self.totalClubs)")
            
            self.totalMembers = summary.total_members
            self.totalEvents  = summary.active_events
            self.avgEngagement = summary.engagement_rate

            // Fetch New Metrics
            if let health = try? await AnalyticsService.shared.fetchPlatformHealth() {
                self.healthScore = health.health_score
                self.improvement = health.improvement
                print("✅ [AdminAnalyticsViewModel] Set healthScore = \(self.healthScore)")
            }
            
            if let trend = try? await AnalyticsService.shared.fetchEngagementTrend() {
                self.trendLabels = trend.labels
                self.trendData = trend.data
                print("✅ [AdminAnalyticsViewModel] Set trendData count = \(self.trendData.count)")
            }
            
            if let alertsData = try? await AnalyticsService.shared.fetchAIAlerts() {
                self.alerts = alertsData.alerts
                print("✅ [AdminAnalyticsViewModel] Set alerts count = \(self.alerts.count)")
            }

            print("🔍 [AdminAnalyticsViewModel] Fetching rankings...")
            self.rankings = try await AnalyticsService.shared.fetchClubRankings()
            print("📈 [AdminAnalyticsViewModel] Received \(self.rankings.count) rankings")
            
            self.lowEngagementClubs = self.rankings.filter { $0.engagementScore < 65 }
            
            self.lastUpdated = Date()
            self.objectWillChange.send()
            print("🏁 [AdminAnalyticsViewModel] fetchPlatformAnalytics() finished. rankingsCount=\(self.rankings.count), totalClubs=\(self.totalClubs)")
        } catch {
            print("❌ [AdminAnalyticsViewModel] Fetch error: \(error.localizedDescription)")
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }
}

// MARK: - Club-level / Authority Analytics ViewModel
@MainActor
final class AnalyticsViewModel: ObservableObject {
    @Published var health: ClubHealthResponse?
    @Published var isLoading = false
    @Published var errorMessage: String?

    func load(clubId: Int) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                health = try await AnalyticsService.shared.getClubHealth(clubId: clubId)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
