//
//  AnalyticsViewModel.swift
//  CLUB ANALYTICSs
//

import Foundation
import Combine

// MARK: - Admin Platform Analytics ViewModel
@MainActor
final class AdminAnalyticsViewModel: ObservableObject {
    // Platform Overview stats
    @Published var totalClubs: Int = 0
    @Published var totalMembers: Int = 0
    @Published var totalEvents: Int = 0
    @Published var avgEngagement: Double = 0.0

    // Rankings
    @Published var rankings: [ClubRankingItem] = []
    @Published var lowEngagementClubs: [ClubRankingItem] = []

    // State
    @Published var isLoading = false
    @Published var errorMessage: String?

    func fetchPlatformAnalytics() async {
        isLoading = true
        errorMessage = nil
        do {
            let summary = try await AnalyticsService.shared.fetchPlatformSummary()
            self.totalClubs   = summary.total_clubs
            self.totalMembers = summary.total_members
            self.totalEvents  = summary.active_events
            self.avgEngagement = summary.engagement_rate

            self.rankings = try await AnalyticsService.shared.fetchClubRankings()
            self.lowEngagementClubs = self.rankings.filter { $0.engagementScore < 65 }
        } catch {
            errorMessage = error.localizedDescription
            print("Admin Analytics Error:", error)
        }
        isLoading = false
    }
}

// MARK: - Club-level / Authority Analytics ViewModel
@MainActor
final class AnalyticsViewModel: ObservableObject {
    @Published var health: ClubHealthResponse?
    @Published var isLoading = false
    @Published var errorMessage: String?

    func load(clubId: Int) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                health = try await AnalyticsService.shared.getClubHealth(clubId: clubId)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
