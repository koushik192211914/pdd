import SwiftUI
import PhotosUI

struct UploadReportView: View {
    let existingReport: ReportResponse?
    
    init(existingReport: ReportResponse? = nil) {
        self.existingReport = existingReport
    }

    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var authManager: AuthManager

    @State private var reportTitle: String = ""
    @State private var selectedEventId: Int? = nil
    @State private var reportType: ReportType = .eventReport
    @State private var description: String = ""
    
    @State private var events: [EventResponse] = []
    @State private var isLoadingEvents: Bool = true
    @State private var selectedImage: PhotosPickerItem? = nil
    @State private var selectedUIImage: UIImage? = nil
    
    @State private var isSubmitting: Bool = false
    @State private var errorMsg: String? = nil
    @State private var showSuccessMessage = false
    
    private var isEditing: Bool { existingReport != nil }

    enum ReportType: String, CaseIterable, Identifiable {
        case eventReport = "Event Report"
        case meetingMinutes = "Meeting Minutes"
        case activityReport = "Activity Report"
        var id: String { self.rawValue }
    }

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // ── Header ───────────────────────────────────────────────
                headerView

                VStack(spacing: 24) {
                    // ── Form Area ───────────────────────────────────────────
                    VStack(alignment: .leading, spacing: 20) {
                        // Title
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Report Title", systemImage: "pencil.line")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            TextField("Enter report title", text: $reportTitle)
                                .padding()
                                .background(Color(UIColor.secondarySystemGroupedBackground))
                                .cornerRadius(12)
                                .shadow(color: .black.opacity(0.03), radius: 5, x: 0, y: 2)
                        }

                        // Event Picker
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Select Event", systemImage: "calendar")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            
                            if isLoadingEvents {
                                HStack {
                                    ProgressView().scaleEffect(0.8)
                                    Text("Loading events...").font(.subheadline).foregroundColor(.secondary)
                                }
                                .padding()
                                .background(Color(UIColor.secondarySystemGroupedBackground))
                                .cornerRadius(12)
                            } else if events.isEmpty {
                                Text("No events found for your club.")
                                    .font(.subheadline).foregroundColor(.secondary)
                                    .padding()
                                    .background(Color(UIColor.secondarySystemGroupedBackground))
                                    .cornerRadius(12)
                            } else {
                                Menu {
                                    ForEach(events) { event in
                                        Button(event.title) { selectedEventId = event.id }
                                    }
                                } label: {
                                    HStack {
                                        Text(events.first { $0.id == selectedEventId }?.title ?? "Select an event")
                                            .foregroundColor(selectedEventId == nil ? .secondary : .primary)
                                        Spacer()
                                        Image(systemName: "chevron.down").font(.caption).foregroundColor(.secondary)
                                    }
                                    .padding()
                                    .background(Color(UIColor.secondarySystemGroupedBackground))
                                    .cornerRadius(12)
                                    .shadow(color: .black.opacity(0.03), radius: 5, x: 0, y: 2)
                                }
                            }
                        }

                        // Report Type
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Report Type", systemImage: "doc.text.fill")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            Picker("Report Type", selection: $reportType) {
                                ForEach(ReportType.allCases) { type in
                                    Text(type.rawValue).tag(type)
                                }
                            }
                            .pickerStyle(.segmented)
                        }

                        // File Upload Placeholder
                        VStack(alignment: .leading, spacing: 8) {
                            Label("File Upload (Image only)", systemImage: "photo")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            
                            PhotosPicker(selection: $selectedImage, matching: .images, photoLibrary: .shared()) {
                                HStack {
                                    if let uiImage = selectedUIImage {
                                        Image(uiImage: uiImage)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 40, height: 40)
                                            .clipShape(RoundedRectangle(cornerRadius: 6))
                                        Text("Image selected").fontWeight(.medium)
                                    } else {
                                        Image(systemName: "arrow.up.doc.fill")
                                        Text("Choose Image").fontWeight(.medium)
                                    }
                                    Spacer()
                                }
                                .padding()
                                .foregroundColor(.blue)
                                .background(Color.blue.opacity(0.08))
                                .cornerRadius(12)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.blue.opacity(0.3), lineWidth: 1)
                                )
                            }
                            .onChange(of: selectedImage) { _, newItem in
                                Task {
                                    if let data = try? await newItem?.loadTransferable(type: Data.self), let image = UIImage(data: data) {
                                        selectedUIImage = image
                                    }
                                }
                            }
                        }

                        // Description
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Description (Optional)", systemImage: "text.alignleft")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            TextEditor(text: $description)
                                .frame(minHeight: 120)
                                .padding(8)
                                .background(Color(UIColor.secondarySystemGroupedBackground))
                                .cornerRadius(12)
                                .shadow(color: .black.opacity(0.03), radius: 5, x: 0, y: 2)
                        }
                    }
                    .padding(.horizontal)

                    // ── Submit Button ───────────────────────────────────────
                    if let err = errorMsg {
                        Text(err).font(.caption).foregroundColor(.red).padding(.horizontal)
                    }

                    Button(action: {
                        Task { await submitReport() }
                    }) {
                        HStack(spacing: 8) {
                            if isSubmitting {
                                ProgressView().tint(.white)
                                Text(isEditing ? "Updating..." : "Submitting...")
                            } else {
                                Text(isEditing ? "Update Report" : "Submit Report")
                            }
                        }
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            LinearGradient(colors: [.purple, .blue], startPoint: .leading, endPoint: .trailing)
                        )
                        .cornerRadius(16)
                        .shadow(color: .purple.opacity(0.3), radius: 8, x: 0, y: 4)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 40)
                    .disabled(reportTitle.isEmpty || selectedEventId == nil || isSubmitting)
                    .opacity(reportTitle.isEmpty || selectedEventId == nil || isSubmitting ? 0.6 : 1.0)
                }
                .padding(.top, 24)
            }
        }
        .onAppear {
            if let report = existingReport {
                self.reportTitle = report.title
                self.selectedEventId = report.event_id
                self.reportType = ReportType(rawValue: report.report_type) ?? .eventReport
                self.description = report.description ?? ""
            }
            Task { await fetchEvents() }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .overlay(
            Group {
                if showSuccessMessage {
                    ZStack {
                        Color.black.opacity(0.3).ignoresSafeArea()
                        VStack(spacing: 16) {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.green)
                            Text(isEditing ? "Report Updated!" : "Report Submitted!")
                                .font(.title3).bold()
                            Text("Returning to dashboard...")
                                .font(.subheadline).foregroundColor(.secondary)
                        }
                        .padding(30)
                        .background(Color(UIColor.systemBackground))
                        .cornerRadius(24)
                        .shadow(radius: 20)
                    }
                    .transition(.opacity)
                }
            }
        )
    }

    private var headerView: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 8)
                HStack(alignment: .center, spacing: 12) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(isEditing ? "Edit Report" : "Upload Report").font(.title3).bold().foregroundColor(.white)
                        Text(isEditing ? "Correct or update your report record" : "Submit new event or meeting documentation")
                            .font(.caption).foregroundColor(.white.opacity(0.80)).lineLimit(1)
                    }
                    Spacer()
                }
                .padding(.horizontal, 18).padding(.bottom, 22)
            }
        }
        .frame(height: safeTop + 92) // Changed from minHeight to height
    }

    private func fetchEvents() async {
        guard let cid = authManager.clubId else {
            DispatchQueue.main.async { isLoadingEvents = false }
            return
        }
        do {
            let fetchedEvents = try await EventService.shared.getEvents(clubId: cid)
            DispatchQueue.main.async {
                self.events = fetchedEvents
                self.isLoadingEvents = false
            }
        } catch {
            DispatchQueue.main.async {
                self.errorMsg = "Failed to load events: \(error.localizedDescription)"
                self.isLoadingEvents = false
            }
        }
    }

    private func submitReport() async {
        guard let eventId = selectedEventId, let clubId = authManager.clubId, let userId = authManager.userId else {
            errorMsg = "Missing required information"
            return
        }
        
        isSubmitting = true
        errorMsg = nil
        
        do {
            if let report = existingReport {
                // Update
                _ = try await ReportService.shared.updateReport(
                    id: report.id,
                    title: reportTitle.trimmingCharacters(in: .whitespaces),
                    reportType: reportType.rawValue,
                    description: description.trimmingCharacters(in: .whitespaces),
                    image: selectedUIImage
                )
            } else {
                // Create
                _ = try await ReportService.shared.uploadReport(
                    title: reportTitle.trimmingCharacters(in: .whitespaces),
                    eventId: eventId,
                    clubId: clubId,
                    reportType: reportType.rawValue,
                    description: description.trimmingCharacters(in: .whitespaces),
                    submittedBy: userId,
                    image: selectedUIImage
                )
            }
            
            withAnimation {
                showSuccessMessage = true
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                dismiss()
            }
        } catch {
            let action = isEditing ? "update" : "submit"
            errorMsg = "Failed to \(action) report: \(error.localizedDescription)"
            isSubmitting = false
        }
    }
}

#Preview {
    PreviewWrapper {
    UploadReportView()

    }
}
