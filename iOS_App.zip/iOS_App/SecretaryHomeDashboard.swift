//
//  SecretaryHomeDashboard.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Secretary Dashboard home tab
//

import SwiftUI

// MARK: - Secretary Home Dashboard
struct SecretaryHomeDashboard: View {
    @ObservedObject var viewModel: SecretaryHomeViewModel
    @EnvironmentObject private var authManager: AuthManager
    
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // ── HEADER + STAT CARDS ──────────────────────────────────────
                RoleDashboardHeader(
                    role: .secretary,
                    roleTitle: "Secretary Dashboard",
                    subtitle: viewModel.club?.name ?? "Loading...",
                    stats: [
                        DashboardStat(title: "Total Members",   value: "\(viewModel.summary["total_members"] ?? 0)", icon: "person.3.fill"),
                        DashboardStat(title: "Active Events",   value: "\(viewModel.summary["total_events"] ?? 0)",   icon: "calendar"),
                        DashboardStat(title: "Reports Uploaded",value: "\(viewModel.reports.count)",   icon: "doc.text.fill",   isWarning: false),
                        DashboardStat(title: "Announcements",   value: "\(viewModel.announcements.count)",  icon: "megaphone.fill")
                    ]
                )

                VStack(spacing: 32) {
                    // ── QUICK ACTIONS ────────────────────────────────────────
                    SecretaryQuickActionsSection()

                    // ── DOCUMENTATION ────────────────────────────────────────
                    SecretaryDocumentationSection(viewModel: viewModel)
                    
                    // ── ANNOUNCEMENTS ────────────────────────────────────────
                    RecentAnnouncementsSection(announcements: viewModel.announcements)
                }
                .padding(.top, 24)
                .padding(.bottom, 100)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .task {
            if let clubId = authManager.clubId {
                await viewModel.fetchData(clubId: clubId)
            }
        }
    }
}


// MARK: - Quick Actions
struct SecretaryQuickActionsSection: View {

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionHeaderRow(title: "Secretary Quick Actions")
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 16) {
                // Upload Report
                NavigationLink(destination: UploadReportView()) {
                    QuickActionItemContent(title: "Upload Report", icon: "arrow.up.doc.fill", color: .blue)
                }
            }
            .padding(.horizontal)
        }
    }
}

/// Helper for NavigationLink content to match RoleQuickActionButton style
private struct QuickActionItemContent: View {
    let title: String
    let icon:  String
    let color: Color

    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle().fill(color.opacity(0.15)).frame(width: 50, height: 50)
                Image(systemName: icon).font(.system(size: 24)).foregroundColor(color)
            }
            Text(title)
                .font(.subheadline).fontWeight(.semibold)
                .foregroundColor(.primary)
                .multilineTextAlignment(.center)
                .lineLimit(2)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

private struct SecretaryDocumentationSection: View {
    @ObservedObject var viewModel: SecretaryHomeViewModel
    @EnvironmentObject private var authManager: AuthManager
    @State private var navigateToReports = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionHeaderRow(title: "Documentation", showViewAll: true) {
                navigateToReports = true
            }
            .navigationDestination(isPresented: $navigateToReports) {
                if let clubId = authManager.clubId {
                    ClubReportsView(clubId: clubId, clubName: viewModel.club?.name ?? "Club Reports", eventName: nil, role: .secretary)
                }
            }
            
            if viewModel.reports.isEmpty {
                Text("No Reports Uploaded")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(16)
                    .padding(.horizontal)
            } else {
                VStack(spacing: 12) {
                    ForEach(viewModel.reports) { report in
                        Button(action: { navigateToReports = true }) {
                            SecDocCard(
                                title: report.title,
                                date: report.submitted_at.prefix(10).description,
                                icon: "doc.text.fill",
                                iconColor: .blue
                            )
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

private struct SecDocCard: View {
    let title: String
    let date:  String
    let icon:  String
    let iconColor: Color

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(iconColor.opacity(0.12)).frame(width: 44, height: 44)
                Image(systemName: icon).font(.system(size: 20)).foregroundColor(iconColor)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.subheadline).fontWeight(.semibold).foregroundColor(.primary).lineLimit(1)
                Text(date).font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(.purple.opacity(0.7))
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Team Management Section
private struct SecretaryTeamManagementSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            SectionHeaderRow(title: "Team Management", showViewAll: true)
            VStack(spacing: 12) {
                SecMemberCard(name: "Priya Kumar",   role: "Event Coordinator", attendance: "92%", initials: "PK", attendanceColor: .green)
                SecMemberCard(name: "Rahul Sharma",  role: "Media Head",        attendance: "78%", initials: "RS", attendanceColor: .orange)
                SecMemberCard(name: "Ananya Singh",  role: "Documentation",     attendance: "45%", initials: "AS", attendanceColor: .red)
            }
            .padding(.horizontal)
        }
    }
}

private struct SecMemberCard: View {
    let name: String; let role: String; let attendance: String
    let initials: String; let attendanceColor: Color

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 46, height: 46)
                Text(initials).font(.system(size: 16, weight: .bold)).foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(name).font(.subheadline).fontWeight(.semibold)
                Text(role).font(.caption).foregroundColor(.secondary)
                HStack(spacing: 4) {
                    Image(systemName: "clock.fill").font(.caption2).foregroundColor(attendanceColor)
                    Text("\(attendance) attendance").font(.caption2).foregroundColor(attendanceColor)
                }
            }
            Spacer()
            Button("Edit") {}
                .font(.caption).fontWeight(.bold)
                .foregroundColor(.blue)
                .padding(.horizontal, 12).padding(.vertical, 6)
                .background(Color.blue.opacity(0.10))
                .clipShape(Capsule())
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Recent Announcements Section handled by Shared Components

// MARK: - Preview
#Preview {
    PreviewWrapper {
        NavigationStack {
            SecretaryHomeDashboard(viewModel: SecretaryHomeViewModel())
        }
        .environmentObject(AttendanceNotificationStore())
    }
}
