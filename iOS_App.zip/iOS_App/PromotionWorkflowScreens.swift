import SwiftUI

// MARK: ─────────────────────────────────────────────────────────────
// PROMOTION WORKFLOW SCREENS
// Updated flow:
// ManageUsers → SelectClubScreen → PromoteUserScreen → ConfirmRoleScreen
//             → SuccessScreen → Return to ManageUsers
// ─────────────────────────────────────────────────────────────────

// MARK: - Club Data Model
struct ClubData: Identifiable, Hashable {
    let id           = UUID()
    var dbId:        Int = 0
    let name:        String
    let category:    String
    let memberCount: Int
    let icon:        String     // SF Symbol
    let color:       Color

    // Simulated existing role occupancy: role → true means slot is taken
    var occupiedRoles: Set<String>

    static func == (lhs: ClubData, rhs: ClubData) -> Bool { lhs.id == rhs.id }
    func hash(into hasher: inout Hasher) { hasher.combine(id) }
}

// MARK: - Sample clubs
extension ClubData {
    static var sampleClubs: [ClubData] = [
        ClubData(name: "Tech Innovation Club",  category: "Technology",   memberCount: 245,
                 icon: "desktopcomputer",        color: .purple, occupiedRoles: ["President"]),
        ClubData(name: "Robotics Society",       category: "Engineering",  memberCount: 189,
                 icon: "gearshape.2.fill",        color: .blue,   occupiedRoles: []),
        ClubData(name: "Business Leaders",       category: "Business",     memberCount: 312,
                 icon: "briefcase.fill",          color: .orange, occupiedRoles: ["Secretary"]),
        ClubData(name: "Design Collective",      category: "Arts & Design",memberCount: 156,
                 icon: "paintpalette.fill",        color: .pink,   occupiedRoles: []),
        ClubData(name: "Environmental Club",     category: "Science",      memberCount: 201,
                 icon: "leaf.fill",               color: .green,  occupiedRoles: ["President"]),
        ClubData(name: "Music & Arts Club",      category: "Arts",         memberCount: 134,
                 icon: "music.note.list",          color: .teal,   occupiedRoles: []),
    ]
}

// MARK: - Shared LeadershipRole enum
enum LeadershipRole: String, CaseIterable, Identifiable {
    case president     = "President"
    case vicePresident = "VicePresident"
    case secretary     = "Secretary"

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .president:     return "President"
        case .vicePresident: return "Vice President"
        case .secretary:     return "Secretary"
        }
    }

    var icon: String {
        switch self {
        case .president:     return "star.fill"
        case .vicePresident: return "star.leadinghalf.filled"
        case .secretary:     return "doc.fill"
        }
    }

    var color: Color {
        switch self {
        case .president:     return .purple
        case .vicePresident: return .blue
        case .secretary:     return .teal
        }
    }

    var description: String {
        switch self {
        case .president:     return "Leads the club and manages all events."
        case .vicePresident: return "Supports the president and coordinates club operations."
        case .secretary:     return "Manages documentation and meeting records."
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - SCREEN 1 · User Profile Detail Screen
// ─────────────────────────────────────────────────────────────────
struct UserProfileScreen: View {
    @State private var user: ClubUser
    let onProfileUpdated: (String, String) -> Void
    let dismissToRoot: () -> Void
    
    init(user: ClubUser, onProfileUpdated: @escaping (String, String) -> Void, dismissToRoot: @escaping () -> Void) {
        _user = State(initialValue: user)
        self.onProfileUpdated = onProfileUpdated
        self.dismissToRoot = dismissToRoot
    }
    
    @State private var isDemoting = false
    @State private var demoteErrorMessage: String?
    
    @State private var isRemoving = false
    @State private var removeErrorMessage: String?

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                UserProfileHeader(user: user)

                VStack(spacing: 24) {
                    performanceSection
                    detailSection

                    if user.role != "Student" {
                        if let err = demoteErrorMessage {
                            Text("⚠️ \(err)").font(.caption).foregroundColor(.red)
                        }
                        Button(action: { Task { await demoteUser() } }) {
                            HStack(spacing: 10) {
                                if isDemoting {
                                    ProgressView().tint(.white)
                                } else {
                                    Image(systemName: "arrow.down.circle.fill").font(.system(size: 20, weight: .semibold))
                                    Text("Demote to Student").font(.headline)
                                }
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(
                                LinearGradient(colors: [.orange, .red], startPoint: .leading, endPoint: .trailing)
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                            .shadow(color: Color.red.opacity(0.30), radius: 8, x: 0, y: 4)
                        }
                        .padding(.horizontal, 20)
                        .disabled(isDemoting)

                        // --- Change Leadership button ---
                        NavigationLink {
                            SelectNewLeaderScreen(currentLeader: user, onRoleUpdated: { role, club in
                                // Update local state
                                updateLocalState(newRole: role, newClub: club)
                                onProfileUpdated(role, club)
                            }, dismissToRoot: dismissToRoot)
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "person.2.fill").font(.system(size: 20, weight: .semibold))
                                Text("Change Leadership").font(.headline)
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(Color.blue)
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                            .shadow(color: Color.blue.opacity(0.30), radius: 8, x: 0, y: 4)
                        }
                        .padding(.horizontal, 20)
                    }

                    // --- Remove from Club button ---
                    if let err = removeErrorMessage {
                        Text("⚠️ \(err)").font(.caption).foregroundColor(.red)
                    }
                    Button(action: { Task { await removeUser() } }) {
                        HStack(spacing: 10) {
                            if isRemoving {
                                ProgressView().tint(.white)
                            } else {
                                Image(systemName: "person.fill.xmark").font(.system(size: 20, weight: .semibold))
                                Text("Remove from Club").font(.headline)
                            }
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color.red)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .shadow(color: Color.red.opacity(0.30), radius: 8, x: 0, y: 4)
                    }
                    .padding(.horizontal, 20)
                    .disabled(isRemoving)

                    // Promote to Leadership → SelectClubScreen
                    NavigationLink(
                        destination: SelectClubScreen(
                            user:          user,
                            onRoleUpdated: { (newRole, newClub) in
                                // Update local state for immediate feedback
                                updateLocalState(newRole: newRole, newClub: newClub)
                                onProfileUpdated(newRole, newClub)
                            },
                            dismissToRoot: dismissToRoot
                        )
                    ) {
                        HStack(spacing: 10) {
                            Image(systemName: "arrow.up.circle.fill")
                                .font(.system(size: 20, weight: .semibold))
                            Text("Promote to Leadership")
                                .font(.headline)
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            LinearGradient(colors: [Color.purple, Color.blue],
                                           startPoint: .leading, endPoint: .trailing)
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .shadow(color: Color.purple.opacity(0.30), radius: 8, x: 0, y: 4)
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 40)
                }
                .padding(.top, 24)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
    }

    private func demoteUser() async {
        isDemoting = true
        demoteErrorMessage = nil
        do {
            _ = try await AdminService.shared.demoteUser(userId: user.dbId)
            updateLocalState(newRole: "Student", newClub: user.club)
            onProfileUpdated("Student", user.club)
            dismissToRoot()
        } catch {
            demoteErrorMessage = "Failed: \(error.localizedDescription)"
        }
        isDemoting = false
    }

    private func updateLocalState(newRole: String, newClub: String) {
        let updatedUser = ClubUser(
            id: user.id,
            dbId: user.dbId,
            name: user.name,
            role: newRole,
            club: newClub,
            eventsAttended: user.eventsAttended,
            attendance: user.attendance,
            engagement: user.engagement,
            profile_picture_url: user.profile_picture_url
        )
        self.user = updatedUser
    }

    private func removeUser() async {
        isRemoving = true
        removeErrorMessage = nil
        do {
            _ = try await AdminService.shared.removeUser(userId: user.dbId)
            dismissToRoot()
        } catch {
            let fullError = "\(error.localizedDescription)"
            if fullError.contains("This student is not registered in any club.") || fullError.contains("Member not found") {
                removeErrorMessage = "This student is not registered in any club."
            } else {
                removeErrorMessage = fullError
            }
        }
        isRemoving = false
    }

    private var performanceSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Student Performance")
                .font(.title3).bold().padding(.horizontal, 20)
            LazyVGrid(columns: [
                GridItem(.flexible(), spacing: 14),
                GridItem(.flexible(), spacing: 14),
                GridItem(.flexible(), spacing: 14)
            ], spacing: 14) {
                ProfileStatCard(icon: "calendar.badge.checkmark", color: .green,  label: "Events",     value: "\(user.eventsAttended)")
                ProfileStatCard(icon: "clock.fill",               color: .blue,   label: "Attendance", value: "\(user.attendance)%")
                ProfileStatCard(icon: "flame.fill",               color: .orange, label: "Engagement", value: "\(user.engagement)%")
            }
            .padding(.horizontal, 20)
        }
    }

    private var detailSection: some View {
        VStack(spacing: 0) {
            ProfileInfoRow(icon: "person.fill",     color: .purple, title: "Current Role",     value: user.role)
            Divider().padding(.leading, 52)
            ProfileInfoRow(icon: "building.2.fill", color: .blue,   title: "Club",             value: user.club)
            
            // Hide Email for Leadership Roles (President, Vice President, Secretary)
            if !["President", "Vice President", "VicePresident", "Secretary"].contains(user.role) {
                Divider().padding(.leading, 52)
                ProfileInfoRow(icon: "envelope.fill",   color: .indigo, title: "Email",
                               value: "\(user.name.lowercased().replacingOccurrences(of: " ", with: "."))@clubsphere.edu")
            }
            
            Divider().padding(.leading, 52)
            ProfileInfoRow(icon: "calendar",        color: .green,  title: "Events Attended",  value: "\(user.eventsAttended)")
            Divider().padding(.leading, 52)
            ProfileInfoRow(icon: "clock.fill",      color: .orange, title: "Attendance Rate",  value: "\(user.attendance)%")
            Divider().padding(.leading, 52)
            ProfileInfoRow(icon: "flame.fill",      color: .red,    title: "Engagement Score", value: "\(user.engagement)%")
        }
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
        .padding(.horizontal, 20)
    }
}

// MARK: - Profile gradient header
struct UserProfileHeader: View {
    let user: ClubUser
    @Environment(\.dismiss) private var dismiss

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [Color.purple, Color.blue],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)

            VStack(spacing: 0) {
                Color.clear.frame(height: safeTop + 8)
                HStack {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    Spacer()
                }
                .padding(.horizontal, 18)

                ZStack {
                    Circle().fill(LinearGradient(
                        colors: [Color.white.opacity(0.35), Color.white.opacity(0.15)],
                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 80, height: 80)
                    .shadow(color: .black.opacity(0.15), radius: 8, x: 0, y: 4)
                    Text(user.initials).font(.system(size: 28, weight: .bold)).foregroundColor(.white)
                }
                .padding(.top, 12)

                VStack(spacing: 6) {
                    Text(user.name).font(.title3).bold().foregroundColor(.white)
                    Text(user.role).font(.caption).fontWeight(.semibold).foregroundColor(.white)
                        .padding(.horizontal, 14).padding(.vertical, 5)
                        .background(Capsule().fill(Color.white.opacity(0.25)))
                    HStack(spacing: 4) {
                        Image(systemName: "building.2.fill").font(.caption).foregroundColor(.white.opacity(0.8))
                        Text(user.club).font(.caption).foregroundColor(.white.opacity(0.8))
                    }
                }
                .padding(.top, 10).padding(.bottom, 24)
            }
        }
        .frame(minHeight: safeTop + 220)
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - SCREEN 2 · Select Club Screen  ← NEW
// ─────────────────────────────────────────────────────────────────
struct SelectClubScreen: View {
    let user:          ClubUser
    let onRoleUpdated: (String, String) -> Void
    let dismissToRoot: () -> Void

    @State private var clubs: [ClubData] = []
    @State private var isLoading = false
    @State private var errorMessage: String?

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                WorkflowSubHeader(title: "Select Club",
                                  subtitle: "Choose the club for \(user.name)'s leadership role")

                VStack(spacing: 14) {
                    // User mini-summary
                    userMiniCard.padding(.horizontal, 20)

                    // Club cards list
                    if isLoading {
                        ProgressView("Loading clubs...")
                            .padding(.top, 40)
                    } else if let error = errorMessage {
                        Text("⚠️ \(error)").foregroundColor(.red).padding()
                    } else if clubs.isEmpty {
                        Text("No clubs available.").foregroundColor(.secondary).padding()
                    } else {
                        VStack(spacing: 12) {
                            ForEach($clubs) { $club in
                                NavigationLink(
                                    destination: PromoteUserScreen(
                                        user:          user,
                                        selectedClub:  club,
                                        allClubs:      $clubs,
                                        onRoleUpdated: onRoleUpdated,
                                        dismissToRoot: dismissToRoot
                                    )
                                ) {
                                    ClubSelectionCard(club: club)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.bottom, 40)
                    }
                }
                .padding(.top, 20)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .task { await loadClubs() }
    }

    private func loadClubs() async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        
        do {
            let fetched = try await ClubService.shared.getClubs()
            let colors: [Color] = [.purple, .blue, .orange, .pink, .green, .teal]
            let icons: [String] = ["desktopcomputer", "gearshape.2.fill", "briefcase.fill", "paintpalette.fill", "leaf.fill", "music.note.list"]
            
            // Mapping occupied_roles from backend
            clubs = fetched.enumerated().map { index, c in
                ClubData(
                    dbId: c.id,
                    name: c.name,
                    category: c.category ?? "General",
                    memberCount: 0, 
                    icon: icons[index % icons.count],
                    color: colors[index % colors.count],
                    occupiedRoles: Set(c.occupied_roles)
                )
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private var userMiniCard: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle().fill(LinearGradient(
                    colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.5)],
                    startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 44, height: 44)
                Text(user.initials).font(.system(size: 14, weight: .bold)).foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(user.name).font(.subheadline).fontWeight(.semibold)
                Text("Promoting from: \(user.role)").font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            Image(systemName: "arrow.up.circle.fill").foregroundColor(.purple).font(.title3)
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

// MARK: - Club Selection Card
struct ClubSelectionCard: View {
    let club: ClubData

    var body: some View {
        HStack(spacing: 16) {
            // Club icon badge
            ZStack {
                RoundedRectangle(cornerRadius: 14)
                    .fill(LinearGradient(
                        colors: [club.color, club.color.opacity(0.7)],
                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 52, height: 52)
                    .shadow(color: club.color.opacity(0.3), radius: 5, x: 0, y: 3)
                Image(systemName: club.icon)
                    .font(.system(size: 22, weight: .medium))
                    .foregroundColor(.white)
            }

            // Info
            VStack(alignment: .leading, spacing: 4) {
                Text(club.name)
                    .font(.headline).foregroundColor(.primary)
                HStack(spacing: 8) {
                    Label(club.category, systemImage: "tag.fill")
                        .font(.caption).foregroundColor(club.color)
                    Text("·").foregroundColor(.secondary)
                    Label("\(club.memberCount) members", systemImage: "person.3.fill")
                        .font(.caption).foregroundColor(.secondary)
                }
                // Occupied roles hint
                if !club.occupiedRoles.isEmpty {
                    HStack(spacing: 4) {
                        Image(systemName: "exclamationmark.circle.fill")
                            .font(.caption2).foregroundColor(.orange)
                        Text("Taken: \(club.occupiedRoles.sorted().joined(separator: ", "))")
                            .font(.caption2).foregroundColor(.orange)
                    }
                }
            }

            Spacer(minLength: 0)

            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(Color(UIColor.tertiaryLabel))
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 3)
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - SCREEN 3 · Assign Leadership Role Screen
// ─────────────────────────────────────────────────────────────────
struct PromoteUserScreen: View {
    let user:          ClubUser
    let selectedClub:  ClubData
    @Binding var allClubs: [ClubData]
    let onRoleUpdated: (String, String) -> Void
    let dismissToRoot: () -> Void

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                WorkflowSubHeader(
                    title:    "Assign Leadership Role",
                    subtitle: "Choose \(user.name)'s role in \(selectedClub.name)"
                )

                VStack(spacing: 20) {
                    // Club + user summary card
                    summaryCard.padding(.horizontal, 20)

                    // Role cards
                    VStack(spacing: 12) {
                        ForEach(LeadershipRole.allCases.filter { !selectedClub.occupiedRoles.contains($0.rawValue) }) { role in
                            RoleSelectionCard(
                                role:          role,
                                user:          user,
                                selectedClub:  selectedClub,
                                allClubs:      $allClubs,
                                onRoleUpdated: onRoleUpdated,
                                dismissToRoot: dismissToRoot
                            )
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 40)
                }
                .padding(.top, 20)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
    }

    private var summaryCard: some View {
        HStack(spacing: 14) {
            // Club icon
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(LinearGradient(
                        colors: [selectedClub.color, selectedClub.color.opacity(0.7)],
                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 44, height: 44)
                Image(systemName: selectedClub.icon)
                    .font(.system(size: 18, weight: .medium)).foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(selectedClub.name).font(.subheadline).fontWeight(.semibold)
                Text("\(selectedClub.memberCount) members · \(selectedClub.category)")
                    .font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            // User avatar
            ZStack {
                Circle().fill(LinearGradient(
                    colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.5)],
                    startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 36, height: 36)
                Text(user.initials).font(.system(size: 12, weight: .bold)).foregroundColor(.white)
            }
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

// MARK: - Role Selection Card → ConfirmRoleScreen
struct RoleSelectionCard: View {
    let role:          LeadershipRole
    let user:          ClubUser
    let selectedClub:  ClubData
    @Binding var allClubs: [ClubData]
    let onRoleUpdated: (String, String) -> Void
    let dismissToRoot: () -> Void

    /// True if this role slot is already occupied in the selected club
    private var isTaken: Bool {
        selectedClub.occupiedRoles.contains(role.rawValue)
    }

    var body: some View {
        NavigationLink(
            destination: ConfirmRoleScreen(
                user:          user,
                selectedRole:  role,
                selectedClub:  selectedClub,
                allClubs:      $allClubs,
                onRoleUpdated: onRoleUpdated,
                dismissToRoot: dismissToRoot
            )
        ) {
            HStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14)
                        .fill(isTaken
                              ? LinearGradient(colors: [Color.gray.opacity(0.4), Color.gray.opacity(0.3)],
                                               startPoint: .topLeading, endPoint: .bottomTrailing)
                              : LinearGradient(colors: [role.color, role.color.opacity(0.7)],
                                               startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 52, height: 52)
                        .shadow(color: (isTaken ? Color.gray : role.color).opacity(0.3), radius: 5, x: 0, y: 3)
                    Image(systemName: isTaken ? "lock.fill" : role.icon)
                        .font(.system(size: 22, weight: .medium)).foregroundColor(.white)
                }

                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 6) {
                        Text(role.displayName).font(.headline)
                            .foregroundColor(isTaken ? .secondary : .primary)
                        if isTaken {
                            Text("Taken")
                                .font(.caption2).fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.horizontal, 6).padding(.vertical, 3)
                                .background(Color.orange)
                                .clipShape(Capsule())
                        }
                    }
                    Text(role.description)
                        .font(.caption).foregroundColor(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(Color(UIColor.tertiaryLabel))
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 3)
            .opacity(isTaken ? 0.65 : 1.0)
        }
        .disabled(isTaken)
        .buttonStyle(PlainButtonStyle())
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - SCREEN 4 · Confirm Role Assignment Screen
// ─────────────────────────────────────────────────────────────────
struct ConfirmRoleScreen: View {
    let user:          ClubUser
    let selectedRole:  LeadershipRole
    let selectedClub:  ClubData
    @Binding var allClubs: [ClubData]
    let onRoleUpdated: (String, String) -> Void
    let dismissToRoot: () -> Void

    @State private var navigateToSuccess = false
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {
            WorkflowSubHeader(title:    "Confirm Role Assignment",
                              subtitle: "Review the assignment before confirming")

            ScrollView {
                VStack(spacing: 24) {
                    assignmentPreviewCard.padding(.horizontal, 20)
                    confirmationMessageCard.padding(.horizontal, 20)


                    VStack(spacing: 12) {
                        Button(action: {
                            Task {
                                do {
                                    // 1. Join club (ignore error if already joined it throws)
                                    struct JoinReq: Encodable { let club_id: Int; let student_id: Int }
                                    struct JoinRes: Decodable { let id: Int }
                                    let req = JoinReq(club_id: selectedClub.dbId, student_id: user.dbId)
                                    _ = try? await APIClient.shared.request("/club-members/join", method: "POST", body: req) as JoinRes
                                    
                                    // 2. Promote the user globally (with the selected club)
                                    _ = try await AdminService.shared.promoteUser(userId: user.dbId, role: selectedRole.rawValue, clubId: selectedClub.dbId)

                                    await MainActor.run {
                                        // Update the club's occupied roles in the binding
                                        if let idx = allClubs.firstIndex(where: { $0.id == selectedClub.id }) {
                                            allClubs[idx].occupiedRoles.insert(selectedRole.rawValue)
                                        }
                                        onRoleUpdated(selectedRole.rawValue, selectedClub.name)
                                        navigateToSuccess = true
                                    }
                                } catch {
                                    print("Failed to assign role: \(error)")
                                }
                            }
                        }) {
                            HStack(spacing: 10) {
                                Image(systemName: "checkmark.seal.fill").font(.system(size: 18, weight: .semibold))
                                Text("Confirm Assignment").font(.headline)
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity).padding(.vertical, 16)
                            .background(LinearGradient(colors: [Color.purple, Color.blue],
                                                       startPoint: .leading, endPoint: .trailing))
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                            .shadow(color: Color.purple.opacity(0.30), radius: 8, x: 0, y: 4)
                        }

                        Button(action: { dismiss() }) {
                            Text("Cancel").font(.headline).foregroundColor(.secondary)
                                .frame(maxWidth: .infinity).padding(.vertical, 16)
                                .background(Color(UIColor.secondarySystemGroupedBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 16))
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 40)
                }
                .padding(.top, 20)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .navigationDestination(isPresented: $navigateToSuccess) {
            SuccessScreen(
                user:          user,
                assignedRole:  selectedRole,
                assignedClub:  selectedClub,
                dismissToRoot: dismissToRoot
            )
        }
    }

    private var assignmentPreviewCard: some View {
        VStack(spacing: 16) {
            // User → Role → Club
            HStack(spacing: 0) {
                // User
                VStack(spacing: 6) {
                    ZStack {
                        Circle().fill(LinearGradient(
                            colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.5)],
                            startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 52, height: 52)
                        Text(user.initials).font(.system(size: 17, weight: .bold)).foregroundColor(.white)
                    }
                    Text(user.name).font(.caption).bold().multilineTextAlignment(.center)
                    Text("→ \(selectedRole.displayName)").font(.caption2)
                        .foregroundColor(selectedRole.color).fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)

                // Arrow + Club badge
                VStack(spacing: 4) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12)
                            .fill(LinearGradient(
                                colors: [selectedClub.color, selectedClub.color.opacity(0.7)],
                                startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: 52, height: 52)
                        Image(systemName: selectedClub.icon)
                            .font(.system(size: 20, weight: .medium)).foregroundColor(.white)
                    }
                    Text(selectedClub.name).font(.caption).bold()
                        .multilineTextAlignment(.center)
                        .lineLimit(2)
                }
                .frame(maxWidth: .infinity)
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 3)
        }
    }

    private var confirmationMessageCard: some View {
        HStack(alignment: .top, spacing: 14) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 22)).foregroundColor(.orange).padding(.top, 2)
            VStack(alignment: .leading, spacing: 6) {
                Text("Please confirm").font(.subheadline).bold()
                Text("Assign \(user.name) as \(selectedRole.displayName) of \(selectedClub.name)?")
                    .font(.subheadline).foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(16)
        .background(Color.orange.opacity(0.08))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.orange.opacity(0.25), lineWidth: 1))
        .cornerRadius(14)
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - SCREEN 5 · Success Screen
// ─────────────────────────────────────────────────────────────────
struct SuccessScreen: View {
    let user:         ClubUser
    let assignedRole: LeadershipRole
    let assignedClub: ClubData
    let dismissToRoot: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            Spacer()

            // Success icon
            VStack(spacing: 20) {
                ZStack {
                    Circle().fill(LinearGradient(
                        colors: [Color.purple.opacity(0.15), Color.blue.opacity(0.10)],
                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 130, height: 130)
                    Circle().fill(LinearGradient(
                        colors: [Color.purple, Color.blue],
                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 90, height: 90)
                    .shadow(color: Color.purple.opacity(0.35), radius: 12, x: 0, y: 6)
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 42, weight: .semibold)).foregroundColor(.white)
                }

                Text("Role Assigned Successfully")
                    .font(.title2).bold().multilineTextAlignment(.center)

                Text("\(user.name) is now the \(assignedRole.rawValue) of \(assignedClub.name).")
                    .font(.subheadline).foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 32)
            }
            .padding(.horizontal, 24)

            Spacer()

            // Role + Club card
            HStack(spacing: 16) {
                VStack(spacing: 6) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 14)
                            .fill(LinearGradient(
                                colors: [assignedRole.color, assignedRole.color.opacity(0.7)],
                                startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: 52, height: 52)
                            .shadow(color: assignedRole.color.opacity(0.35), radius: 6, x: 0, y: 3)
                        Image(systemName: assignedRole.icon)
                            .font(.system(size: 22, weight: .medium)).foregroundColor(.white)
                    }
                    Text(assignedRole.rawValue).font(.caption).bold()
                        .foregroundColor(assignedRole.color)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text(user.name).font(.headline)
                    Text(assignedClub.name).font(.subheadline).foregroundColor(.secondary)
                    HStack(spacing: 4) {
                        Image(systemName: "tag.fill").font(.caption2)
                            .foregroundColor(assignedClub.color)
                        Text(assignedClub.category).font(.caption)
                            .foregroundColor(assignedClub.color)
                    }
                }
                Spacer()
            }
            .padding(18)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(20)
            .shadow(color: .black.opacity(0.06), radius: 8, x: 0, y: 4)
            .padding(.horizontal, 24)

            Spacer()

            // Login note
            HStack(spacing: 8) {
                Image(systemName: "info.circle.fill").font(.caption).foregroundColor(.blue)
                Text("On next login, \(user.name) will navigate to the \(assignedRole.rawValue) Dashboard.")
                    .font(.caption).foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(14)
            .background(Color.blue.opacity(0.07))
            .cornerRadius(12)
            .padding(.horizontal, 24)

            Spacer(minLength: 24)

            // Return button
            Button(action: dismissToRoot) {
                HStack(spacing: 8) {
                    Image(systemName: "house.fill")
                    Text("Return to Manage Users").font(.headline)
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity).padding(.vertical, 16)
                .background(LinearGradient(colors: [Color.purple, Color.blue],
                                           startPoint: .leading, endPoint: .trailing))
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.purple.opacity(0.30), radius: 8, x: 0, y: 4)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 40)
        }
        .background(Color(UIColor.systemGroupedBackground).ignoresSafeArea())
        .navigationBarHidden(true)
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - Shared compact workflow sub-header
// ─────────────────────────────────────────────────────────────────
struct WorkflowSubHeader: View {
    let title:    String
    let subtitle: String
    @Environment(\.dismiss) private var dismiss

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [Color.purple, Color.blue],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .clipShape(RoundedCorner(radius: 28, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop)
                HStack(alignment: .center) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title).font(.title3).bold().foregroundColor(.white).lineLimit(1)
                        Text(subtitle).font(.caption).foregroundColor(.white.opacity(0.80)).lineLimit(1)
                    }
                    .padding(.leading, 10)
                    Spacer()
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 14)
            }
        }
        .frame(height: safeTop + 74)
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - Previews
// ─────────────────────────────────────────────────────────────────
struct PromotionWorkflow_Previews: PreviewProvider {
    static let sampleUser = ClubUser(
        id: UUID(),
        name: "Alex Johnson", role: "Student",
        club: "Tech Innovation Club", eventsAttended: 11, attendance: 92, engagement: 87,
        profile_picture_url: nil
    )
    @State static var sampleClubs = ClubData.sampleClubs

    static var previews: some View {
        PreviewWrapper {
        Group {
            NavigationStack {
                UserProfileScreen(user: sampleUser, onProfileUpdated: { _, _ in }, dismissToRoot: {})
            }
            .previewDisplayName("User Profile")

            NavigationStack {
                SelectClubScreen(user: sampleUser, onRoleUpdated: { _, _ in }, dismissToRoot: {})
            }
            .previewDisplayName("Select Club")

            NavigationStack {
                PromoteUserScreen(user: sampleUser,
                                  selectedClub: ClubData.sampleClubs[0],
                                  allClubs: .constant(ClubData.sampleClubs),
                                  onRoleUpdated: { _, _ in }, dismissToRoot: {})
            }
            .previewDisplayName("Assign Role")

            NavigationStack {
                ConfirmRoleScreen(user: sampleUser, selectedRole: .president,
                                  selectedClub: ClubData.sampleClubs[1],
                                  allClubs: .constant(ClubData.sampleClubs),
                                  onRoleUpdated: { _, _ in }, dismissToRoot: {})
            }
            .previewDisplayName("Confirm Role")

            NavigationStack {
                SuccessScreen(user: sampleUser, assignedRole: .president,
                              assignedClub: ClubData.sampleClubs[1], dismissToRoot: {})
            }
            .previewDisplayName("Success")
        }
    
        }
    }
}
// ─────────────────────────────────────────────────────────────────
// MARK: - SCREEN 4 · Select New Leader Screen
// ─────────────────────────────────────────────────────────────────
struct SelectNewLeaderScreen: View {
    let currentLeader: ClubUser
    let onRoleUpdated: (String, String) -> Void
    let dismissToRoot: () -> Void

    @State private var members: [ClubMemberItem] = []
    @State private var isLoading = false
    @State private var errorMessage: String?
    @State private var isSwapping = false
    @Environment(\.dismiss) private var dismiss
    @Environment(\.auth) private var authManager

    var body: some View {
        VStack(spacing: 0) {
            WorkflowSubHeader(
                title: "Select New \(currentLeader.role)",
                subtitle: "Choose a student to replace \(currentLeader.name)"
            )
            
            if isLoading {
                Spacer(); ProgressView(); Spacer()
            } else if let err = errorMessage {
                Spacer(); Text(err).foregroundColor(.red); Spacer()
            } else if members.isEmpty {
                Spacer(); Text("No other students found."); Spacer()
            } else {
                List(members.filter { $0.role == "Student" }) { member in
                    Button {
                        Task { await performSwap(with: member) }
                    } label: {
                        HStack {
                            VStack(alignment: .leading) {
                                Text(member.name).font(.headline)
                                Text(member.email).font(.subheadline).foregroundColor(.secondary)
                            }
                            Spacer()
                            if isSwapping {
                                ProgressView()
                            } else {
                                Image(systemName: "chevron.right").foregroundColor(.secondary)
                            }
                        }
                    }
                }
                .listStyle(InsetGroupedListStyle())
            }
        }
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .onAppear { Task { await loadMembers() } }
    }

    private func loadMembers() async {
        isLoading = true
        defer { isLoading = false }
        do {
            // We use the clubId from authManager since the Admin/President is logged in
            guard let clubId = authManager.clubId else { return }
            members = try await ClubService.shared.getMembers(clubId: clubId)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func performSwap(with newLeader: ClubMemberItem) async {
        isSwapping = true
        defer { isSwapping = false }
        do {
            let res = try await AdminService.shared.changeLeadership(userId: currentLeader.dbId, newLeaderId: newLeader.id)
            print("Leadership swapped: \(res.message)")
            onRoleUpdated("Student", currentLeader.club) // Current person is now Student
            dismissToRoot()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

extension EnvironmentValues {
    // Helper to get AuthManager from environment if not using EnvironmentObject
    var auth: AuthManager {
        AuthManager.shared
    }
}
