//
//  SharedDashboardComponents.swift
//  CLUB ANALYTICSs
//
//  Reusable header + stat model shared by Secretary dashboards.
//

import SwiftUI

// MARK: - Stat data model
struct DashboardStat {
    let title:    String
    let value:    String
    let icon:     String
    var isWarning: Bool = false
}

// MARK: - Shared gradient header (used by Secretary & Student dashboards)
struct RoleDashboardHeader: View {
    let role: ClubRole
    let roleTitle: String
    var subtitle:  String = "Purple Innovation Club"   // ← now configurable
    let stats: [DashboardStat]          // exactly 4 items expected

    @EnvironmentObject private var authManager: AuthManager
    @StateObject private var vm = NotificationViewModel()
    @State private var showNotificationPanel = false
    

    private var safeTop: CGFloat {
        UIApplication.shared
            .connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?
            .safeAreaInsets.top ?? 50
    }

    var body: some View {
        ZStack(alignment: .top) {
            // ── Gradient background ───────────────────────────────────────────
            LinearGradient(
                colors: [Color.purple, Color.blue],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)

            // ── Content ───────────────────────────────────────────────────────
            VStack(alignment: .leading, spacing: 0) {

                // Safe-area spacer – pushes content below Dynamic Island / camera
                Color.clear.frame(height: safeTop + 16)

                // Row 1 – Title + Bell
                HStack(alignment: .center) {
                    Text(roleTitle)
                        .font(.title2).bold()
                        .foregroundColor(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                    Spacer()
                    Button(action: { showNotificationPanel = true }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 44, height: 44)
                            Image(systemName: "bell.badge.fill")
                                .font(.system(size: 20)).foregroundColor(.white)
                            
                            if vm.notifications.filter({ $0.is_read == 0 }).count > 0 {
                                Circle()
                                    .fill(Color.red)
                                    .frame(width: 12, height: 12)
                                    .offset(x: 12, y: -12)
                            }
                        }
                    }
                }
                .padding(.horizontal, 18)

                // Row 2 – Subtitle
                Text(subtitle)
                    .font(.subheadline).fontWeight(.medium)
                    .foregroundColor(.white.opacity(0.80))
                    .padding(.horizontal, 18)
                    .padding(.top, 4)
                    .padding(.bottom, 20)

                // Row 3 – Stat cards grid (2×2)
                LazyVGrid(columns: [
                    GridItem(.flexible(), spacing: 16),
                    GridItem(.flexible(), spacing: 16)
                ], spacing: 16) {
                    ForEach(stats.prefix(4), id: \.title) { stat in
                        StatCardView(
                            title:     stat.title,
                            value:     stat.value,
                            icon:      stat.icon,
                            isWarning: stat.isWarning
                        )
                    }
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 26)
            }
        }
        .frame(height: safeTop + 280)
        .sheet(isPresented: $showNotificationPanel) {
            NavigationStack {
                NotificationsView(role: role, vm: vm)
            }
        }
        .onAppear {
            if let uid = authManager.userId {
                vm.load(userId: uid, role: role.rawValue)
            }
        }
    }
}

// MARK: - Notifications View
struct NotificationsView: View {
    let role: ClubRole
    @ObservedObject var vm: NotificationViewModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        List {
            if vm.isLoading {
                ProgressView("Loading notifications...")
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.top, 40)
                    .listRowBackground(Color.clear)
            } else if let err = vm.errorMessage {
                Text("Error: \(err)")
                    .foregroundColor(.red)
                    .listRowBackground(Color.clear)
            } else if vm.notifications.isEmpty {
                Text("No new notifications")
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.top, 40)
                    .listRowBackground(Color.clear)
            } else {
                ForEach(vm.notifications) { note in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(note.title)
                            .font(.headline)
                        
                        Text(note.message)
                            .font(.subheadline)
                        
                        Text(formatDate(note.created_at))
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)
                    .listRowBackground(note.is_read == 1 ? Color(UIColor.systemBackground) : Color.blue.opacity(0.05))
                    .onTapGesture {
                        if note.is_read == 0 {
                            vm.markRead(note)
                        }
                    }
                }
            }
        }
        .navigationTitle("Notifications")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("Done") { dismiss() }
            }
        }
    }
    
    private func formatDate(_ str: String) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        // Try with fractional seconds
        f.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS"
        if let d = f.date(from: str) {
            let out = DateFormatter(); out.dateStyle = .medium; out.timeStyle = .short
            return out.string(from: d)
        }
        // Try without fractional seconds
        f.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        if let d = f.date(from: str) {
            let out = DateFormatter(); out.dateStyle = .medium; out.timeStyle = .short
            return out.string(from: d)
        }
        return str
    }
}

// MARK: - Shared Quick Action button used by all role dashboards
struct RoleQuickActionButton: View {
    let title:       String
    let icon:        String
    let color:       Color
    var action:      () -> Void = {}

    var body: some View {
        Button(action: action) {
            VStack(spacing: 12) {
                ZStack {
                    Circle().fill(color.opacity(0.15)).frame(width: 50, height: 50)
                    Image(systemName: icon).font(.system(size: 24)).foregroundColor(color)
                }
                Text(title)
                    .font(.subheadline).fontWeight(.semibold)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(16)
            .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Section header row (title + optional "View All" button)
struct SectionHeaderRow: View {
    let title: String
    var showViewAll: Bool = false

    var body: some View {
        HStack {
            Text(title).font(.title2).bold()
            Spacer()
            if showViewAll {
                Button("View All") {}
                    .font(.subheadline).fontWeight(.semibold).foregroundColor(.purple)
            }
        }
        .padding(.horizontal)
    }
}
