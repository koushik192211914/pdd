require 'xcodeproj'
require 'find'

project_path = 'CLUB ANALYTICSs.xcodeproj'
project = Xcodeproj::Project.open(project_path)

# Find the main target
target = project.targets.first

# Add a group if none exists, or just use main group
main_group = project.main_group
app_group = main_group.groups.find { |g| g.name == 'AppFiles' }
unless app_group
  app_group = main_group.new_group('AppFiles')
end

# Find all swift and xcassets
Dir.glob('*.swift').each do |file|
  unless app_group.files.find { |f| f.path == file }
    file_ref = app_group.new_file(file)
    target.source_build_phase.add_file_reference(file_ref)
  end
end

Dir.glob('*.xcassets').each do |file|
  unless app_group.files.find { |f| f.path == file }
    file_ref = app_group.new_file(file)
    target.resources_build_phase.add_file_reference(file_ref)
  end
end

project.save
puts "Successfully added all Swift and xcassets files to the Xcode project."
