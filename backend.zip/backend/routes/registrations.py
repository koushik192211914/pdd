from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from database import get_db
import models
import schemas
from core.permissions import require_student

router = APIRouter(
    prefix="/registrations",
    tags=["Event Registrations"]
)

@router.post("/register", response_model=schemas.EventRegistrationResponse)
def register_for_event(registration: schemas.EventRegistrationCreate, db: Session = Depends(get_db), student_user: models.User = Depends(require_student)):
    # Deriving student_id from authenticated user
    student_id = student_user.id
    
    # Check if event exists
    event = db.query(models.Event).filter(models.Event.id == registration.event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    # Verify club membership
    is_member = db.query(models.ClubMember).filter(
        models.ClubMember.club_id == event.club_id,
        models.ClubMember.student_id == student_id
    ).first()
    if not is_member:
        raise HTTPException(status_code=403, detail="You must be a member of this club to join its events.")
        
    # Check if already registered
    existing_reg = db.query(models.EventRegistration).filter(
        models.EventRegistration.event_id == registration.event_id,
        models.EventRegistration.student_id == student_id
    ).first()
    if existing_reg:
        raise HTTPException(status_code=400, detail="Student already registered for this event")
        
    new_reg = models.EventRegistration(
        event_id=registration.event_id,
        student_id=student_id
    )
    db.add(new_reg)
    db.commit()
    db.refresh(new_reg)

    # Notify the club president about this registration
    club = db.query(models.Club).filter(models.Club.id == event.club_id).first()
    if club and club.created_by:
        notif = models.Notification(
            user_id=club.created_by,
            title="New Event Registration",
            message=f"{student_user.name} has registered for '{event.event_name}'."
        )
        db.add(notif)
        db.commit()

    return new_reg

@router.get("/event/{event_id}/participants")
def get_event_participants(event_id: int, db: Session = Depends(get_db)):
    """Returns enriched participant list for an event."""
    regs = db.query(models.EventRegistration).filter(
        models.EventRegistration.event_id == event_id
    ).all()
    result = []
    for reg in regs:
        user = db.query(models.User).filter(models.User.id == reg.student_id).first()
        if user:
            result.append({
                "registration_id": reg.id,
                "student_id": user.id,
                "name": user.name,
                "email": user.email,
                "status": reg.status,
                "registration_date": str(reg.registration_date)
            })
    return result

@router.get("", response_model=List[schemas.EventRegistrationResponse])
def get_all_registrations(db: Session = Depends(get_db)):
    registrations = db.query(models.EventRegistration).all()
    return registrations

@router.get("/event/{event_id}", response_model=List[schemas.EventRegistrationResponse])
def get_participants_of_event(event_id: int, db: Session = Depends(get_db)):
    registrations = db.query(models.EventRegistration).filter(models.EventRegistration.event_id == event_id).all()
    return registrations

@router.get("/student/{student_id}", response_model=List[schemas.EventRegistrationResponse])
def get_events_registered_by_student(student_id: int, db: Session = Depends(get_db)):
    registrations = db.query(models.EventRegistration).filter(models.EventRegistration.student_id == student_id).all()
    return registrations

@router.delete("/{registration_id}")
def delete_registration(registration_id: int, db: Session = Depends(get_db)):
    registration = db.query(models.EventRegistration).filter(models.EventRegistration.id == registration_id).first()
    if not registration:
        raise HTTPException(status_code=404, detail="Registration not found")
        
    db.delete(registration)
    db.commit()
    return {"message": "Registration deleted successfully"}
