from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from database import get_db
import models
import schemas
from core.permissions import require_authority

router = APIRouter(
    prefix="/event-attendance",
    tags=["Event Attendance"]
)

@router.post("/mark", response_model=schemas.MessageResponse)
def mark_attendance(attendance_list: List[schemas.EventAttendanceCreate], db: Session = Depends(get_db), auth_user: models.User = Depends(require_authority)):
    
    # Track metrics for admin notification
    marked_count = 0
    event_id_ref = None
    
    for attendance in attendance_list:
        if event_id_ref is None:
            event_id_ref = attendance.event_id
            
        # 1. Check if attendance already marked
        existing = db.query(models.EventAttendance).filter(
            models.EventAttendance.event_id == attendance.event_id,
            models.EventAttendance.student_id == attendance.student_id
        ).first()
        
        if existing:
            existing.status = attendance.status
            existing.marked_by = auth_user.id
        else:
            new_attendance = models.EventAttendance(
                event_id=attendance.event_id,
                student_id=attendance.student_id,
                status=attendance.status,
                marked_by=auth_user.id
            )
            db.add(new_attendance)
            marked_count += 1
            
        # 2. Add Notification for the student
        student_notif = models.Notification(
            user_id=attendance.student_id,
            title="Attendance Logged",
            message=f"You have been successfully marked {attendance.status} for event ID {attendance.event_id}."
        )
        db.add(student_notif)

    # 3. Add Global Admin Notification (user_id=None)
    if event_id_ref is not None:
        admin_notif = models.Notification(
            user_id=None,
            title="Event Attendance Submitted",
            message=f"{auth_user.name} submitted attendance for {len(attendance_list)} students in Event ID {event_id_ref}."
        )
        db.add(admin_notif)

    db.commit()
    return schemas.MessageResponse(message=f"Successfully marked/updated attendance for {len(attendance_list)} students.")

@router.post("/mark-bulk", response_model=schemas.MessageResponse)
def mark_bulk_attendance(
    payload: schemas.BulkAttendanceCreate, 
    db: Session = Depends(get_db), 
    auth_user: models.User = Depends(require_authority)
):
    # Verify event exists
    event = db.query(models.Event).filter(models.Event.id == payload.event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
        
    for student_id_str, is_present in payload.attendance.items():
        try:
            student_id = int(student_id_str)
        except ValueError:
            continue
            
        status = "Present" if is_present else "Absent"
        
        # Check if attendance already exists
        existing = db.query(models.EventAttendance).filter(
            models.EventAttendance.event_id == payload.event_id,
            models.EventAttendance.student_id == student_id
        ).first()
        
        if existing:
            existing.status = status
            existing.marked_by = auth_user.id
        else:
            # Verify registration (optional but safer)
            registration = db.query(models.EventRegistration).filter(
                models.EventRegistration.event_id == payload.event_id,
                models.EventRegistration.student_id == student_id
            ).first()
            
            if registration:
                new_attendance = models.EventAttendance(
                    event_id=payload.event_id,
                    student_id=student_id,
                    status=status,
                    marked_by=auth_user.id
                )
                db.add(new_attendance)
                
    db.commit()
    return schemas.MessageResponse(message=f"Bulk attendance updated for event {payload.event_id}")

@router.get("/event/{event_id}", response_model=List[schemas.EventAttendanceResponse])
def get_attendance_for_event(event_id: int, db: Session = Depends(get_db)):
    records = db.query(models.EventAttendance).filter(models.EventAttendance.event_id == event_id).all()
    return records

@router.get("/student/{student_id}", response_model=List[schemas.EventAttendanceResponse])
def get_attendance_for_student(student_id: int, db: Session = Depends(get_db)):
    records = db.query(models.EventAttendance).filter(models.EventAttendance.student_id == student_id).all()
    return records

@router.put("/{attendance_id}", response_model=schemas.EventAttendanceResponse)
def update_attendance(attendance_id: int, status: str, db: Session = Depends(get_db)):
    record = db.query(models.EventAttendance).filter(models.EventAttendance.id == attendance_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Attendance record not found")
        
    record.status = status
    db.commit()
    db.refresh(record)
    return record

@router.delete("/{attendance_id}")
def delete_attendance(attendance_id: int, db: Session = Depends(get_db)):
    record = db.query(models.EventAttendance).filter(models.EventAttendance.id == attendance_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Attendance record not found")
        
    db.delete(record)
    db.commit()
    return {"message": "Attendance record deleted"}
