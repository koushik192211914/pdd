from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from database import get_db
import models
import schemas
from core.permissions import require_authority

router = APIRouter(
    prefix="/club-members",
    tags=["Club Members"]
)

@router.post("/join", response_model=schemas.ClubMemberResponse)
def join_club(member: schemas.ClubMemberCreate, db: Session = Depends(get_db)):
    # Check if a user is already a member
    existing_member = db.query(models.ClubMember).filter(
        models.ClubMember.club_id == member.club_id,
        models.ClubMember.student_id == member.student_id
    ).first()
    
    if existing_member:
        raise HTTPException(status_code=400, detail="Student is already a member of this club")
        
    new_member = models.ClubMember(
        club_id=member.club_id,
        student_id=member.student_id
    )
    db.add(new_member)
    db.commit()
    db.refresh(new_member)
    return new_member

@router.get("/club/{club_id}", response_model=List[schemas.ClubMemberResponse])
def get_members_of_club(club_id: int, db: Session = Depends(get_db), auth_user: models.User = Depends(require_authority)):
    members = db.query(models.ClubMember).filter(models.ClubMember.club_id == club_id).all()
    return members

@router.get("/{club_id}/members")
def get_club_members_list(club_id: int, db: Session = Depends(get_db)):
    """Clean list of members for a specific club."""
    members = db.query(models.ClubMember).filter(models.ClubMember.club_id == club_id).all()
    result = []
    for m in members:
        user = db.query(models.User).filter(models.User.id == m.student_id).first()
        if user:
            result.append({
                "id": user.id,
                "name": user.name,
                "email": user.email,
                "role": user.role
            })
    return result

@router.get("/student/{student_id}", response_model=List[schemas.ClubMemberResponse])
def get_clubs_of_student(student_id: int, db: Session = Depends(get_db)):
    clubs = db.query(models.ClubMember).filter(models.ClubMember.student_id == student_id).all()
    return clubs


@router.delete("/{member_id}")
def remove_member_from_club(member_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(require_authority)):
    member = db.query(models.ClubMember).filter(models.ClubMember.id == member_id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Club member record not found")
        
    db.delete(member)
    db.commit()
    return {"message": "Member removed successfully"}


@router.delete("/leave/{student_id}")
def leave_club(student_id: int, club_id: int, db: Session = Depends(get_db)):
    member = db.query(models.ClubMember).filter(
        models.ClubMember.student_id == student_id,
        models.ClubMember.club_id == club_id
    ).first()
    if not member:
        raise HTTPException(status_code=404, detail="Membership not found")
        
    db.delete(member)
    db.commit()
    return {"message": "Successfully left the club"}
