//
//  RegistrationService.swift
//  CLUB ANALYTICSs
//
//  POST /registrations/register  (Student only)
//

import Foundation

final class RegistrationService {
    static let shared = RegistrationService()
    private init() {}

    func register(eventId: Int) async throws -> EventRegistrationResponse {
        let request = EventRegistrationCreate(event_id: eventId)
        return try await APIClient.shared.request("/registrations/register", method: "POST", body: request)
    }
}
