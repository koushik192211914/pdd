//
//  AuthManager.swift
//  CLUB ANALYTICSs
//
//  Manages authentication state across the app.
//  Persists userId, role, and name in UserDefaults.
//

import Foundation
import SwiftUI
import Combine

typealias User = UserResponseModel

final class AuthManager: ObservableObject {
    static let shared = AuthManager()

    // MARK: - Published State
    @Published var user: User? = nil {
        didSet {
            if let u = user {
                UserDefaults.standard.set(u.id, forKey: Keys.userId)
                UserDefaults.standard.set(u.role, forKey: Keys.role)
                UserDefaults.standard.set(u.name, forKey: Keys.name)
                UserDefaults.standard.set(u.email, forKey: Keys.email)
                if let cid = u.club_id {
                    UserDefaults.standard.set(cid, forKey: Keys.clubId)
                }
            } else {
                UserDefaults.standard.removeObject(forKey: Keys.userId)
                UserDefaults.standard.removeObject(forKey: Keys.role)
                UserDefaults.standard.removeObject(forKey: Keys.name)
                UserDefaults.standard.removeObject(forKey: Keys.email)
                UserDefaults.standard.removeObject(forKey: Keys.clubId)
            }
        }
    }

    @Published var hasSeenOnboarding: Bool {
        didSet {
            UserDefaults.standard.set(hasSeenOnboarding, forKey: Keys.onboarding)
        }
    }

    var userId: Int?     { user?.id }
    var userRole: String { user?.role ?? "Student" }
    var userName: String { user?.name ?? "" }
    var userEmail: String{ user?.email ?? "" }
    var clubId: Int?     { user?.club_id }

    var isLoggedIn: Bool { user != nil }

    // MARK: - Keys
    private enum Keys {
        static let userId = "cs_userId"
        static let role   = "cs_role"
        static let name   = "cs_name"
        static let email  = "cs_email"
        static let clubId = "cs_clubId"
        static let onboarding = "cs_hasSeenOnboarding"
    }

    // MARK: - Init (restore from UserDefaults)
    private init() {
        self.hasSeenOnboarding = UserDefaults.standard.bool(forKey: Keys.onboarding)
        
        // Disabled auto-login persistence to ensure app always starts at Login/Onboarding
        /*
        if let storedId = UserDefaults.standard.object(forKey: Keys.userId) as? Int {
            let role  = UserDefaults.standard.string(forKey: Keys.role)  ?? "Student"
            let name  = UserDefaults.standard.string(forKey: Keys.name)  ?? ""
            let email = UserDefaults.standard.string(forKey: Keys.email) ?? ""
            let cId   = UserDefaults.standard.object(forKey: Keys.clubId) as? Int
            
            self.user = User(id: storedId, name: name, email: email, role: role, created_at: "", club_id: cId)
        } else {
            self.user = nil
        }
        */
        self.user = nil
    }

    // MARK: - Session Actions
    @MainActor
    func saveSession(user: User) {
        withAnimation(.easeInOut) {
            self.user = user
        }
    }

    @MainActor
    func logout() {
        print("👤 [AuthManager] logout initiated")
        withAnimation(.easeInOut) {
            self.user = nil
        }
        
        // Only clear session-specific keys to preserve onboarding state
        UserDefaults.standard.removeObject(forKey: Keys.userId)
        UserDefaults.standard.removeObject(forKey: Keys.role)
        UserDefaults.standard.removeObject(forKey: Keys.name)
        UserDefaults.standard.removeObject(forKey: Keys.email)
        UserDefaults.standard.removeObject(forKey: Keys.clubId)
        
        UserDefaults.standard.synchronize()
        print("✅ [AuthManager] session cleared (onboarding state preserved)")
    }

    // MARK: - Role helpers
    var clubRole: ClubRole {
        let normalized = userRole.lowercased()
        print("🔐 [AuthManager] mapping userRole: '\(userRole)' (normalized: '\(normalized)') to ClubRole")
        
        switch normalized {
        case "admin":         return .admin
        case "president":     return .president
        case "vicepresident": return .vicePresident
        case "secretary":     return .secretary
        case "student":       return .student
        default:
            print("⚠️ [AuthManager] unknown mapping for '\(userRole)', defaulting to .student")
            return .student
        }
    }
}
