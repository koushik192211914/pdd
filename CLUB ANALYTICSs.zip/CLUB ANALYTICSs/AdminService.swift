//
//  AdminService.swift
//  CLUB ANALYTICSs
//
//  GET /admin/users  |  POST /admin/promote/{id}  |  POST /admin/demote/{id}
//

import Foundation

final class AdminService {
    static let shared = AdminService()
    private init() {}

    func getAllUsers() async throws -> [AdminUserResponse] {
        return try await APIClient.shared.request("/admin/users")
    }

    func getPlatformSummary() async throws -> PlatformSummaryResponse {
        return try await APIClient.shared.request("/analytics/platform-summary")
    }

    func getDashboard() async throws -> DashboardResponse {
        return try await APIClient.shared.request("/analytics/dashboard")
    }

    func promoteUser(userId: Int, role: String) async throws -> MessageResponse {
        let request = PromoteRequest(role: role)
        return try await APIClient.shared.request("/admin/promote/\(userId)", method: "POST", body: request)
    }

    func demoteUser(userId: Int) async throws -> MessageResponse {
        return try await APIClient.shared.request("/admin/demote/\(userId)", method: "POST")
    }

    func removeUser(userId: Int) async throws -> MessageResponse {
        return try await APIClient.shared.request("/members/remove/\(userId)", method: "DELETE")
    }

    func changeLeadership(userId: Int, newLeaderId: Int) async throws -> MessageResponse {
        let req = ChangeLeadershipRequest(new_leader_id: newLeaderId)
        return try await APIClient.shared.request("/admin/change-leadership/\(userId)", method: "POST", body: req)
    }
}
