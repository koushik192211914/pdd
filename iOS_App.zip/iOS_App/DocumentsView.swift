import SwiftUI

struct ReportDocument: Identifiable {
    let id = UUID()
    let title: String
    let eventName: String
    let uploadDate: String
    let type: String
    let description: String
}

struct DocumentsView: View {
    @Environment(\.dismiss) private var dismiss

    // Sample data
    @State private var documents: [ReportDocument] = [
        ReportDocument(title: "Tech Workshop Report", eventName: "Tech Workshop", uploadDate: "Mar 08, 2026", type: "Event Report", description: "Detailed summary of the tech workshop outcomes and participant feedback."),
        ReportDocument(title: "Meeting Minutes – March", eventName: "Spring General Meeting", uploadDate: "Mar 05, 2026", type: "Meeting Minutes", description: "Minutes from the spring opening general assembly."),
        ReportDocument(title: "Annual Event Summary", eventName: "Fall Gala", uploadDate: "Feb 28, 2026", type: "Activity Report", description: "Comprehensive review of the fall flagship event success metrics."),
        ReportDocument(title: "Budget Proposal Q2", eventName: "Board Meeting", uploadDate: "Feb 20, 2026", type: "Activity Report", description: "Financial breakdown and funding request for upcoming quarter activities.")
    ]

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        VStack(spacing: 0) {
            // ── Header ───────────────────────────────────────────────
            headerView

            // ── Document List ──────────────────────────────────────────
            ScrollView {
                VStack(spacing: 16) {
                    if documents.isEmpty {
                        VStack(spacing: 20) {
                            Image(systemName: "doc.text.magnifyingglass")
                                .font(.system(size: 60))
                                .foregroundColor(.secondary.opacity(0.3))
                            Text("No documents found")
                                .font(.headline)
                                .foregroundColor(.secondary)
                        }
                        .padding(.top, 100)
                    } else {
                        ForEach(documents) { doc in
                            NavigationLink(destination: DocumentDetailView(document: doc, onDelete: {
                                withAnimation {
                                    documents.removeAll(where: { $0.id == doc.id })
                                }
                            })) {
                                DocumentRow(document: doc)
                            }
                        }
                    }
                }
                .padding(20)
                .padding(.bottom, 40)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
    }

    private var headerView: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 8)
                HStack(alignment: .center, spacing: 12) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("View Documents").font(.title3).bold().foregroundColor(.white)
                        Text("Management portal for club reports")
                            .font(.caption).foregroundColor(.white.opacity(0.80))
                    }
                    Spacer()
                }
                .padding(.horizontal, 18).padding(.bottom, 22)
            }
        }
        .frame(height: safeTop + 92) // Changed from minHeight to height
    }
}

struct DocumentRow: View {
    let document: ReportDocument

    var body: some View {
        HStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.blue.opacity(0.1))
                    .frame(width: 48, height: 48)
                Image(systemName: "doc.fill")
                    .foregroundColor(.blue)
                    .font(.system(size: 20))
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(document.title)
                    .font(.subheadline).bold()
                    .foregroundColor(.primary)
                Text(document.eventName)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 4) {
                Text(document.uploadDate)
                    .font(.caption2)
                    .foregroundColor(.secondary)
                Image(systemName: "chevron.right")
                    .font(.caption2)
                    .foregroundColor(.secondary.opacity(0.5))
            }
        }
        .padding()
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.04), radius: 5, x: 0, y: 2)
    }
}

struct DocumentDetailView: View {
    let document: ReportDocument
    var onDelete: () -> Void
    @Environment(\.dismiss) private var dismiss

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        VStack(spacing: 0) {
            // Header
            ZStack(alignment: .top) {
                LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                    .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))

                VStack(alignment: .leading, spacing: 0) {
                    Color.clear.frame(height: safeTop + 8)
                    HStack {
                        Button(action: { dismiss() }) {
                            ZStack {
                                Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                                Image(systemName: "chevron.left").font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                            }
                        }
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Document Details").font(.title3).bold().foregroundColor(.white)
                            Text(document.type).font(.caption).foregroundColor(.white.opacity(0.8))
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 18).padding(.bottom, 22)
                }
            }
            .frame(minHeight: safeTop + 92)

            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    // Document Icon + Title
                    HStack(spacing: 20) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 16)
                                .fill(Color.blue.opacity(0.1))
                                .frame(width: 70, height: 70)
                            Image(systemName: "doc.fill")
                                .font(.system(size: 30))
                                .foregroundColor(.blue)
                        }

                        VStack(alignment: .leading, spacing: 6) {
                            Text(document.title)
                                .font(.title3).bold()
                            Text("Uploaded on \(document.uploadDate)")
                                .font(.subheadline).foregroundColor(.secondary)
                        }
                    }
                    .padding(.top, 20)

                    Divider()

                    // Info Section
                    VStack(alignment: .leading, spacing: 16) {
                        InfoRow(label: "Event Name", value: document.eventName, icon: "calendar")
                        InfoRow(label: "Report Type", value: document.type, icon: "tag.fill")
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Description", systemImage: "text.alignleft")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            Text(document.description)
                                .font(.subheadline)
                                .foregroundColor(.primary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }

                    Spacer()

                    // Actions
                    VStack(spacing: 12) {
                        Button(action: {}) {
                            ActionWideButton(title: "Open Document", icon: "arrow.up.right.square.fill", color: .blue)
                        }

                        Button(action: {}) {
                            ActionWideButton(title: "Download", icon: "icloud.and.arrow.down.fill", color: .purple)
                        }

                        Button(action: {
                            onDelete()
                            dismiss()
                        }) {
                            ActionWideButton(title: "Delete Document", icon: "trash.fill", color: .red)
                        }
                    }
                    .padding(.bottom, 40)
                }
                .padding(.horizontal, 20)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
    }
}

struct InfoRow: View {
    let label: String
    let value: String
    let icon: String

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon).foregroundColor(.secondary).frame(width: 20)
            VStack(alignment: .leading, spacing: 2) {
                Text(label).font(.caption).foregroundColor(.secondary)
                Text(value).font(.subheadline).fontWeight(.medium)
            }
        }
    }
}

struct ActionWideButton: View {
    let title: String
    let icon: String
    let color: Color

    var body: some View {
        HStack {
            Image(systemName: icon)
            Text(title).fontWeight(.semibold)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .foregroundColor(color)
        .background(color.opacity(0.1))
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(color.opacity(0.3), lineWidth: 1)
        )
    }
}

#Preview {
    PreviewWrapper {
    NavigationStack {
        DocumentsView()
    }

    }
}
