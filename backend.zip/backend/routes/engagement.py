from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
from pydantic import BaseModel
from database import get_db
from models import (
    UserRole, User, ClubMember,
    EventRegistration, EventAttendance, ClubAttendanceRecord, ClubAttendanceSession
)
from core.permissions import require_authority, get_current_user

router = APIRouter(prefix="/engagement", tags=["Engagement"])

class StudentEngagementResponse(BaseModel):
    student_id: int
    attendance_rate: float
    events_registered: int
    events_attended: int
    engagement_score: float

class ClubEngagementResponse(BaseModel):
    students: List[StudentEngagementResponse]

def calculate_student_engagement(student_id: int, db: Session) -> float:
    # 1. Club Attendance -> 50 points
    # Calculate attendance rate
    # Find total number of club attendance sessions the student could attend 
    # (for simplicity, we'll assume total sessions for all clubs they belong to)
    
    # Let's count present records as present_days
    present_days = db.query(func.count(ClubAttendanceRecord.id)).filter(
        ClubAttendanceRecord.student_id == student_id,
        ClubAttendanceRecord.status.in_(["Present", "Attended"])
    ).scalar() or 0
    
    # Ideally total_days would be derived from the club the specific student is in.
    # To prevent division by zero, we'll assume a baseline if no records exist.
    # Let's fetch all sessions for clubs the student is in
    clubs_memberships = db.query(ClubMember.club_id).filter(ClubMember.student_id == student_id).all()
    club_ids = [c[0] for c in clubs_memberships]
    
    if not club_ids:
        total_days = 0
    else:
        total_days = db.query(func.count(ClubAttendanceSession.id)).filter(
            ClubAttendanceSession.club_id.in_(club_ids)
        ).scalar() or 0

    attendance_rate = 0.0
    if total_days > 0:
        attendance_rate = (present_days / total_days) * 50.0

    # 2. Event Participation -> 30 points
    events_registered = db.query(func.count(EventRegistration.id)).filter(
        EventRegistration.student_id == student_id
    ).scalar() or 0
    
    event_participation_score = min(events_registered * 5.0, 30.0)

    # 3. Event Attendance -> 20 points
    events_attended = db.query(func.count(EventAttendance.id)).filter(
        EventAttendance.student_id == student_id,
        EventAttendance.status.in_(["Present", "Attended"])
    ).scalar() or 0
    
    event_attendance_score = min(events_attended * 5.0, 20.0)

    engagement_score = attendance_rate + event_participation_score + event_attendance_score
    
    return {
        "student_id": student_id,
        "attendance_rate": attendance_rate, # Storing score component or percentage? Let's use the rate mapped to out of 50 per prompt calculation. We can just return the rate out of 50. The example says 80, maybe it means percentage. Let's send the computed components back.
        "events_registered": events_registered,
        "events_attended": events_attended,
        "engagement_score": round(engagement_score, 2)
    }

@router.get("/student/{student_id}", response_model=StudentEngagementResponse)
def get_student_engagement(student_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    # Check permissions:
    # 1. Admin/President/VicePresident/Secretary can see anyone.
    # 2. Student can only see their own.
    
    authority_roles = [UserRole.Admin, UserRole.President, UserRole.VicePresident, UserRole.Secretary]
    if current_user.role not in authority_roles and current_user.id != student_id:
        raise HTTPException(status_code=403, detail="Not authorized to view engagement")
        
    user = db.query(User).filter(User.id == student_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Student not found")
        
    data = calculate_student_engagement(student_id, db)
    # The prompt expects attendance_rate to perhaps be out of 100 for the response (example: 80). 
    # We will compute attendance matching the prompt's `attendance_rate = (present_days / total_days) * 50`.
    return data

@router.get("/club/{club_id}", response_model=List[StudentEngagementResponse])
def get_club_engagement(club_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_authority)):
    allowed_roles = [UserRole.Admin, UserRole.President, UserRole.VicePresident, UserRole.Secretary]
    if current_user.role not in allowed_roles:
        raise HTTPException(status_code=403, detail="Not authorized to view engagement")
        
    members = db.query(ClubMember).filter(ClubMember.club_id == club_id).all()
    results = []
    
    for member in members:
        engagement_data = calculate_student_engagement(member.student_id, db)
        results.append(engagement_data)
        
    # Sort by engagement score descending
    results.sort(key=lambda x: x["engagement_score"], reverse=True)
    return results
