import SwiftUI

// MARK: - Attendance Choice
enum AttendanceChoice: String, CaseIterable {
    case present  = "Present"
    case absent   = "Absent"
    case substitute = "Substitute"

    var color: Color {
        switch self {
        case .present:    return .green
        case .absent:     return .red
        case .substitute: return .orange
        }
    }
    var icon: String {
        switch self {
        case .present:    return "checkmark.square.fill"
        case .absent:     return "xmark.square.fill"
        case .substitute: return "arrow.triangle.2.circlepath"
        }
    }
}

// MARK: - Mark Attendance View
struct MarkAttendanceView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var store: AttendanceNotificationStore
    @EnvironmentObject var authManager: AuthManager

    let eventId: String

    @State private var participants: [ClubMemberItem] = []
    @State private var isLoading = true
    @State private var errorMessage: String?

    // choice per member id
    @State private var choices: [Int: AttendanceChoice] = [:]
    // substitute name per member id
    @State private var substituteNames: [Int: String] = [:]

    // substitute picker
    @State private var pickingSubstituteFor: ClubMemberItem? = nil

    @State private var isSubmitting = false
    @State private var submitMessage: String?

    var body: some View {
        ZStack {
            Color(UIColor.systemGroupedBackground).ignoresSafeArea()

            VStack(spacing: 0) {
                MarkAttendanceHeader(eventId: eventId)

                if isLoading {
                    Spacer()
                    ProgressView("Loading members...")
                    Spacer()
                } else if let error = errorMessage {
                    Spacer()
                    Text(error).foregroundColor(.red).padding()
                    Spacer()
                } else if participants.isEmpty {
                    Spacer()
                    VStack(spacing: 10) {
                        Image(systemName: "person.3").font(.system(size: 44)).foregroundColor(.secondary)
                        Text("No club members found.").foregroundColor(.secondary)
                    }
                    Spacer()
                } else {
                    ScrollView {
                        VStack(spacing: 12) {
                            ForEach(participants) { member in
                                AttendanceRow(
                                    member: member,
                                    choice: Binding(
                                        get: { choices[member.id] },
                                        set: { choices[member.id] = $0 }
                                    ),
                                    substituteName: substituteNames[member.id],
                                    onPickSubstitute: { pickingSubstituteFor = member },
                                    isSelf: member.id == authManager.userId,
                                    isClubAttendance: eventId.isEmpty
                                )
                            }
                        }
                        .padding(.horizontal)
                        .padding(.top, 16)
                        .padding(.bottom, 110)
                    }
                }
            }

            // Submit button
            VStack {
                Spacer()
                if let msg = submitMessage {
                    Text(msg).font(.caption).foregroundColor(.green).padding(.bottom, 4)
                }
                let allMarked = participants.allSatisfy { member in
                    if authManager.userId == member.id { return true }
                    return choices[member.id] != nil
                }
                Button(action: submitAttendance) {
                    if isSubmitting {
                        ProgressView().tint(.white)
                    } else {
                        Text("Submit Attendance")
                            .font(.headline).foregroundColor(.white)
                    }
                }
                .frame(maxWidth: .infinity).frame(height: 52)
                .background(allMarked ? Color.blue : Color.gray.opacity(0.5))
                .cornerRadius(14)
                .padding(.horizontal)
                .padding(.bottom, 20)
                .disabled(!allMarked || isSubmitting)
            }
        }
        .navigationBarHidden(true)
        .onAppear { Task { await loadMembers() } }
        // Substitute picker sheet
        .sheet(item: $pickingSubstituteFor) { target in
            SubstitutePickerSheet(
                target: target,
                allMembers: participants,
                alreadyPresent: Set(participants.compactMap { m -> Int? in
                    choices[m.id] == .present ? m.id : nil
                }),
                onSelect: { chosen in
                    substituteNames[target.id] = chosen.name
                    pickingSubstituteFor = nil
                },
                onNoAvailable: {
                    substituteNames[target.id] = nil
                    pickingSubstituteFor = nil
                }
            )
        }
    }

    // MARK: - Load Members
    private func loadMembers() async {
        isLoading = true
        defer { isLoading = false }
        guard let clubId = authManager.clubId else {
            errorMessage = "No club assigned."; return
        }
        do {
            participants = try await ClubService.shared.getMembers(clubId: clubId)
        } catch {
            errorMessage = "Failed to load members."
        }
    }

    // Submit attendance to actual backend endpoints
    private func submitAttendance() {
        isSubmitting = true

        Task {
            if eventId.isEmpty {
                // CLUB ATTENDANCE
                guard let clubId = authManager.clubId else { return }
                
                do {
                    // 1. Create session
                    let session: AttendanceSessionResponse = try await APIClient.shared.request("/club-attendance/\(clubId)/session", method: "POST")
                    let sessionId = session.id
                    
                    // 2. Mark records
                    var payload: [AttendanceRecordRequest] = []
                    for member in participants {
                        if authManager.userId == member.id { continue } // Cannot mark self
                        let choice = choices[member.id] ?? .absent
                        payload.append(AttendanceRecordRequest(
                            session_id: sessionId,
                            student_id: member.id,
                            status: choice == .present ? "present" : "absent"
                        ))
                    }
                    
                    for item in payload {
                        let _: AttendanceRecordResponse = try await APIClient.shared.request("/club-attendance/mark", method: "POST", body: item)
                    }
                } catch {
                    print("❌ Club Attendance Error: \(error)")
                }

            } else {
                // EVENT ATTENDANCE
                guard let eId = Int(eventId) else { return }
                
                var eventPayload: [EventAttendanceRequest] = []
                for member in participants {
                    if authManager.userId == member.id { continue }
                    
                    let choice = choices[member.id] ?? .absent
                    let statusStr = (choice == .present) ? "present" : (choice == .absent ? "absent" : "substitute")
                    var rec = EventAttendanceRequest(
                        event_id: eId,
                        student_id: member.id,
                        status: statusStr
                    )
                    if choice == .substitute, let subName = substituteNames[member.id], 
                       let subId = participants.first(where: { $0.name == subName })?.id {
                        rec.substitute_id = subId
                    }
                    eventPayload.append(rec)
                }
                
                do {
                    let _: MessageResponse = try await APIClient.shared.request("/event-attendance/mark", method: "POST", body: eventPayload)
                } catch {
                    print("❌ Event Attendance Error: \(error)")
                }
            }
            
            await MainActor.run {
                submitMessage = "Attendance submitted!"
                isSubmitting = false
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { dismiss() }
            }
        }
    }
}

private struct AttendanceRow: View {
    let member: ClubMemberItem
    @Binding var choice: AttendanceChoice?
    let substituteName: String?
    let onPickSubstitute: () -> Void
    let isSelf: Bool
    let isClubAttendance: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                ZStack {
                    Circle().fill(Color.purple.opacity(0.10)).frame(width: 42, height: 42)
                    Text(String(member.name.prefix(1)).uppercased())
                        .font(.headline).foregroundColor(.purple)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(member.name).font(.subheadline).fontWeight(.semibold)
                    if isSelf {
                        Text("Self (Cannot Mark)").font(.caption).foregroundColor(.orange)
                    } else {
                        Text(member.role).font(.caption).foregroundColor(.secondary)
                    }
                }
                Spacer()
            }

            // toggle buttons
            HStack(spacing: 8) {
                let options = isClubAttendance ? [.present, .absent] : AttendanceChoice.allCases
                ForEach(options, id: \.self) { opt in
                    Button {
                        choice = opt
                        if opt == .substitute { onPickSubstitute() }
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: choice == opt ? opt.icon : "square")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(choice == opt ? opt.color : .secondary)
                            Text(opt.rawValue)
                                .font(.caption).fontWeight(.semibold)
                                .foregroundColor(choice == opt ? opt.color : .secondary)
                        }
                        .padding(.horizontal, 10).padding(.vertical, 7)
                        .background(choice == opt ? opt.color.opacity(0.12) : Color(UIColor.systemFill))
                        .clipShape(Capsule())
                    }
                    .buttonStyle(PlainButtonStyle())
                    .disabled(isSelf)
                }
            }

            if choice == .substitute {
                if let sub = substituteName {
                    Text("Substitute: \(sub)").font(.caption).foregroundColor(.orange).padding(.leading, 4)
                } else {
                    Text("Tap 'Substitute' again to pick a member")
                        .font(.caption).foregroundColor(.secondary).padding(.leading, 4)
                }
            }
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Substitute Picker Sheet
private struct SubstitutePickerSheet: View {
    let target: ClubMemberItem
    let allMembers: [ClubMemberItem]
    let alreadyPresent: Set<Int>
    let onSelect: (ClubMemberItem) -> Void
    let onNoAvailable: () -> Void

    @Environment(\.dismiss) private var dismiss

    private var eligible: [ClubMemberItem] {
        allMembers.filter { $0.id != target.id && !alreadyPresent.contains($0.id) }
    }

    var body: some View {
        NavigationView {
            Group {
                if eligible.isEmpty {
                    VStack(spacing: 16) {
                        Image(systemName: "person.slash").font(.system(size: 48)).foregroundColor(.secondary)
                        Text("No available substitute").font(.headline).foregroundColor(.secondary)
                        Text("All other members are already marked present.")
                            .font(.caption).foregroundColor(.secondary).multilineTextAlignment(.center)
                    }
                    .padding()
                } else {
                    List(eligible) { member in
                        Button {
                            onSelect(member)
                        } label: {
                            HStack(spacing: 12) {
                                ZStack {
                                    Circle().fill(Color.orange.opacity(0.12)).frame(width: 40, height: 40)
                                    Text(String(member.name.prefix(1)).uppercased())
                                        .font(.headline).foregroundColor(.orange)
                                }
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(member.name).font(.subheadline).fontWeight(.semibold)
                                    Text(member.role).font(.caption).foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Pick Substitute for \(target.name)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { onNoAvailable(); dismiss() }
                }
            }
        }
    }
}

// MARK: - Mark Attendance Header
struct MarkAttendanceHeader: View {
    let eventId: String
    @Environment(\.dismiss) private var dismiss

    private var safeTop: CGFloat {
        UIApplication.shared
            .connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?
            .safeAreaInsets.top ?? 50
    }

    var body: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [Color.blue, Color.purple],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
            .frame(height: safeTop + 60)

            HStack {
                Button(action: { dismiss() }) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 20, weight: .semibold)).foregroundColor(.white)
                }
                Spacer()
                Text(eventId.isEmpty ? "Mark Club Attendance" : "Event: \(eventId)")
                    .font(.headline).foregroundColor(.white)
                Spacer()
                Image(systemName: "chevron.left").foregroundColor(.clear)
            }
            .padding(.horizontal)
            .padding(.top, safeTop + 10)
        }
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
        NavigationStack {
            MarkAttendanceView(eventId: "")
                .environmentObject(AttendanceNotificationStore())
        }
    }
}
