from fastapi import Depends, HTTPException, Header
from sqlalchemy.orm import Session
from database import get_db
import models
from typing import Optional

def get_current_user(x_user_id: Optional[int] = Header(None), db: Session = Depends(get_db)):
    """
    Mock function to get the current user.
    Always returns user with ID 1 for now if X-User-Id is missing.
    """
    if x_user_id is not None:
        user = db.query(models.User).filter(models.User.id == x_user_id).first()
        if user:
            return user
            
    user = db.query(models.User).filter(models.User.id == 1).first()
    if not user:
        # If user 1 doesn't exist, return a mock user object/dict
        return models.User(id=1, name="Mock User", role=models.UserRole.Admin)
    
    # Overriding role to Admin for mock development (ensures full access)
    user.role = models.UserRole.Admin
    return user

def require_admin(current_user: models.User = Depends(get_current_user)):
    if current_user.role != models.UserRole.Admin:
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

def require_authority(current_user: models.User = Depends(get_current_user)):
    allowed_roles = [
        models.UserRole.Admin,
        models.UserRole.President,
        models.UserRole.VicePresident,
        models.UserRole.Secretary,
        models.UserRole.Treasurer
    ]
    if current_user.role not in allowed_roles:
        raise HTTPException(status_code=403, detail="Authority access required")
    return current_user

def require_president(current_user: models.User = Depends(get_current_user)):
    allowed_roles = [
        models.UserRole.Admin,
        models.UserRole.President
    ]
    if current_user.role not in allowed_roles:
        raise HTTPException(status_code=403, detail="President access required")
    return current_user

def require_student(current_user: models.User = Depends(get_current_user)):
    if current_user.role != models.UserRole.Student:
        raise HTTPException(status_code=403, detail="Student access required")
    return current_user
