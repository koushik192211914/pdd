import SwiftUI

// MARK: - AI Recommendations View
struct AIRecommendationsView: View {
    @EnvironmentObject private var authManager: AuthManager
    
    @State private var isLoading = true
    @State private var recommendations: [AIRecommendationResponse] = []
    @State private var errorMessage: String?

    var body: some View {
        ScrollView(showsIndicators: false) {
            if isLoading {
                VStack(spacing: 16) {
                    ProgressView().scaleEffect(1.3)
                    Text("Loading AI Recommendations…")
                        .font(.subheadline).foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.top, 60)
            } else if let err = errorMessage {
                VStack(spacing: 12) {
                    Image(systemName: "exclamationmark.triangle.fill").font(.system(size: 40)).foregroundColor(.red)
                    Text("Failed to Load Data").font(.title3).fontWeight(.semibold)
                    Text(err).font(.caption).foregroundColor(.secondary).multilineTextAlignment(.center)
                }
                .padding(.top, 60).padding(.horizontal)
            } else {
                VStack(spacing: 14) {
                    HStack(spacing: 8) {
                        Image(systemName: "wand.and.stars").foregroundColor(.purple)
                        Text("AI Recommendations")
                            .font(.title3).bold()
                        Spacer()
                        Text("Updated Today")
                            .font(.caption).foregroundColor(.secondary)
                    }
                    .padding(.horizontal)
                    .padding(.top, 16)

                    if recommendations.isEmpty {
                        Text("No recommendations available.")
                            .font(.subheadline).foregroundColor(.secondary).padding(.top)
                    } else {
                        ForEach(recommendations) { rec in
                            RecommendationCardView(
                                icon: rec.icon,
                                color: rec.swiftColor,
                                title: rec.title,
                                content: rec.content
                            )
                        }
                    }
                }
                .padding(.bottom, 40)
            }
        }
        .background(Color(UIColor.systemGroupedBackground))
        .navigationTitle("AI Recommendations")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            await fetchData()
        }
    }
    
    @MainActor
    private func fetchData() async {
        guard let clubId = authManager.clubId else {
            isLoading = false
            errorMessage = "No club assigned."
            return
        }
        isLoading = true
        errorMessage = nil
        do {
            let res = try await AnalyticsService.shared.getAIRecommendations(clubId: clubId)
            self.recommendations = res.recommendations
        } catch {
            self.errorMessage = error.localizedDescription
        }
        isLoading = false
    }
}

// MARK: - Recommendation Card Component
private struct RecommendationCardView: View {
    let icon: String
    let color: Color
    let title: String
    let content: String

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(color.opacity(0.14))
                        .frame(width: 42, height: 42)
                    Image(systemName: icon)
                        .font(.system(size: 18))
                        .foregroundColor(color)
                }
                Text(title)
                    .font(.subheadline).fontWeight(.semibold)
                Spacer()
            }
            Text(content)
                .font(.caption)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
        .padding(.horizontal)
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
    NavigationStack {
        AIRecommendationsView()
    }

    }
}
