//
//  AnalyticsService.swift
//  CLUB ANALYTICSs
//
//  GET /analytics/club/health/{club_id}
//  GET /analytics/platform-summary
//  GET /analytics/club-rankings
//

import Foundation

final class AnalyticsService {
    static let shared = AnalyticsService()
    private init() {}

    func getClubHealth(clubId: Int) async throws -> ClubHealthResponse {
        return try await APIClient.shared.request("/analytics/club/health/\(clubId)")
    }

    func getLowEngagementMembers(clubId: Int) async throws -> [LowEngagementMember] {
        return try await APIClient.shared.request("/analytics/low-engagement/\(clubId)")
    }

    func getStudentEngagement(studentId: Int) async throws -> StudentEngagementResponse {
        return try await APIClient.shared.request("/analytics/student/\(studentId)")
    }

    /// Platform-wide summary for admin dashboard (delegates to AdminService)
    func fetchPlatformSummary() async throws -> PlatformSummaryResponse {
        return try await AdminService.shared.getPlatformSummary()
    }

    /// Fetch all clubs and their health scores to build a ranking list
    func fetchClubRankings() async throws -> [ClubRankingItem] {
        let clubs: [ClubResponse] = try await APIClient.shared.request("/clubs")
        var rankings: [ClubRankingItem] = []
        for club in clubs {
            if let health = try? await getClubHealth(clubId: club.id) {
                rankings.append(ClubRankingItem(
                    clubId: club.id,
                    clubName: club.name,
                    engagementScore: health.average_engagement
                ))
            }
        }
        return rankings.sorted { $0.engagementScore > $1.engagementScore }
    }

    /// Fetch low-engagement clubs (clubs whose health score is below threshold)
    func fetchLowEngagementClubs(threshold: Double = 65.0) async throws -> [ClubRankingItem] {
        let all = try await fetchClubRankings()
        return all.filter { $0.engagementScore < threshold }
    }

    func getPredictiveAnalytics(clubId: Int) async throws -> PredictiveAnalyticsResponse {
        return try await APIClient.shared.request("/analytics/predictive/\(clubId)")
    }

    func getAIRecommendations(clubId: Int) async throws -> AIRecommendationsListResponse {
        return try await APIClient.shared.request("/analytics/recommendations/\(clubId)")
    }

    /// Fetch platform health score
    func fetchPlatformHealth() async throws -> PlatformHealthResponse {
        return try await APIClient.shared.request("/analytics/overview")
    }

    /// Fetch historical engagement trend data
    func fetchEngagementTrend() async throws -> EngagementTrendResponse {
        return try await APIClient.shared.request("/analytics/engagement-trend")
    }

    /// Fetch platform-wide AI alerts
    func fetchAIAlerts() async throws -> AIAlertsResponse {
        return try await APIClient.shared.request("/analytics/alerts")
    }
}
