//
//  UserViewModel.swift
//  CLUB ANALYTICSs
//

import Foundation
import Combine

@MainActor
final class UserViewModel: ObservableObject {
    @Published var user: UserResponseModel?
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var successMessage: String?

    func loadMe() {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                user = try await UserService.shared.getMe()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func updateMe(name: String?, email: String?) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                let updated = try await UserService.shared.updateMe(name: name, email: email)
                user = updated
                // Keep AuthManager in sync
                AuthManager.shared.saveSession(user: updated)
                successMessage = "Profile updated."
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
