from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
import models
from models.announcement import Announcement
from schemas.announcements import AnnouncementCreate, AnnouncementResponse
from core.permissions import get_current_user

router = APIRouter(
    prefix="/announcements",
    tags=["Announcements"]
)

@router.get("/{club_id}", response_model=List[AnnouncementResponse])
def get_announcements(club_id: int, db: Session = Depends(get_db)):
    # Verify club exists
    club = db.query(models.Club).filter(models.Club.id == club_id).first()
    if not club:
        raise HTTPException(status_code=404, detail="Club not found")
        
    announcements = db.query(Announcement).filter(Announcement.club_id == club_id).order_by(Announcement.created_at.desc()).all()
    return announcements

@router.post("/", response_model=AnnouncementResponse, status_code=status.HTTP_201_CREATED)
def create_announcement(
    announcement: AnnouncementCreate, 
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    # Verify club exists
    club = db.query(models.Club).filter(models.Club.id == announcement.club_id).first()
    if not club:
        raise HTTPException(status_code=404, detail="Club not found")
        
    # Check if user has permission (must be a member of the club, ideally an authority, but we'll keep it simple for now or rely on frontend. Let's enforce authority role)
    allowed_roles = [models.UserRole.Admin, models.UserRole.President, models.UserRole.VicePresident, models.UserRole.Secretary]
    if current_user.role not in allowed_roles:
         raise HTTPException(status_code=403, detail="Not authorized to create announcements")

    new_announcement = Announcement(
        title=announcement.title,
        content=announcement.content,
        club_id=announcement.club_id,
        author_id=current_user.id
    )
    db.add(new_announcement)
    db.commit()
    db.refresh(new_announcement)
    return new_announcement

@router.delete("/{announcement_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_announcement(
    announcement_id: int, 
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    announcement = db.query(Announcement).filter(Announcement.id == announcement_id).first()
    if not announcement:
        raise HTTPException(status_code=404, detail="Announcement not found")
        
    # Check if user has permission (author or admin/president/vice_president/secretary)
    authority_roles = [models.UserRole.Admin, models.UserRole.President, models.UserRole.VicePresident, models.UserRole.Secretary]
    if announcement.author_id != current_user.id and current_user.role not in authority_roles:
         raise HTTPException(status_code=403, detail="Not authorized to delete this announcement")

    db.delete(announcement)
    db.commit()
    return None
