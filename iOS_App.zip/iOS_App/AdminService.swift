//
//  AdminService.swift
//  CLUB ANALYTICSs
//
//  GET /admin/users  |  POST /admin/promote/{id}  |  POST /admin/demote/{id}
//

import Foundation

final class AdminService {
    static let shared = AdminService()
    private init() {}

    func getAllUsers() async throws -> [AdminUserResponse] {
        return try await APIClient.shared.request("/admin/users")
    }

    func getPlatformSummary() async throws -> PlatformSummaryResponse {
        return try await APIClient.shared.request("/analytics/platform-summary")
    }

    func getDashboard() async throws -> DashboardResponse {
        return try await APIClient.shared.request("/analytics/dashboard")
    }

    func promoteUser(userId: Int, role: String, clubId: Int) async throws -> MessageResponse {
        let request = PromoteRequest(role: role, club_id: clubId)
        return try await APIClient.shared.request("/admin/promote/\(userId)", method: "POST", body: request)
    }

    func demoteUser(userId: Int) async throws -> MessageResponse {
        return try await APIClient.shared.request("/admin/demote/\(userId)", method: "POST")
    }

    func removeUser(userId: Int) async throws -> MessageResponse {
        return try await APIClient.shared.request("/members/remove/\(userId)", method: "DELETE")
    }

    func changeLeadership(userId: Int, newLeaderId: Int) async throws -> MessageResponse {
        let req = ChangeLeadershipRequest(new_leader_id: newLeaderId)
        return try await APIClient.shared.request("/admin/change-leadership/\(userId)", method: "POST", body: req)
    }
}

// MARK: - Event Attendance Service
final class EventAttendanceService {
    static let shared = EventAttendanceService()
    private init() {}

    func getEventParticipants(eventId: Int) async throws -> [EventParticipant] {
        return try await APIClient.shared.request("/registrations/event/\(eventId)/participants")
    }

    func getAvailableSubstitutes(eventId: Int, clubId: Int) async throws -> [EventParticipant] {
        return try await APIClient.shared.request("/registrations/event/\(eventId)/available-substitutes?club_id=\(clubId)")
    }

    func hasSubmittedAttendance(eventId: Int) async throws -> Bool {
        // Fetch existing attendance records; if > 0, attendance is locked
        struct MinimalRecord: Decodable { let id: Int }
        let records: [MinimalRecord] = try await APIClient.shared.request("/event-attendance/event/\(eventId)")
        return !records.isEmpty
    }

    func markAttendance(records: [EventAttendanceRequest]) async throws -> MessageResponse {
        return try await APIClient.shared.request("/event-attendance/mark", method: "POST", body: records)
    }

    func assignSubstitute(eventId: Int, originalStudentId: Int, substituteStudentId: Int) async throws {
        struct SubReq: Encodable {
            let event_id: Int
            let original_student_id: Int
            let substitute_student_id: Int
        }
        let req = SubReq(event_id: eventId, original_student_id: originalStudentId, substitute_student_id: substituteStudentId)
        let _: MessageResponse = try await APIClient.shared.request("/substitutions/assign", method: "POST", body: req)
    }
}
