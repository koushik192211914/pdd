import SwiftUI
import Combine

@MainActor
final class ClubReportsViewModel: ObservableObject {
    @Published var reports: [ReportResponse] = []
    @Published var suggestions: [String] = []
    @Published var isLoading = false
    @Published var errorMsg: String? = nil
    
    func load(clubId: Int) async {
        isLoading = true
        errorMsg = nil
        do {
            async let fetchedReports = ReportService.shared.getReports()
            async let fetchedSuggestions = ReportService.shared.getReportAnalysis(clubId: clubId)
            
            let (r, s) = try await (fetchedReports, fetchedSuggestions)
            
            // Sort by latest submitted
            let isoFormatter = ISO8601DateFormatter()
            isoFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            
            self.reports = r.filter { $0.club_id == clubId }.sorted { 
                let d1 = isoFormatter.date(from: $0.submitted_at) ?? Date()
                let d2 = isoFormatter.date(from: $1.submitted_at) ?? Date()
                return d1 > d2
            }
            self.suggestions = s
        } catch {
            self.errorMsg = error.localizedDescription
        }
        isLoading = false
    }
    
    func deleteReport(_ report: ReportResponse) async {
        do {
            try await ReportService.shared.deleteReport(id: report.id)
            self.reports.removeAll { $0.id == report.id }
        } catch {
            self.errorMsg = "Delete failed: \(error.localizedDescription)"
        }
    }
}

struct ClubReportsView: View {
    let clubId: Int
    let clubName: String
    let eventName: String?
    let role: ClubRole
    
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = ClubReportsViewModel()
    @State private var reportToEdit: ReportResponse? = nil
    @State private var showingEditSheet = false
    
    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }
    
    private var canManage: Bool { role == .admin || role == .secretary }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // ── Header ─────────────────────────────────────────────
                reportsHeader
                
                VStack(spacing: 24) {
                    // ── AI Writing Assistant ───────────────────────────
                    if !viewModel.suggestions.isEmpty {
                        aiAssistantSection
                    }
                    
                    // ── Reports List ──────────────────────────────────
                    if viewModel.isLoading {
                        ProgressView().scaleEffect(1.2).padding(.top, 40)
                    } else if let error = viewModel.errorMsg {
                        Text("⚠️ \(error)").foregroundColor(.red).padding().multilineTextAlignment(.center)
                    } else if viewModel.reports.isEmpty {
                        VStack(spacing: 12) {
                            Image(systemName: "doc.text.magnifyingglass").font(.system(size: 48)).foregroundColor(.secondary.opacity(0.5))
                            Text("No reports found for this club.").font(.headline).foregroundColor(.secondary)
                        }
                        .padding(.top, 60)
                    } else {
                        ForEach(viewModel.reports) { report in
                            ReportVisualCard(report: report, canManage: canManage) {
                                reportToEdit = report
                                showingEditSheet = true
                            } onDelete: {
                                Task { await viewModel.deleteReport(report) }
                            }
                        }
                    }
                }
                .padding(20)
                .padding(.bottom, 60)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .task {
            await viewModel.load(clubId: clubId)
        }
        .sheet(item: $reportToEdit) { report in
            NavigationStack {
                UploadReportView(existingReport: report)
            }
        }
        .onChange(of: showingEditSheet) { _, newValue in
             if !newValue {
                 Task { await viewModel.load(clubId: clubId) }
             }
        }
    }
    
    private var reportsHeader: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [.purple, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                .clipShape(RoundedCorner(radius: 30, corners: [.bottomLeft, .bottomRight]))
                .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 8)
                HStack(alignment: .center, spacing: 12) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 40, height: 40)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                        }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(clubName).font(.title3).bold().foregroundColor(.white)
                        Text(eventName ?? "Submitted Event & Meeting Reports")
                            .font(.caption).foregroundColor(.white.opacity(0.80)).lineLimit(1)
                    }
                    Spacer()
                }
                .padding(.horizontal, 18).padding(.bottom, 22)
            }
        }
        .frame(height: safeTop + 92)
    }
    
    private var aiAssistantSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("AI Writing Assistant", systemImage: "sparkles")
                    .font(.headline).foregroundColor(.purple)
                Spacer()
                Text("BETA").font(.caption2).fontWeight(.bold).padding(.horizontal, 6).padding(.vertical, 2).background(Color.purple.opacity(0.1)).cornerRadius(4)
            }
            
            VStack(alignment: .leading, spacing: 10) {
                ForEach(viewModel.suggestions, id: \.self) { suggestion in
                    HStack(alignment: .top, spacing: 8) {
                        Image(systemName: "lightbulb.fill").font(.caption).foregroundColor(.orange)
                        Text(suggestion).font(.footnote).foregroundColor(.secondary).lineLimit(2)
                    }
                }
            }
        }
        .padding(18)
        .background(
            ZStack {
                Color.white
                LinearGradient(colors: [.purple.opacity(0.05), .clear], startPoint: .topLeading, endPoint: .bottomTrailing)
            }
        )
        .cornerRadius(20)
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.purple.opacity(0.1), lineWidth: 1))
        .shadow(color: .purple.opacity(0.05), radius: 10, x: 0, y: 5)
    }
}

// MARK: - Rich Visual Card
private struct ReportVisualCard: View {
    let report: ReportResponse
    let canManage: Bool
    let onEdit: () -> Void
    let onDelete: () -> Void
    
    var imageUrl: URL? {
        guard let path = report.file_url, !path.isEmpty else { return nil }
        let base = "http://127.0.0.1:8000"
        return URL(string: path.hasPrefix("http") ? path : base + path)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Title & Badge
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(report.title)
                        .font(.title3).bold()
                        .foregroundColor(.primary)
                    Text(report.club_name ?? "Club Member")
                        .font(.subheadline).fontWeight(.medium)
                        .foregroundColor(.purple)
                }
                Spacer()
                Text(report.report_type)
                    .font(.caption2).fontWeight(.bold)
                    .padding(.horizontal, 10).padding(.vertical, 5)
                    .background(Color.blue.opacity(0.1))
                    .foregroundColor(.blue)
                    .clipShape(Capsule())
            }
            
            Divider().opacity(0.5)
            
            // Meta info
            HStack(spacing: 12) {
                HStack(spacing: 4) {
                    Image(systemName: "calendar").font(.caption2)
                    Text("Event: \(report.event_name ?? "Meeting")").font(.caption).fontWeight(.medium)
                }
                .foregroundColor(.secondary)
                
                Spacer()
                
                if canManage {
                    Menu {
                        Button(action: onEdit) {
                            Label("Edit Report", systemImage: "pencil")
                        }
                        Button(role: .destructive, action: onDelete) {
                            Label("Delete Report", systemImage: "trash")
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle.fill")
                            .font(.title3)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            // Description
            if let desc = report.description, !desc.isEmpty {
                Text(desc)
                    .font(.subheadline)
                    .foregroundColor(.primary.opacity(0.85))
                    .lineLimit(3)
                    .padding(.top, 4)
            }
            
            // Image Preview
            if let url = imageUrl {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        ProgressView().frame(height: 180).frame(maxWidth: .infinity)
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                            .frame(height: 200)
                            .frame(maxWidth: .infinity)
                            .clipped()
                            .cornerRadius(16)
                            .shadow(radius: 2)
                    case .failure:
                        VStack(spacing: 8) {
                            Image(systemName: "photo").font(.largeTitle).foregroundColor(.secondary)
                            Text("Image Unavailable").font(.caption).foregroundColor(.secondary)
                        }
                        .frame(height: 150).frame(maxWidth: .infinity)
                        .background(Color.secondary.opacity(0.1))
                        .cornerRadius(16)
                    @unknown default:
                        EmptyView()
                    }
                }
                .padding(.top, 8)
            }
        }
        .padding(20)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(24)
        .shadow(color: .black.opacity(0.06), radius: 10, x: 0, y: 5)
    }
}

