//
//  AnnouncementViewModel.swift
//  CLUB ANALYTICSs
//

import Foundation
import Combine

@MainActor
final class AnnouncementViewModel: ObservableObject {
    @Published var announcements: [AnnouncementResponse] = []
    @Published var isLoading = false
    @Published var isPublishing = false
    @Published var publishSuccess = false
    @Published var errorMessage: String?

    func load(clubId: Int) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                announcements = try await AnnouncementService.shared.getAnnouncements(clubId: clubId)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func publishAnnouncement(draft: AnnouncementDraft, authManager: AuthManager) async -> Bool {
        isPublishing = true
        errorMessage = nil
        publishSuccess = false
        
        do {
            if draft.audience == .allClubs {
                // Admin sending to All Clubs: Loop through all clubs
                let clubs = try await ClubService.shared.getClubs()
                if clubs.isEmpty { 
                    errorMessage = "No clubs found to post to."
                    isPublishing = false
                    return false 
                }
                
                var successCount = 0
                for c in clubs {
                    do {
                        _ = try await AnnouncementService.shared.postAnnouncement(
                            title: draft.title, 
                            content: draft.message, 
                            clubId: c.id,
                            priority: draft.priority.rawValue
                        )
                        successCount += 1
                    } catch {
                        print("❌ [AnnouncementViewModel] Failed to post to club \(c.id): \(error)")
                        // Continue to others
                    }
                }
                
                if successCount == 0 && !clubs.isEmpty {
                    errorMessage = "Failed to post to any clubs."
                    isPublishing = false
                    return false
                }
            } else if draft.audience == .specificClub {
                // Specific Club or President's club
                let cid: Int
                if let draftCid = Int(draft.club) {
                    cid = draftCid
                } else if let authCid = authManager.clubId {
                    cid = authCid
                } else {
                    errorMessage = "No club selected."
                    isPublishing = false
                    return false
                }
                
                _ = try await AnnouncementService.shared.postAnnouncement(
                    title: draft.title, content: draft.message, clubId: cid, priority: draft.priority.rawValue
                )
            } else {
                // Fallback to user's club
                guard let cid = authManager.clubId else {
                    errorMessage = "Club context missing."
                    isPublishing = false
                    return false
                }
                _ = try await AnnouncementService.shared.postAnnouncement(
                    title: draft.title, content: draft.message, clubId: cid, priority: draft.priority.rawValue
                )
            }
            
            await MainActor.run {
                publishSuccess = true
                isPublishing = false
            }
            return true
        } catch {
            await MainActor.run {
                errorMessage = error.localizedDescription
                isPublishing = false
            }
            return false
        }
    }
}
