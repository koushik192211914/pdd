//
//  JoinRequestViewModel.swift
//  CLUB ANALYTICSs
//

import Foundation
import Combine

@MainActor
final class JoinRequestViewModel: ObservableObject {
    @Published var pendingRequests: [JoinRequestResponse] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var successMessage: String?

    func loadPending(clubId: Int) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                pendingRequests = try await JoinRequestService.shared.getPendingRequests(clubId: clubId)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func sendRequest(clubId: Int) {
        guard let studentId = AuthManager.shared.userId else {
            errorMessage = "Not logged in."
            return
        }
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                let result = try await JoinRequestService.shared.sendRequest(studentId: studentId, clubId: clubId)
                successMessage = result.message
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func approve(requestId: Int, clubId: Int) {
        Task {
            isLoading = true
            defer { isLoading = false }
            do {
                _ = try await JoinRequestService.shared.approveRequest(id: requestId)
                loadPending(clubId: clubId)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func reject(requestId: Int, clubId: Int) {
        Task {
            isLoading = true
            defer { isLoading = false }
            do {
                _ = try await JoinRequestService.shared.rejectRequest(id: requestId)
                loadPending(clubId: clubId)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
