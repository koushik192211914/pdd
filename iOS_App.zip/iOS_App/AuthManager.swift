//
//  AuthManager.swift
//  CLUB ANALYTICSs
//
//  Manages authentication state across the app.
//  Persists userId, role, and name in UserDefaults.
//

import Foundation
import SwiftUI
import Combine

typealias User = UserResponseModel

final class AuthManager: ObservableObject {
    static let shared = AuthManager()

    // MARK: - Published State
    @Published var user: User? = nil {
        didSet {
            if let u = user {
                UserDefaults.standard.set(u.id, forKey: Keys.userId)
                UserDefaults.standard.set(u.role, forKey: Keys.role)
                UserDefaults.standard.set(u.name, forKey: Keys.name)
                UserDefaults.standard.set(u.email, forKey: Keys.email)
                if let cid = u.club_id {
                    UserDefaults.standard.set(cid, forKey: Keys.clubId)
                }
            } else {
                UserDefaults.standard.removeObject(forKey: Keys.userId)
                UserDefaults.standard.removeObject(forKey: Keys.role)
                UserDefaults.standard.removeObject(forKey: Keys.name)
                UserDefaults.standard.removeObject(forKey: Keys.email)
                UserDefaults.standard.removeObject(forKey: Keys.clubId)
            }
        }
    }

    var userId: Int?     { user?.id }
    var userRole: String { user?.role ?? "Student" }
    var userName: String { user?.name ?? "" }
    var userEmail: String{ user?.email ?? "" }
    var clubId: Int?     { user?.club_id }

    var isLoggedIn: Bool { user != nil }

    // MARK: - Keys
    private enum Keys {
        static let userId = "cs_userId"
        static let role   = "cs_role"
        static let name   = "cs_name"
        static let email  = "cs_email"
        static let clubId = "cs_clubId"
    }

    // MARK: - Init (restore from UserDefaults)
    private init() {
        if let storedId = UserDefaults.standard.object(forKey: Keys.userId) as? Int {
            let role  = UserDefaults.standard.string(forKey: Keys.role)  ?? "Student"
            let name  = UserDefaults.standard.string(forKey: Keys.name)  ?? ""
            let email = UserDefaults.standard.string(forKey: Keys.email) ?? ""
            let cId   = UserDefaults.standard.object(forKey: Keys.clubId) as? Int
            
            self.user = User(id: storedId, name: name, email: email, role: role, created_at: "", club_id: cId)
        } else {
            self.user = nil
        }
    }

    // MARK: - Session Actions
    @MainActor
    func saveSession(user: User) {
        self.user = user
    }

    @MainActor
    func logout() {
        self.user = nil
    }

    // MARK: - Role helpers
    var clubRole: ClubRole {
        switch userRole {
        case "Admin":         return .admin
        case "President":     return .president
        case "VicePresident": return .vicePresident
        case "Secretary":     return .secretary
        default:              return .student
        }
    }
}
