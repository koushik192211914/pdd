//
//  PageIndicator.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Custom pagination dots
//

import SwiftUI

struct PageIndicator: View {
    let totalPages: Int
    let currentPage: Int

    // Active dot colour
    private let activeColor  = Color(red: 0.58, green: 0.23, blue: 0.98)
    private let inactiveColor = Color(red: 0.85, green: 0.80, blue: 0.95)

    var body: some View {
        HStack(spacing: 8) {
            ForEach(0..<totalPages, id: \.self) { index in
                Capsule()
                    .fill(index == currentPage ? activeColor : inactiveColor)
                    .frame(
                        width: index == currentPage ? 24 : 8,
                        height: 8
                    )
                    .animation(
                        .spring(response: 0.35, dampingFraction: 0.70),
                        value: currentPage
                    )
            }
        }
    }
}

#Preview {
    PreviewWrapper {
    VStack(spacing: 20) {
        PageIndicator(totalPages: 4, currentPage: 0)
        PageIndicator(totalPages: 4, currentPage: 1)
        PageIndicator(totalPages: 4, currentPage: 3)
    }
    .padding()

    }
}
