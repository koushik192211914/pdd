import SwiftUI

// MARK: - Member Engagement List View  (live data + kick action for Presidents)
struct MemberEngagementListView: View {
    @EnvironmentObject private var authManager: AuthManager

    @State private var members: [ClubMemberItem] = []
    @State private var isLoading = true
    @State private var errorMessage: String?
    @State private var kickMessage: String?

    private var isPresident: Bool {
        authManager.clubRole == .president
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 12) {
                // Header
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Club Members")
                            .font(.title3).bold()
                        Text("\(members.count) members total")
                            .font(.caption).foregroundColor(.secondary)
                    }
                    Spacer()
                    Image(systemName: "person.2.fill")
                        .font(.title2).foregroundColor(.purple)
                }
                .padding(.horizontal)
                .padding(.top, 16)

                if let msg = kickMessage {
                    Text(msg)
                        .font(.caption).foregroundColor(msg.contains("removed") ? .green : .red)
                        .padding(.horizontal)
                }

                if isLoading {
                    ProgressView("Loading members…").padding(.top, 40)
                } else if let err = errorMessage {
                    Text(err).foregroundColor(.red).padding()
                } else if members.isEmpty {
                    VStack(spacing: 8) {
                        Image(systemName: "person.3").font(.system(size: 44)).foregroundColor(.secondary)
                        Text("No members yet.").foregroundColor(.secondary)
                    }.padding(.top, 40)
                } else {
                    // Column headers
                    HStack {
                        Text("Member")
                            .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        Text("Role")
                            .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                            .frame(width: 80, alignment: .center)
                        if isPresident {
                            Text("Action")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.secondary)
                                .frame(width: 60, alignment: .center)
                        }
                    }
                    .padding(.horizontal, 20)

                    ForEach(members) { member in
                        HStack(spacing: 14) {
                            // Avatar
                            ZStack {
                                Circle()
                                    .fill(Color.purple.opacity(0.12))
                                    .frame(width: 44, height: 44)
                                Text(String(member.name.prefix(1)).uppercased())
                                    .font(.subheadline).fontWeight(.semibold)
                                    .foregroundColor(.purple)
                            }

                            VStack(alignment: .leading, spacing: 2) {
                                Text(member.name).font(.subheadline).fontWeight(.semibold)
                                Text(member.email).font(.caption).foregroundColor(.secondary)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)

                            Text(member.role)
                                .font(.caption).fontWeight(.semibold)
                                .foregroundColor(.purple)
                                .frame(width: 80, alignment: .center)

                            if isPresident {
                                Button {
                                    Task { await kickMember(member) }
                                } label: {
                                    Text("Remove")
                                        .font(.caption).fontWeight(.bold)
                                        .foregroundColor(.white)
                                        .padding(.horizontal, 10).padding(.vertical, 6)
                                        .background(Color.red)
                                        .clipShape(Capsule())
                                }
                                .frame(width: 60)
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.vertical, 12)
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(14)
                        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
                        .padding(.horizontal)
                    }
                    .padding(.bottom, 40)
                }
            }
        }
        .background(Color(UIColor.systemGroupedBackground))
        .navigationTitle("Club Members")
        .navigationBarTitleDisplayMode(.inline)
        .task { await loadMembers() }
    }

    // MARK: - Data Loading
    private func loadMembers() async {
        guard let clubId = authManager.clubId else {
            errorMessage = "No club assigned."
            isLoading = false
            return
        }
        isLoading = true
        do {
            members = try await ClubService.shared.getMembers(clubId: clubId)
        } catch {
            errorMessage = "Failed to load members: \(error.localizedDescription)"
        }
        isLoading = false
    }

    private func kickMember(_ member: ClubMemberItem) async {
        guard let clubId = authManager.clubId else { return }
        do {
            try await ClubService.shared.removeMember(studentId: member.id, clubId: clubId)
            members.removeAll { $0.id == member.id }
            kickMessage = "\(member.name) removed successfully."
        } catch {
            kickMessage = "Failed to remove \(member.name)."
        }
        // Auto-clear message after 3 seconds
        try? await Task.sleep(nanoseconds: 3_000_000_000)
        kickMessage = nil
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
        NavigationStack {
            MemberEngagementListView()
                .environmentObject(AuthManager.shared)
        }
    }
}
