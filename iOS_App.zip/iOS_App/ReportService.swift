import Foundation
import UIKit

final class ReportService {
    static let shared = ReportService()
    private let baseURL = "http://127.0.0.1:8000/reports"
    
    // Upload a report with an optional image
    func uploadReport(
        title: String,
        eventId: Int,
        clubId: Int,
        reportType: String,
        description: String?,
        submittedBy: Int,
        image: UIImage?
    ) async throws -> ReportResponse {
         guard let url = URL(string: baseURL) else {
             throw URLError(.badURL)
         }
         
         var request = URLRequest(url: url)
         request.httpMethod = "POST"
         
         let boundary = UUID().uuidString
         request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
         
         var body = Data()
         
         // Helper to append text fields
         func appendTextField(named name: String, value: String) {
             body.append("--\(boundary)\r\n".data(using: .utf8)!)
             body.append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n".data(using: .utf8)!)
             body.append("\(value)\r\n".data(using: .utf8)!)
         }
         
         appendTextField(named: "title", value: title)
         appendTextField(named: "event_id", value: "\(eventId)")
         appendTextField(named: "club_id", value: "\(clubId)")
         appendTextField(named: "report_type", value: reportType)
         appendTextField(named: "submitted_by", value: "\(submittedBy)")
         
         if let desc = description, !desc.isEmpty {
             appendTextField(named: "description", value: desc)
         }
         
         // Append image if present
         if let image = image, let imageData = image.jpegData(compressionQuality: 0.8) {
             body.append("--\(boundary)\r\n".data(using: .utf8)!)
             body.append("Content-Disposition: form-data; name=\"file\"; filename=\"report_image.jpg\"\r\n".data(using: .utf8)!)
             body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
             body.append(imageData)
             body.append("\r\n".data(using: .utf8)!)
         }
         
         body.append("--\(boundary)--\r\n".data(using: .utf8)!)
         
         let (data, response) = try await URLSession.shared.upload(for: request, from: body)
         
         guard let httpResp = response as? HTTPURLResponse, (200...299).contains(httpResp.statusCode) else {
             print("Error: \(String(data: data, encoding: .utf8) ?? "Unknown")")
             throw URLError(.badServerResponse)
         }
         
         return try JSONDecoder().decode(ReportResponse.self, from: data)
    }
    
    // Fetch all reports
    func getReports() async throws -> [ReportResponse] {
         guard let url = URL(string: baseURL) else {
             throw URLError(.badURL)
         }
         let (data, response) = try await URLSession.shared.data(from: url)
         
         guard let httpResp = response as? HTTPURLResponse, (200...299).contains(httpResp.statusCode) else {
             throw URLError(.badServerResponse)
         }
         
         return try JSONDecoder().decode([ReportResponse].self, from: data)
    }
}
