//
//  OnboardingView.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – 4-screen onboarding flow (light theme)
//
//  KEY FIX: Pages are listed EXPLICITLY (not with ForEach) inside TabView
//  to prevent the SwiftUI bug that causes duplicate pages.
//

import SwiftUI

struct OnboardingView: View {

    // ── Page data ─────────────────────────────────────────────────────────
    private let pages: [OnboardingCardModel] = [
        OnboardingCardModel(
            id: 0,
            iconName: "brain.head.profile",
            title: "Welcome to ClubSphere AI",
            description: "Manage clubs, track engagement, and organize events intelligently using AI-powered analytics."
        ),
        OnboardingCardModel(
            id: 1,
            iconName: "chart.line.uptrend.xyaxis",
            title: "Track Engagement",
            description: "Monitor member participation, attendance rates, and engagement scores in real-time."
        ),
        OnboardingCardModel(
            id: 2,
            iconName: "cpu.fill",
            title: "AI Powered Insights",
            description: "Discover patterns in club activity and receive smart recommendations to improve participation."
        ),
        OnboardingCardModel(
            id: 3,
            iconName: "calendar.badge.clock",
            title: "Smart Event Analytics",
            description: "Plan better events with predictive analytics and automated attendance tracking."
        )
    ]

    @State private var currentPage: Int = 0
    @State private var goToLogin: Bool   = false

    private var isLastPage: Bool { currentPage == pages.count - 1 }

    // ── Background colour ─────────────────────────────────────────────────
    private let bgColor = Color(red: 0.97, green: 0.97, blue: 0.98)

    var body: some View {
        ZStack {
            bgColor.ignoresSafeArea()

            VStack(spacing: 0) {

                // ── Swipeable pages ──────────────────────────────────────
                // IMPORTANT: pages listed EXPLICITLY – never use ForEach here
                // because SwiftUI reuses cells incorrectly and duplicates them.
                TabView(selection: $currentPage) {
                    OnboardingCard(model: pages[0]).tag(0)
                    OnboardingCard(model: pages[1]).tag(1)
                    OnboardingCard(model: pages[2]).tag(2)
                    OnboardingCard(model: pages[3]).tag(3)
                }
                .tabViewStyle(.page(indexDisplayMode: .never))
                .animation(.easeInOut(duration: 0.35), value: currentPage)

                // ── Bottom section ──────────────────────────────────────
                bottomSection
            }
        }
        .navigationDestination(isPresented: $goToLogin) {
            LoginView()
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    // ── Bottom controls ───────────────────────────────────────────────────
    @ViewBuilder
    private var bottomSection: some View {
        VStack(spacing: 20) {

            // Pagination dots
            PageIndicator(totalPages: pages.count, currentPage: currentPage)

            Spacer().frame(height: 4)

            // Primary button (Next / Get Started)
            GradientButton(
                isLastPage ? "Get Started" : "Next",
                showChevron: !isLastPage
            ) {
                handlePrimary()
            }

            // Skip link (hidden on last page to avoid redundancy)
            if !isLastPage {
                Button {
                    goToLogin = true
                } label: {
                    Text("Skip")
                        .font(.system(size: 15, weight: .medium))
                        .foregroundColor(Color(red: 0.50, green: 0.50, blue: 0.55))
                }
                .padding(.top, 2)
            } else {
                // Keep height stable so layout doesn't jump
                Color.clear.frame(height: 20)
            }

            Spacer().frame(height: 24)
        }
        .padding(.bottom, 16)
    }

    // ── Action handlers ───────────────────────────────────────────────────
    private func handlePrimary() {
        if isLastPage {
            goToLogin = true
        } else {
            withAnimation(.easeInOut(duration: 0.35)) {
                currentPage += 1
            }
        }
    }
}

#Preview {
    PreviewWrapper {
    NavigationStack {
        OnboardingView()
    }
    .environmentObject(AttendanceNotificationStore())

    }
}
