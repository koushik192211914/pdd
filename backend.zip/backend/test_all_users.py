import sys
sys.path.append("/Users/sail/Desktop/CLUB ANALYTICSs/backend")

from database import SessionLocal
from models import User

def test():
    db = SessionLocal()
    users = db.query(User).all()
    for u in users:
        print(f"ID: {u.id}, Name: {u.name}, Email: {u.email}, Role: {u.role}")

test()
