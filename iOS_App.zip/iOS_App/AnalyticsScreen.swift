//
//  AnalyticsScreen.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Role-Based Analytics
//  • Admin    → Platform-wide analytics + club filter
//  • Authority → Club-level AI insights (existing design)
//  • Student  → Personal engagement analytics
//

import SwiftUI

// MARK: - Analytics Screen (role-aware entry point)
struct AnalyticsDashboardView: View {
    var role: ClubRole = .president
    @StateObject private var adminVM = AdminAnalyticsViewModel()

    var body: some View {
        switch role {
        case .admin:
            AdminAnalyticsView(role: role, viewModel: adminVM)
        case .student:
            StudentAnalyticsView(role: role)
        default:
            AuthorityAnalyticsView(role: role)  // President, VP, Secretary
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - ADMIN ANALYTICS VIEW
// ─────────────────────────────────────────────────────────────────
struct AdminAnalyticsView: View {
    let role: ClubRole
    @ObservedObject var viewModel: AdminAnalyticsViewModel
    @State private var showNotificationPanel = false
    @StateObject private var vm = NotificationViewModel()
    @EnvironmentObject private var authManager: AuthManager

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {
                adminHeader

                if viewModel.isLoading {
                    VStack(spacing: 16) {
                        ProgressView()
                            .scaleEffect(1.3)
                        Text("Loading Analytics…")
                            .font(.subheadline).foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 60)

                } else if let error = viewModel.errorMessage {
                    VStack(spacing: 12) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.system(size: 40)).foregroundColor(.red)
                        Text("Analytics Error")
                            .font(.title3).fontWeight(.semibold)
                        Text(error)
                            .font(.caption).foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 60)
                } else {
                    VStack(spacing: 28) {
                        // 1. Platform Health & Summary
                        AdminPlatformOverview(viewModel: viewModel)
                        
                        // 2. Engagement Trend (New)
                        AdminEngagementTrendSection(labels: viewModel.trendLabels, data: viewModel.trendData)
                        
                        // 3. Club Rankings
                        if !viewModel.rankings.isEmpty {
                            AdminClubRanking(rankings: viewModel.rankings)
                        } else {
                            // Show a small placeholder if rankings are truly empty but summary isn't
                            Text("No rankings available yet").font(.caption).foregroundColor(.secondary)
                        }
                        
                        // 4. AI Alerts (New)
                        if !viewModel.alerts.isEmpty {
                            AdminAIAlertsSection(alerts: viewModel.alerts)
                        }
                        
                        // 5. AI Annual Award (New Feature)
                        if let award = viewModel.annualAward {
                            AdminAnnualAwardSection(award: award, viewModel: viewModel)
                        }
                        
                        // 6. Low Engagement
                        if !viewModel.lowEngagementClubs.isEmpty {
                            AdminLowEngagementSection(clubs: viewModel.lowEngagementClubs)
                        }
                    }
                    .padding(.top, 20)
                    .padding(.bottom, 100)
                }
            }
        }
        .id(viewModel.lastUpdated)
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .task {
            await viewModel.fetchPlatformAnalytics()
        }
    }

    // MARK: Header
    private var adminHeader: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [Color.purple, Color.blue],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)

            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 16)
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Platform Analytics")
                            .font(.title2).bold().foregroundColor(.white)
                        Text("AI Insights Across All Clubs")
                            .font(.caption).fontWeight(.medium)
                            .foregroundColor(.white.opacity(0.75))
                    }
                    Spacer()
                    
                    Button(action: { 
                        Task { await viewModel.fetchPlatformAnalytics() }
                    }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 44, height: 44)
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 18, weight: .bold)).foregroundColor(.white)
                        }
                    }
                    .padding(.trailing, 8)

                    Button(action: { showNotificationPanel = true }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 44, height: 44)
                            Image(systemName: "bell.badge.fill")
                                .font(.system(size: 20)).foregroundColor(.white)
                        }
                    }
                    .sheet(isPresented: $showNotificationPanel) {
                        NavigationStack {
                            NotificationsView(role: role, userId: authManager.userId ?? 0, vm: vm)
                                .onAppear {
                                    if let uid = authManager.userId {
                                        vm.load(userId: uid, role: ClubRole.admin.rawValue)
                                    }
                                }
                        }
                    }
                }
                .padding(.horizontal, 18).padding(.bottom, 24)
            }
        }
        .frame(height: safeTop + 110)
    }
}

// MARK: Admin Section 1 — Platform Overview
private struct AdminPlatformOverview: View {
    @ObservedObject var viewModel: AdminAnalyticsViewModel

    var body: some View {
        VStack(spacing: 20) {
            // Platform Health Score (Main AI Metric)
            VStack(spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Platform Health")
                            .font(.subheadline).fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        HStack(alignment: .firstTextBaseline, spacing: 4) {
                            Text("\(String(format: "%.1f", viewModel.healthScore))")
                                .font(.system(size: 44, weight: .bold))
                            Text("/10")
                                .font(.title3).fontWeight(.medium).foregroundColor(.secondary)
                        }
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 4) {
                        HStack(spacing: 4) {
                            Image(systemName: "arrow.up.right")
                            Text(viewModel.improvement)
                        }
                        .font(.caption).bold()
                        .foregroundColor(.green)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.green.opacity(0.1))
                        .cornerRadius(8)
                        
                        Text("Overall performance")
                            .font(.caption2).foregroundColor(.secondary)
                    }
                }
                
                // Progress Bar
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.gray.opacity(0.1)).frame(height: 8)
                        Capsule()
                            .fill(LinearGradient(colors: [.purple, .blue], startPoint: .leading, endPoint: .trailing))
                            .frame(width: geo.size.width * (viewModel.healthScore / 10.0), height: 8)
                    }
                }
                .frame(height: 8)
            }
            .padding(20)
            .background(Color.white)
            .cornerRadius(24)
            .shadow(color: Color.black.opacity(0.04), radius: 10, x: 0, y: 4)
            .padding(.horizontal)

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 14),
                                GridItem(.flexible(), spacing: 14)], spacing: 14) {
                AdminStatCard(icon: "building.2.fill",  title: "Total Clubs",
                               value: "\(viewModel.totalClubs)",  color: .purple)
                AdminStatCard(icon: "person.3.fill",    title: "Total Members",
                               value: "\(viewModel.totalMembers)", color: .blue)
                AdminStatCard(icon: "calendar.badge.plus", title: "Active Events",
                               value: "\(viewModel.totalEvents)",  color: .orange)
                AdminStatCard(icon: "chart.line.uptrend.xyaxis", title: "Avg Engagement",
                               value: "\(Int(viewModel.avgEngagement))%", color: .green)
            }
            .padding(.horizontal)
        }
    }
}

// MARK: - TREND SECTION
struct AdminEngagementTrendSection: View {
    let labels: [String]
    let data: [Int]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Engagement Trend")
                .font(.headline).padding(.horizontal)
            
            VStack(alignment: .leading, spacing: 20) {
                HStack(alignment: .bottom, spacing: 12) {
                    if data.isEmpty {
                        Text("No trend data available").font(.caption).foregroundColor(.secondary)
                    } else {
                        ForEach(0..<data.count, id: \.self) { i in
                            VStack(spacing: 8) {
                                ZStack(alignment: .bottom) {
                                    Capsule().fill(Color.gray.opacity(0.05)).frame(width: 30, height: 120)
                                    Capsule()
                                        .fill(LinearGradient(colors: [.purple.opacity(0.8), .purple], startPoint: .top, endPoint: .bottom))
                                        .frame(width: 30, height: CGFloat(data[i]) * 1.2)
                                }
                                Text(labels.indices.contains(i) ? labels[i] : "")
                                    .font(.caption2).foregroundColor(.secondary)
                            }
                        }
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
            }
            .padding(20)
            .background(Color.white)
            .cornerRadius(24)
            .shadow(color: Color.black.opacity(0.04), radius: 10, x: 0, y: 4)
            .padding(.horizontal)
        }
    }
}

// MARK: - ALERTS SECTION
struct AdminAIAlertsSection: View {
    let alerts: [AIAlert]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("AI Analytics Alerts")
                .font(.headline).padding(.horizontal)
            
            VStack(spacing: 12) {
                ForEach(alerts) { alert in
                    HStack(spacing: 16) {
                        ZStack {
                            Circle().fill(alert.type == "warning" ? Color.orange.opacity(0.1) : Color.green.opacity(0.1))
                                .frame(width: 40, height: 40)
                            Image(systemName: alert.type == "warning" ? "exclamationmark.triangle.fill" : "sparkles")
                                .foregroundColor(alert.type == "warning" ? .orange : .green)
                        }
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text(alert.title).font(.subheadline).fontWeight(.bold)
                            Text(alert.message).font(.caption).foregroundColor(.secondary)
                        }
                        Spacer()
                    }
                    .padding(16)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(16)
                }
            }
            .padding(.horizontal)
        }
    }
}

// MARK: - ANNUAL AWARD SECTION
struct AdminAnnualAwardSection: View {
    let award: AnnualAwardResponse
    @ObservedObject var viewModel: AdminAnalyticsViewModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("AI Annual Award")
                .font(.headline).padding(.horizontal)
                
            VStack(spacing: 20) {
                // Badge Image & Winner Designation
                ZStack {
                    Circle()
                        .fill(LinearGradient(colors: [.yellow.opacity(0.3), .orange.opacity(0.1)], 
                                           startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 140, height: 140)
                    
                    Image(systemName: "award.circle.fill")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 85, height: 85)
                        .foregroundStyle(
                            LinearGradient(colors: [.yellow, .orange], 
                                         startPoint: .topLeading, endPoint: .bottomTrailing)
                        )
                        .shadow(color: .orange.opacity(0.4), radius: 10, x: 0, y: 5)
                }
                .padding(.top, 10)
                
                VStack(spacing: 12) {
                    Text(award.club_name)
                        .font(.title2).bold()
                        .multilineTextAlignment(.center)
                        .foregroundColor(.primary)
                    
                    Text("PLATFORM WINNER")
                        .font(.caption).fontWeight(.black)
                        .foregroundColor(.white)
                        .padding(.horizontal, 12).padding(.vertical, 4)
                        .background(Color.orange.cornerRadius(8))
                    
                    Text(award.message)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 24)
                    
                    HStack(spacing: 30) {
                        VStack(spacing: 4) {
                            Text("\(Int(award.engagement_score))%")
                                .font(.headline).foregroundColor(.primary)
                            Text("Overall Score").font(.caption2).foregroundColor(.secondary)
                        }
                        
                        Divider().frame(height: 30)
                        
                        VStack(spacing: 4) {
                            Text("Year 2026")
                                .font(.headline).foregroundColor(.orange)
                            Text("Academic Period").font(.caption2).foregroundColor(.secondary)
                        }
                    }
                    .padding(.top, 10)
                    
                    // --- PUBLISH BUTTON ---
                    if award.is_published {
                        HStack {
                            Image(systemName: "checkmark.seal.fill")
                            Text("Award Published")
                        }
                        .font(.subheadline).bold()
                        .foregroundColor(.green)
                        .padding(.top, 16)
                    } else {
                        Button(action: {
                            Task {
                                await viewModel.publishAward()
                            }
                        }) {
                            HStack {
                                if viewModel.isLoading {
                                    ProgressView().tint(.white)
                                } else {
                                    Image(systemName: "paperplane.fill")
                                    Text("Publish to Club")
                                }
                            }
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(
                                LinearGradient(colors: [.orange, .red], startPoint: .leading, endPoint: .trailing)
                            )
                            .cornerRadius(12)
                            .shadow(color: .orange.opacity(0.3), radius: 5, x: 0, y: 3)
                        }
                        .disabled(viewModel.isLoading)
                        .padding(.horizontal, 24)
                        .padding(.top, 20)
                    }
                }
            }
            .padding(.vertical, 35)
            .frame(maxWidth: .infinity)
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(Color(UIColor.secondarySystemGroupedBackground))
                    .shadow(color: Color.black.opacity(0.06), radius: 15, x: 0, y: 8)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 24)
                    .stroke(LinearGradient(colors: [.yellow.opacity(0.5), .clear], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 2)
            )
            .padding(.horizontal)
        }
    }
}

private struct AdminStatCard: View {
    let icon: String; let title: String; let value: String; let color: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(color.opacity(0.12))
                    .frame(width: 40, height: 40)
                Image(systemName: icon).font(.system(size: 18)).foregroundColor(color)
            }
            Text(value).font(.title2).bold()
            Text(title).font(.caption).foregroundColor(.secondary).lineLimit(2)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

// MARK: Admin Section 2 — Club Performance Ranking
private struct AdminClubRanking: View {
    let rankings: [ClubRankingItem]

    // Cycle through a palette of accent colours
    private let palette: [Color] = [.purple, .blue, .green, .orange, .teal, .indigo, .pink]
    private func color(for index: Int) -> Color { palette[index % palette.count] }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Club Performance Ranking")
                    .font(.title3).bold()
                Spacer()
                Text("By Engagement").font(.caption).foregroundColor(.secondary)
                    .padding(.horizontal, 10).padding(.vertical, 4)
                    .background(Color.purple.opacity(0.09)).clipShape(Capsule())
            }
            .padding(.horizontal)

            if rankings.isEmpty {
                Text("No ranking data available")
                    .font(.subheadline).foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
            } else {
                VStack(spacing: 10) {
                    ForEach(Array(rankings.enumerated()), id: \.element.id) { idx, item in
                        let accent = color(for: idx)
                        HStack(spacing: 14) {
                            ZStack {
                                Circle()
                                    .fill(idx == 0
                                          ? LinearGradient(colors: [.purple, .blue],
                                                           startPoint: .topLeading, endPoint: .bottomTrailing)
                                          : LinearGradient(colors: [Color(UIColor.tertiarySystemGroupedBackground),
                                                                    Color(UIColor.tertiarySystemGroupedBackground)],
                                                           startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .frame(width: 32, height: 32)
                                Text("\(idx + 1)")
                                    .font(.system(size: 13, weight: .bold))
                                    .foregroundColor(idx == 0 ? .white : .secondary)
                            }
                            Text(item.clubName)
                                .font(.subheadline).fontWeight(.semibold).lineLimit(1)
                            Spacer()
                            HStack(spacing: 8) {
                                GeometryReader { geo in
                                    ZStack(alignment: .leading) {
                                        Capsule().fill(Color(UIColor.tertiarySystemGroupedBackground))
                                            .frame(height: 6)
                                        Capsule()
                                            .fill(LinearGradient(colors: [accent, accent.opacity(0.6)],
                                                                 startPoint: .leading, endPoint: .trailing))
                                            .frame(width: geo.size.width * CGFloat(min(item.engagementScore, 100)) / 100,
                                                   height: 6)
                                    }
                                }
                                .frame(width: 70, height: 6)
                                Text("\(Int(item.engagementScore))%")
                                    .font(.caption).fontWeight(.bold).foregroundColor(accent)
                                    .frame(width: 34, alignment: .trailing)
                            }
                        }
                        .padding(14)
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(14)
                        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

// MARK: Admin Section 3 — Low Engagement Clubs
private struct AdminLowEngagementSection: View {
    let clubs: [ClubRankingItem]

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Low Engagement Clubs")
                    .font(.title3).bold()
                Spacer()
                Label("Needs Attention", systemImage: "exclamationmark.triangle.fill")
                    .font(.caption2).fontWeight(.semibold)
                    .foregroundColor(.orange)
                    .padding(.horizontal, 10).padding(.vertical, 4)
                    .background(Color.orange.opacity(0.10)).clipShape(Capsule())
            }
            .padding(.horizontal)

            if clubs.isEmpty {
                HStack {
                    Spacer()
                    VStack(spacing: 8) {
                        Image(systemName: "checkmark.circle.fill").font(.title2).foregroundColor(.green)
                        Text("No low engagement clubs")
                            .font(.caption).foregroundColor(.secondary)
                    }
                    .padding(20)
                    Spacer()
                }
                .background(Color(UIColor.secondarySystemGroupedBackground))
                .cornerRadius(14)
                .padding(.horizontal)
            } else {
                VStack(spacing: 10) {
                    ForEach(clubs) { item in
                        HStack(spacing: 14) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10).fill(Color.orange.opacity(0.12))
                                    .frame(width: 40, height: 40)
                                Image(systemName: "exclamationmark.circle.fill")
                                    .font(.system(size: 18)).foregroundColor(.orange)
                            }
                            VStack(alignment: .leading, spacing: 3) {
                                Text(item.clubName).font(.subheadline).fontWeight(.semibold)
                                Text("\(Int(item.engagementScore))% engagement")
                                    .font(.caption).foregroundColor(.orange)
                            }
                            Spacer()
                            GeometryReader { geo in
                                ZStack(alignment: .leading) {
                                    Capsule().fill(Color(UIColor.tertiarySystemGroupedBackground))
                                        .frame(height: 6)
                                    Capsule().fill(Color.orange)
                                        .frame(width: geo.size.width * CGFloat(min(item.engagementScore, 100)) / 100,
                                               height: 6)
                                }
                            }
                            .frame(width: 60, height: 6)
                        }
                        .padding(14)
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(14)
                        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

// Note: AdminEventPerformance and AdminAIRecommendations removed — their data
// must come from API endpoints not yet available in AnalyticsService.
// Add them back once backend exposes /analytics/events and /analytics/recommendations.

// ─────────────────────────────────────────────────────────────────
// MARK: - AUTHORITY ANALYTICS VIEW (President / VP / Secretary)
// Preserves the existing design exactly; no visual changes.
// ─────────────────────────────────────────────────────────────────
struct AuthorityAnalyticsView: View {
    let role: ClubRole
    @State private var showNotificationPanel = false
    @StateObject private var vm = NotificationViewModel()
    @EnvironmentObject private var authManager: AuthManager
    @StateObject private var viewModel = PresidentHomeViewModel()

    private var safeTop: CGFloat {
        UIApplication.shared
            .connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?
            .safeAreaInsets.top ?? 50
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {
                authorityHeader
                if viewModel.isLoading {
                    VStack(spacing: 16) {
                        ProgressView().scaleEffect(1.3)
                        Text("Loading AI Insights…")
                            .font(.subheadline).foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 60)
                } else {
                    VStack(spacing: 28) {
                        if viewModel.health?.has_award == true {
                            AwardRecognitionCard()
                                .transition(.move(edge: .top).combined(with: .opacity))
                        }
                        
                        HealthScoreCard(health: viewModel.health)
                        ClubStatsGrid(health: viewModel.health, platformRank: viewModel.platformRank)
                        EngagementTrendsCard(predictive: viewModel.predictive)
                        AIAlertsSection(viewModel: viewModel)
                        AnalyticsDataGrid()
                        AIInsightsOptions()
                    }
                    .padding(.top, 24)
                    .padding(.bottom, 100)
                }
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .task {
            if let clubId = authManager.clubId {
                await viewModel.fetchData(clubId: clubId)
            }
        }
    }

    private var authorityHeader: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [Color.purple, Color.blue],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)
            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 16)
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("AI Insights")
                            .font(.title2).bold().foregroundColor(.white)
                        Text("Powered by machine learning")
                            .font(.caption).fontWeight(.medium)
                            .foregroundColor(.white.opacity(0.75))
                    }
                    Button(action: { showNotificationPanel = true }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 44, height: 44)
                            Image(systemName: "bell.badge.fill")
                                .font(.system(size: 20)).foregroundColor(.white)
                        }
                    }
                    .sheet(isPresented: $showNotificationPanel) {
                        NavigationStack {
                            NotificationsView(role: role, userId: authManager.userId ?? 0, vm: vm)
                                .onAppear {
                                    if let uid = authManager.userId {
                                        vm.load(userId: uid, role: role.rawValue)
                                    }
                                }
                        }
                    }
                }
                .padding(.horizontal, 18).padding(.bottom, 24)
            }
        }
        .frame(height: safeTop + 110)
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - STUDENT ANALYTICS VIEW
// ─────────────────────────────────────────────────────────────────
struct StudentAnalyticsView: View {
    let role: ClubRole
    @State private var showNotificationPanel = false
    @StateObject private var vm = NotificationViewModel()
    @EnvironmentObject private var authManager: AuthManager

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    @StateObject private var viewModel = StudentHomeViewModel()

    private var participationScore: Int { viewModel.engagement?.engagement_score ?? 0 }
    private var eventsAttended: Int     { viewModel.engagement?.events_attended ?? 0 }
    private var clubsJoined: Int        { viewModel.engagement?.clubs_joined ?? 0 }
    private var attendanceRate: Int {
        guard let eng = viewModel.engagement else { return 0 }
        // Base it on events_attended to roughly map 0-100% via a heuristic (assuming 10 events is 100%)
        // or just use engagement score if it maps better. We'll use score here.
        return eng.engagement_score
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {
                // ── Header ────────────────────────────────────────────────
                studentHeader

                VStack(spacing: 28) {
                    // 1. Personal score dial
                    studentScoreCard

                    // 2. Quick stats grid
                    studentStatsGrid

                }
                .padding(.top, 24)
                .padding(.bottom, 100)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
        .task {
            if let uid = authManager.userId {
                await viewModel.fetchData(studentId: uid, clubId: authManager.clubId)
            }
        }
    }

    // MARK: Header
    private var studentHeader: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [Color.purple, Color.blue],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .clipShape(RoundedCorner(radius: 32, corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)
            VStack(alignment: .leading, spacing: 0) {
                Color.clear.frame(height: safeTop + 16)
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("My Analytics")
                            .font(.title2).bold().foregroundColor(.white)
                        Text("Personal engagement insights")
                            .font(.caption).fontWeight(.medium)
                            .foregroundColor(.white.opacity(0.75))
                    }
                    Spacer()
                    Button(action: { showNotificationPanel = true }) {
                        ZStack {
                            Circle().fill(Color.white.opacity(0.20)).frame(width: 44, height: 44)
                            Image(systemName: "bell.badge.fill")
                                .font(.system(size: 20)).foregroundColor(.white)
                        }
                    }
                    .sheet(isPresented: $showNotificationPanel) {
                        NavigationStack {
                            NotificationsView(role: role, userId: authManager.userId ?? 0, vm: vm)
                                .onAppear {
                                    if let uid = authManager.userId {
                                        vm.load(userId: uid, role: ClubRole.student.rawValue)
                                    }
                                }
                        }
                    }
                }
                .padding(.horizontal, 18).padding(.bottom, 24)
            }
        }
        .frame(height: safeTop + 110)
    }

    // MARK: Participation score card
    private var studentScoreCard: some View {
        VStack(spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Participation Score")
                        .font(.headline).fontWeight(.semibold)
                    Text("+5 points this month")
                        .font(.caption).foregroundColor(.green)
                        .padding(.horizontal, 8).padding(.vertical, 3)
                        .background(Color.green.opacity(0.10)).clipShape(Capsule())
                }
                Spacer()
                // Score dial
                ZStack {
                    Circle()
                        .trim(from: 0, to: CGFloat(participationScore) / 100)
                        .stroke(
                            LinearGradient(colors: [.purple, .blue],
                                           startPoint: .topLeading, endPoint: .bottomTrailing),
                            style: StrokeStyle(lineWidth: 8, lineCap: .round)
                        )
                        .rotationEffect(.degrees(-90))
                        .frame(width: 70, height: 70)
                    VStack(spacing: 0) {
                        Text("\(participationScore)")
                            .font(.system(size: 18, weight: .bold)).foregroundColor(.primary)
                        Text("/ 100").font(.caption2).foregroundColor(.secondary)
                    }
                }
            }

            // Score label
            HStack(spacing: 6) {
                Image(systemName: "sparkles").font(.caption).foregroundColor(.purple)
                Text("You're performing above average for your club!")
                    .font(.caption).foregroundColor(.secondary)
            }
            .padding(10)
            .background(Color.purple.opacity(0.07))
            .cornerRadius(10)
        }
        .padding(18)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
        .padding(.horizontal)
    }

    // MARK: Quick stats 2×2 grid
    private var studentStatsGrid: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Your Activity").font(.title3).bold().padding(.horizontal)

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 14),
                                GridItem(.flexible(), spacing: 14)], spacing: 14) {
                StudentStatCard(icon: "calendar.badge.checkmark", color: .purple,
                                value: "\(eventsAttended)", label: "Events Attended")
                StudentStatCard(icon: "checkmark.circle.fill", color: .green,
                                value: "\(attendanceRate)%", label: "Attendance Rate")
                StudentStatCard(icon: "building.2.fill", color: .blue,
                                value: "\(clubsJoined)", label: "Clubs Joined")
                StudentStatCard(icon: "star.fill", color: .orange,
                                value: "Top 15%", label: "Class Ranking")
            }
            .padding(.horizontal)
        }
    }



    // MARK: AI tips
    private var studentAITips: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Image(systemName: "wand.and.stars").foregroundColor(.purple)
                Text("AI Tips For You").font(.title3).bold()
            }
            .padding(.horizontal)

            VStack(spacing: 10) {
                StudentAITip(icon: "calendar.badge.plus", color: .orange,
                             text: "You've missed 2 events this month. Attending Thursday sessions boosts your score the most.")
                StudentAITip(icon: "person.2.fill", color: .blue,
                             text: "Joining one more club could improve your engagement score by up to 12 points.")
                StudentAITip(icon: "trophy.fill", color: .purple,
                             text: "Your attendance rate puts you in the top 15% of your year group. Keep it up!")
            }
            .padding(.horizontal)
        }
    }
}

private struct StudentStatCard: View {
    let icon: String; let color: Color; let value: String; let label: String
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(color.opacity(0.12)).frame(width: 40, height: 40)
                Image(systemName: icon).font(.system(size: 18)).foregroundColor(color)
            }
            Text(value).font(.title2).bold()
            Text(label).font(.caption).foregroundColor(.secondary).lineLimit(2)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

private struct StudentAITip: View {
    let icon: String; let color: Color; let text: String
    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(color.opacity(0.12)).frame(width: 40, height: 40)
                Image(systemName: icon).font(.system(size: 16)).foregroundColor(color)
            }
            Text(text).font(.subheadline).foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// ─────────────────────────────────────────────────────────────────
// MARK: - Preserved authority analytics sub-components
// (Identical to the original file — kept internal so they compile
//  without needing 'private' which would break cross-file usage.)
// ─────────────────────────────────────────────────────────────────

// MARK: - 1. Overall Club Health Score Card
// MARK: - AWARD RECOGNITION (New)
struct AwardRecognitionCard: View {
    var body: some View {
        VStack(spacing: 16) {
            HStack(spacing: 16) {
                ZStack {
                    Circle()
                        .fill(LinearGradient(colors: [.yellow, .orange], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 54, height: 54)
                    Image(systemName: "rosette")
                        .font(.system(size: 26))
                        .foregroundColor(.white)
                        .shadow(radius: 2)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("AI Excellence Award")
                        .font(.headline).bold()
                        .foregroundColor(.primary)
                    Text("Top Performance Recognized")
                        .font(.caption).fontWeight(.semibold)
                        .foregroundColor(.orange)
                }
                Spacer()
            }
            
            Text("Based on AI analytics, your club has been recognized as the platform leader in engagement this year. Keep up the amazing work!")
                .font(.caption)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            
            HStack {
                Spacer()
                Text("CONGRATULATIONS!")
                    .font(.system(size: 10, weight: .black))
                    .foregroundColor(.white)
                    .padding(.horizontal, 10).padding(.vertical, 4)
                    .background(Color.orange.cornerRadius(6))
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 24)
                .fill(Color(UIColor.secondarySystemGroupedBackground))
                .shadow(color: Color.orange.opacity(0.12), radius: 15, x: 0, y: 8)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 24)
                .stroke(LinearGradient(colors: [.yellow.opacity(0.6), .clear], 
                                     startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 2)
        )
        .padding(.horizontal)
    }
}

struct HealthScoreCard: View {
    let health: ClubHealthResponse?

    var healthScore: Double {
        health?.club_health_score ?? 0.0
    }

    var body: some View {
        VStack(spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Overall Club Health Score")
                        .font(.headline).fontWeight(.semibold)
                    Text("+0.5 from last month")
                        .font(.caption).foregroundColor(.green)
                        .padding(.horizontal, 8).padding(.vertical, 3)
                        .background(Color.green.opacity(0.10)).clipShape(Capsule())
                }
                Spacer()
                ZStack {
                    Circle()
                        .trim(from: 0, to: CGFloat(healthScore) / 10.0)
                        .stroke(
                            LinearGradient(colors: [.purple, .blue],
                                           startPoint: .topLeading, endPoint: .bottomTrailing),
                            style: StrokeStyle(lineWidth: 8, lineCap: .round)
                        )
                        .rotationEffect(.degrees(-90))
                        .frame(width: 70, height: 70)
                    VStack(spacing: 0) {
                        Text(String(format: "%.1f", healthScore)).font(.system(size: 18, weight: .bold)).foregroundColor(.primary)
                        Text("/ 10").font(.caption2).foregroundColor(.secondary)
                    }
                }
            }
        }
        .padding(18)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
        .padding(.horizontal)
    }
}

// MARK: - Club Stats Grid for President
struct ClubStatsGrid: View {
    let health: ClubHealthResponse?
    let platformRank: Int?
    
    var body: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 14), 
                            GridItem(.flexible(), spacing: 14)], spacing: 14) {
            
            AnalyticsDataCardSmall(icon: "person.3.fill", title: "Members", 
                                   value: "\(health?.total_members ?? 0)", color: .blue)
            
            AnalyticsDataCardSmall(icon: "calendar", title: "Total Events", 
                                   value: "\(health?.total_events ?? 0)", color: .orange)
            
            AnalyticsDataCardSmall(icon: "chart.bar.fill", title: "Avg Engagement", 
                                   value: "\(Int(health?.average_engagement ?? 0))%", color: .green)
            
            AnalyticsDataCardSmall(icon: "star.fill", title: "Platform Rank", 
                                   value: platformRank != nil ? "#\(platformRank!)" : "--", color: .purple)
        }
        .padding(.horizontal)
    }
}

struct AnalyticsDataCardSmall: View {
    let icon: String; let title: String; let value: String; let color: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: icon).foregroundColor(color)
                Text(title).font(.caption).foregroundColor(.secondary)
            }
            Text(value).font(.headline).bold()
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.03), radius: 4, x: 0, y: 2)
    }
}

// MARK: - 2. Engagement Trends (bar chart)
struct EngagementTrendsCard: View {
    let predictive: PredictiveAnalyticsResponse?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Engagement Trends").font(.title3).bold()
                Spacer()
                Text("4-Week Forecast")
                    .font(.caption).fontWeight(.semibold).foregroundColor(.purple)
                    .padding(.horizontal, 10).padding(.vertical, 4)
                    .background(Color.purple.opacity(0.10)).clipShape(Capsule())
            }
            
            if let trendData = predictive?.future_trend, !trendData.isEmpty {
                HStack(alignment: .bottom, spacing: 10) {
                    ForEach(trendData) { item in
                        VStack(spacing: 6) {
                            RoundedRectangle(cornerRadius: 6)
                                .fill(item.trend_value > 0.90
                                      ? LinearGradient(colors: [.purple, .blue], startPoint: .top, endPoint: .bottom)
                                      : LinearGradient(colors: [Color.purple.opacity(0.35), Color.blue.opacity(0.35)],
                                                       startPoint: .top, endPoint: .bottom))
                                .frame(height: CGFloat(item.trend_value) * 100)
                            Text(item.week_label).font(.caption2).foregroundColor(.secondary)
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .frame(height: 120)
                Text("Projected engagement based on upcoming events.")
                    .font(.caption).foregroundColor(.secondary).padding(.top, 2)
            } else {
                VStack {
                    Spacer()
                    Text("No trend data available yet.")
                        .font(.caption).foregroundColor(.secondary)
                    Spacer()
                }
                .frame(maxWidth: .infinity)
                .frame(height: 120)
            }
        }
        .padding(18)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 2)
        .padding(.horizontal)
    }
}

// MARK: - 3. AI Alerts & Predictions
struct AIAlertsSection: View {
    @ObservedObject var viewModel: PresidentHomeViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("AI Alerts & Predictions").font(.title3).bold().padding(.horizontal)
            
            // 1. Always show the inactive members warning from predictive data (if any)
            if viewModel.lowEngagementCount > 0 {
                AIAlertCard(icon: "person.fill.xmark", iconColor: .red,
                            title: "Inactive Members",
                            detail: "\(viewModel.lowEngagementCount) members haven't attended events recently",
                            bg: Color.red.opacity(0.08))
            } else {
                AIAlertCard(icon: "checkmark.seal.fill", iconColor: .green,
                            title: "Healthy Member Activity",
                            detail: "No members are currently flagged as inactive.",
                            bg: Color.green.opacity(0.08))
            }
            
            // 2. Map the live AI Alerts from the backend
            if viewModel.aiAlerts.isEmpty {
                Text("No further alerts at this time.")
                    .font(.caption).foregroundColor(.secondary)
                    .padding(.horizontal)
            } else {
                ForEach(viewModel.aiAlerts) { alert in
                    let isWarning = alert.type == "warning"
                    AIAlertCard(icon: isWarning ? "exclamationmark.triangle.fill" : "sparkles",
                                iconColor: isWarning ? .orange : .purple,
                                title: alert.title,
                                detail: alert.message,
                                bg: isWarning ? Color.orange.opacity(0.08) : Color.purple.opacity(0.08))
                }
            }
        }
    }
}

struct AIAlertCard: View {
    let icon: String; let iconColor: Color
    let title: String; let detail: String; let bg: Color
    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(iconColor.opacity(0.15)).frame(width: 42, height: 42)
                Image(systemName: icon).font(.system(size: 18)).foregroundColor(iconColor)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.subheadline).fontWeight(.semibold)
                Text(detail).font(.caption).foregroundColor(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
        }
        .padding(14)
        .background(bg)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
        .padding(.horizontal)
    }
}

// MARK: - 4. Analytics Data Cards (2-col grid)
struct AnalyticsDataGrid: View {
    var isAdmin: Bool = false
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Analytics Data").font(.title3).bold().padding(.horizontal)
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)], spacing: 14) {
                NavigationLink(destination: MemberEngagementListView()) {
                    AnalyticsDataCard(icon: "person.2.fill",    iconColor: .purple,
                                      title: "Member Engagement",  detail: "Detailed engagement scores")
                }
                .buttonStyle(PlainButtonStyle())
                if isAdmin {
                    NavigationLink(destination: Text("Club Comparison").font(.largeTitle)) {
                        AnalyticsDataCard(icon: "chart.bar.xaxis",  iconColor: .blue,
                                          title: "Club Comparison",    detail: "Benchmark vs. other clubs")
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
            .padding(.horizontal)
        }
    }
}

struct AnalyticsDataCard: View {
    let icon: String; let iconColor: Color
    let title: String; let detail: String
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(iconColor.opacity(0.12)).frame(width: 42, height: 42)
                Image(systemName: icon).font(.system(size: 20)).foregroundColor(iconColor)
            }
            Text(title).font(.subheadline).fontWeight(.semibold).foregroundColor(.primary)
            Text(detail).font(.caption).foregroundColor(.secondary).lineLimit(2)
            Text("View")
                .font(.caption).fontWeight(.bold).foregroundColor(iconColor)
                .padding(.horizontal, 12).padding(.vertical, 5)
                .background(iconColor.opacity(0.10)).clipShape(Capsule())
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

// MARK: - 5. AI Insights Options
struct AIInsightsOptions: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("AI Insights").font(.title3).bold().padding(.horizontal)
            NavigationLink(destination: AIRecommendationsView()) {
                AIInsightOptionCard(icon: "wand.and.stars", iconColor: .purple,
                                    title: "AI Recommendations",
                                    detail: "Personalised suggestions to improve club engagement")
            }
            .buttonStyle(PlainButtonStyle())
            NavigationLink(destination: PredictiveAnalyticsView()) {
                AIInsightOptionCard(icon: "chart.line.uptrend.xyaxis", iconColor: .blue,
                                    title: "Predictive Analytics",
                                    detail: "Future engagement forecasts powered by AI")
            }
            .buttonStyle(PlainButtonStyle())
        }
    }
}

struct AIInsightOptionCard: View {
    let icon: String; let iconColor: Color
    let title: String; let detail: String
    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(LinearGradient(colors: [iconColor, iconColor.opacity(0.65)],
                                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 48, height: 48)
                Image(systemName: icon).font(.system(size: 22)).foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.subheadline).fontWeight(.semibold)
                Text(detail).font(.caption).foregroundColor(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(Color(UIColor.tertiaryLabel))
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
        .padding(.horizontal)
    }
}

#Preview("Admin (Platform)") {
    NavigationStack { AnalyticsDashboardView(role: .admin) }
        .environmentObject(AttendanceNotificationStore())
}

#Preview("President (Club View)") {
    NavigationStack { AnalyticsDashboardView(role: .president) }
        .environmentObject(AttendanceNotificationStore())
}

#Preview("Student (Personal View)") {
    NavigationStack { AnalyticsDashboardView(role: .student) }
        .environmentObject(AttendanceNotificationStore())
}
