import Foundation

struct UserNotification: Decodable, Identifiable {
    let id: Int
    let user_id: Int?
    let title: String
    let message: String
    let is_read: Int
    let created_at: String
}

final class NotificationService {
    static let shared = NotificationService()
    private init() {}

    func getNotifications(userId: Int, role: String = "Student") async throws -> [UserNotification] {
        let encodedRole = role.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? role
        return try await APIClient.shared.request("/notifications/user/\(userId)?role=\(encodedRole)")
    }

    func markRead(notificationId: Int) async throws {
        let _: MessageResponse = try await APIClient.shared.request(
            "/notifications/\(notificationId)/read", method: "POST"
        )
    }

    func markAllRead(userId: Int, role: String) async throws {
        let encodedRole = role.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? role
        let _: MessageResponse = try await APIClient.shared.request(
            "/notifications/mark-all-read?user_id=\(userId)&role=\(encodedRole)", method: "POST"
        )
    }
}

