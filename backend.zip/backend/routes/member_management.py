from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models import UserRole, User, Club, ClubMember
from schemas.member_management import UserResponse, MemberResponse
from core.permissions import require_admin, require_authority, require_president, get_current_user

router = APIRouter(prefix="/members", tags=["Member Management"])

@router.get("/users", response_model=List[UserResponse])
def get_all_users(db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    users = db.query(User).all()
    # Ensure role is converted to string for the pydantic schema if it's an enum
    for user in users:
        user.role = str(user.role.value) if hasattr(user.role, 'value') else str(user.role)
    return users

@router.get("/club/{club_id}", response_model=List[MemberResponse])
def get_club_members(club_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_authority)):
    allowed_roles = [UserRole.Admin, UserRole.President, UserRole.VicePresident]
    if current_user.role not in allowed_roles:
        raise HTTPException(status_code=403, detail="Not authorized to view club members")
        
    members = db.query(ClubMember).filter(ClubMember.club_id == club_id).all()
    return members

@router.delete("/remove/{student_id}")
def remove_member(student_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_authority)):
    allowed_roles = [UserRole.Admin, UserRole.President]
    if current_user.role not in allowed_roles:
        raise HTTPException(status_code=403, detail="Not authorized to remove members")
        
    member = db.query(ClubMember).filter(ClubMember.student_id == student_id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")
        
    db.delete(member)
    db.commit()
    return {"message": "Member removed successfully"}

@router.get("/user/{user_id}", response_model=UserResponse)
def get_user_profile(user_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.role = str(user.role.value) if hasattr(user.role, 'value') else str(user.role)
    return user
