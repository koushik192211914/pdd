from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class BudgetCreate(BaseModel):
    club_id: int
    total_budget: float

class ExpenseCreate(BaseModel):
    club_id: int
    title: str
    amount: float
    description: str

class ExpenseResponse(BaseModel):
    id: int
    club_id: int
    added_by: int
    title: str
    amount: float
    description: str
    created_at: datetime

    class Config:
        from_attributes = True
        orm_mode = True

class BudgetUpdateFull(BaseModel):
    total_budget: float
    remaining_budget: float
    notes: Optional[str] = None

class BudgetResponse(BaseModel):
    id: int
    club_id: int
    total_budget: float
    remaining_budget: float
    status: str
    notes: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True

class FinancialReportResponse(BaseModel):
    total_budget: float
    total_expenses: float
    remaining_budget: float
    number_of_expenses: int
    events_funded: int
