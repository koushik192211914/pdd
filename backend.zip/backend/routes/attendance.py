from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
import models
import schemas
from core.permissions import require_authority

router = APIRouter(
    prefix="/attendance",
    tags=["Attendance"]
)

@router.post("/mark", response_model=schemas.MessageResponse)
def mark_attendance(payload: schemas.AttendanceMark, db: Session = Depends(get_db), auth_user: models.User = Depends(require_authority)):
    # Verify event exists
    event = db.query(models.Event).filter(models.Event.id == payload.event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    existing = db.query(models.EventAttendance).filter(
        models.EventAttendance.event_id == payload.event_id,
        models.EventAttendance.student_id == payload.user_id
    ).first()

    if existing:
        existing.status = payload.status
        existing.marked_by = auth_user.id
    else:
        new_attendance = models.EventAttendance(
            event_id=payload.event_id,
            student_id=payload.user_id,
            status=payload.status,
            marked_by=auth_user.id
        )
        db.add(new_attendance)

    db.commit()
    return schemas.MessageResponse(message=f"Attendance marked as {payload.status} for user {payload.user_id}")


@router.post("/substitute", response_model=schemas.MessageResponse)
def assign_substitute(payload: schemas.AttendanceSubstitute, db: Session = Depends(get_db), auth_user: models.User = Depends(require_authority)):
    # Verify event exists
    event = db.query(models.Event).filter(models.Event.id == payload.event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    # Mark original user as Absent (or whatever status they sent, typically 'Absent')
    # Use "Absent" if they are being substituted, or the provided status if they just pass it
    status_to_mark = payload.status if payload.status else "Absent"
    
    existing = db.query(models.EventAttendance).filter(
        models.EventAttendance.event_id == payload.event_id,
        models.EventAttendance.student_id == payload.user_id
    ).first()

    if existing:
        existing.status = status_to_mark
        existing.marked_by = auth_user.id
    else:
        new_attendance = models.EventAttendance(
            event_id=payload.event_id,
            student_id=payload.user_id,
            status=status_to_mark,
            marked_by=auth_user.id
        )
        db.add(new_attendance)

    # Note: EventSubstitution table implementation depends on backend/models.py
    # From clubs.py cleanup, we know models.EventSubstitution exists with event_id
    # We'll try to insert a record into EventSubstitution if substitute_id is provided
    if payload.substitute_id:
        sub_record = models.EventSubstitution(
            event_id=payload.event_id,
            original_student_id=payload.user_id,
            substitute_student_id=payload.substitute_id,
            assigned_by=auth_user.id
        )
        db.add(sub_record)

        # Also optionally register substitute for the event if they are not already
        existing_sub_att = db.query(models.EventAttendance).filter(
             models.EventAttendance.event_id == payload.event_id,
             models.EventAttendance.student_id == payload.substitute_id
        ).first()

        if not existing_sub_att:
            sub_att = models.EventAttendance(
                 event_id=payload.event_id,
                 student_id=payload.substitute_id,
                 status="Present", # Assume they are present if they are substituting
                 marked_by=auth_user.id
            )
            db.add(sub_att)
        else:
            existing_sub_att.status = "Present"
            existing_sub_att.marked_by = auth_user.id
            
    db.commit()
    return schemas.MessageResponse(message=f"Substitute assigned successfully for user {payload.user_id}")
