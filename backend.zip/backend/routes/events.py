from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from database import get_db
import models
import schemas
from core.permissions import require_authority, get_current_user

router = APIRouter(
    prefix="/events",
    tags=["Events"]
)

@router.post("", response_model=schemas.EventResponse)
def create_event(event: schemas.EventCreate, db: Session = Depends(get_db)):
    # Use User ID 1 for now
    user_id = 1
    new_event = models.Event(
        event_name=event.event_name,
        description=event.description,
        club_id=event.club_id,
        event_date=event.event_date,
        created_by=user_id
    )
    db.add(new_event)
    db.commit()
    db.refresh(new_event)
    return new_event

@router.get("", response_model=List[schemas.EventResponse])
def get_all_events(db: Session = Depends(get_db)):
    events = db.query(models.Event).all()
    return events

@router.get("/club/{club_id}", response_model=List[schemas.EventResponse])
def get_events_by_club(club_id: int, db: Session = Depends(get_db)):
    events = db.query(models.Event).filter(models.Event.club_id == club_id).all()
    return events

@router.get("/{event_id}", response_model=schemas.EventResponse)
def get_event(event_id: int, db: Session = Depends(get_db)):
    event = db.query(models.Event).filter(models.Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    return event

@router.put("/{event_id}", response_model=schemas.EventResponse)
def update_event(event_id: int, event_update: schemas.EventCreate, db: Session = Depends(get_db), auth_user: models.User = Depends(require_authority)):
    event = db.query(models.Event).filter(models.Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    
    event.event_name = event_update.event_name
    event.description = event_update.description
    event.club_id = event_update.club_id
    event.event_date = event_update.event_date
    db.commit()
    db.refresh(event)
    return event

@router.delete("/{event_id}")
def delete_event(event_id: int, db: Session = Depends(get_db), auth_user: models.User = Depends(require_authority)):
    event = db.query(models.Event).filter(models.Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    
    db.query(models.EventRegistration).filter(models.EventRegistration.event_id == event_id).delete(synchronize_session=False)
    db.query(models.EventAttendance).filter(models.EventAttendance.event_id == event_id).delete(synchronize_session=False)
    db.query(models.EventSubstitution).filter(models.EventSubstitution.event_id == event_id).delete(synchronize_session=False)
    
    db.delete(event)
    db.commit()
    return {"message": "Event deleted successfully"}
