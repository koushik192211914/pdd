//
//  UserService.swift
//  CLUB ANALYTICSs
//
//  GET /users/me  |  PUT /users/me
//

import Foundation

final class UserService {
    static let shared = UserService()
    private init() {}

    func getMe() async throws -> UserResponseModel {
        return try await APIClient.shared.request("/users/me")
    }

    func updateMe(name: String?, email: String?) async throws -> UserResponseModel {
        let request = UserUpdateRequest(name: name, email: email)
        return try await APIClient.shared.request("/users/me", method: "PUT", body: request)
    }
}
