import os
import shutil

src_dir = "/tmp/backup/CLUB ANALYTICSs/CLUB ANALYTICSs"
dest_dir = "/Users/sail/Desktop/CLUB ANALYTICSs/CLUB ANALYTICSs"

do_not_overwrite = [
    "LoginView.swift",
    "SignUpView.swift",
    "ClubsScreen.swift",
    "EventsScreen.swift",
    "ProfileScreen.swift",
    "JoinRequestsView.swift",
    "CLUB_ANALYTICSsApp.swift",
    "APIClient.swift",
    "AuthManager.swift",
    "AppModels.swift",
    "PreviewWrapper.swift"
]

restored = 0

for filename in os.listdir(src_dir):
    if filename.endswith(".swift"):
        if filename not in do_not_overwrite:
            if not "ViewModel.swift" in filename and not "Service.swift" in filename:
                src_file = os.path.join(src_dir, filename)
                dest_file = os.path.join(dest_dir, filename)
                shutil.copy2(src_file, dest_file)
                restored += 1

print(f"Restored {restored} files from backup.")
