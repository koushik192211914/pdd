//
//  AnnouncementViewModel.swift
//  CLUB ANALYTICSs
//

import Foundation
import Combine

@MainActor
final class AnnouncementViewModel: ObservableObject {
    @Published var announcements: [AnnouncementResponse] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    func load(clubId: Int) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                announcements = try await AnnouncementService.shared.getAnnouncements(clubId: clubId)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func post(title: String, content: String, clubId: Int) {
        Task {
            isLoading = true
            errorMessage = nil
            defer { isLoading = false }
            do {
                let newItem = try await AnnouncementService.shared.postAnnouncement(
                    title: title, content: content, clubId: clubId
                )
                announcements.insert(newItem, at: 0)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
