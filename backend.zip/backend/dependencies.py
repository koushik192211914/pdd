from fastapi import Depends, HTTPException, Query
from sqlalchemy.orm import Session
from database import get_db
import models

def get_current_user(db: Session = Depends(get_db)):
    # Mocking user with ID 1 for now
    user = db.query(models.User).filter(models.User.id == 1).first()
    if not user:
        # If user 1 doesn't exist, return a dict or create one
        return {"id": 1, "name": "Mock User", "role": models.UserRole.Admin}
    
    # Overriding role to Admin for mock development (ensures full access)
    user.role = models.UserRole.Admin
    return user

def require_admin(current_user: dict = Depends(get_current_user)):
    user_role = getattr(current_user, "role", current_user.get("role") if isinstance(current_user, dict) else None)
    if user_role != models.UserRole.Admin:
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

def require_authority(current_user: dict = Depends(get_current_user)):
    user_role = getattr(current_user, "role", current_user.get("role") if isinstance(current_user, dict) else None)
    allowed_roles = [
        models.UserRole.Admin,
        models.UserRole.President,
        models.UserRole.VicePresident,
        models.UserRole.Secretary,
        models.UserRole.Treasurer
    ]
    if user_role not in allowed_roles:
        raise HTTPException(status_code=403, detail="Authority access required")
    return current_user
