import os
import re

dir_path = "/Users/sail/Desktop/CLUB ANALYTICSs/CLUB ANALYTICSs"

files_fixed = 0

for filename in os.listdir(dir_path):
    if not filename.endswith("Service.swift"):
        continue
    filepath = os.path.join(dir_path, filename)
    with open(filepath, 'r') as f:
        content = f.read()
    original = content

    content = re.sub(r'body:\s*body\s*\}', 'body: body\n        )\n    }', content)
    content = re.sub(r'\)\n\}\n\n', ')\n    }\n}\n', content)
    
    # Wait, the try await APIClient.shared.authRequest(...) might not have `body: body`.
    # Let's use a more robust regex for the APIClient calls that are missing `)` before `}`
    # `path: "[^"]*",\s*method: \.[A-Z]+\s*}` -> `path: "...", method: ...\n        )\n    }`
    content = re.sub(r'(method:\s*\.[A-Z]+)\s*\}', r'\1\n        )\n    }', content)
    content = re.sub(r'(body:\s*[a-zA-Z0-9_]+)\s*\}', r'\1\n        )\n    }', content)

    if content != original:
        with open(filepath, 'w') as f:
            f.write(content)
        files_fixed += 1
        print(f"Fixed {filename}")

print(f"Fixed {files_fixed} Service files.")
