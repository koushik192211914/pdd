import Foundation

func runTestLogin() {
    Task {
        do {
            let body: Encodable = LoginRequest(email: "test@example.com", password: "password123")
            let url = URL(string: "http://127.0.0.1:8000/auth/login")!
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let encoder = JSONEncoder()
            let bodyData = try encoder.encode(AnyEncodable(body))
            request.httpBody = bodyData
            
            print(String(data: bodyData, encoding: .utf8) ?? "ERROR")

            let (data, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse {
                print("Status: \(http.statusCode)")
                print("Body: \(String(data: data, encoding: .utf8) ?? "")")
            }
        } catch {
            print("Catch: \(error)")
        }
        exit(0)
    }

    RunLoop.main.run()
}
