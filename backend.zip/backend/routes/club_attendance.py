from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from database import get_db
import models
import schemas
from core.permissions import require_authority

router = APIRouter(
    prefix="/club-attendance",
    tags=["Club Attendance"]
)

@router.post("/session", response_model=schemas.AttendanceSessionResponse)
def create_attendance_session(session_data: schemas.CreateAttendanceSession, created_by: int = None, db: Session = Depends(get_db), auth_user: models.User = Depends(require_authority)):
    # Check if a session already exists for this club on this date
    existing = db.query(models.ClubAttendanceSession).filter(
        models.ClubAttendanceSession.club_id == session_data.club_id,
        models.ClubAttendanceSession.attendance_date == session_data.attendance_date
    ).first()
    
    if existing:
        raise HTTPException(status_code=400, detail="Attendance already marked for today")
        
    new_session = models.ClubAttendanceSession(
        club_id=session_data.club_id,
        attendance_date=session_data.attendance_date,
        created_by=created_by
    )
    db.add(new_session)
    db.commit()
    db.refresh(new_session)
    return new_session

@router.post("/mark", response_model=schemas.AttendanceRecordResponse)
def mark_attendance(record_data: schemas.AttendanceRecordCreate, db: Session = Depends(get_db), auth_user: models.User = Depends(require_authority)):
    # Optional: could check if session exists, but FK handles hard constraints
    session = db.query(models.ClubAttendanceSession).filter(models.ClubAttendanceSession.id == record_data.session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Attendance session not found")
        
    # Optional: check if record already exists for this student in this session
    existing_record = db.query(models.ClubAttendanceRecord).filter(
        models.ClubAttendanceRecord.session_id == record_data.session_id,
        models.ClubAttendanceRecord.student_id == record_data.student_id
    ).first()
    
    if existing_record:
        # Update existing record instead of creating multiple (or raise error, depending on exact spec)
        # Spec says "Insert attendance record", so let's check if they want to update it or block it. 
        # Typically you'd update or raise. I'll raise to be safe, or update. Let's raise.
        raise HTTPException(status_code=400, detail="Attendance already marked for this student in this session")

    new_record = models.ClubAttendanceRecord(
        session_id=record_data.session_id,
        student_id=record_data.student_id,
        status=record_data.status
    )
    db.add(new_record)
    
    # ── Notification ──────────────────────────────────────────────────────────
    # Notify student
    student_notif = models.Notification(
        user_id=record_data.student_id,
        title="Club Attendance Logged",
        message=f"You have been marked {record_data.status} for today's club session."
    )
    db.add(student_notif)

    # Notify admin (global log)
    admin_notif = models.Notification(
        user_id=None,
        title="Club Attendance Submitted",
        message=f"{auth_user.name} marked attendance for student ID {record_data.student_id}."
    )
    db.add(admin_notif)

    db.commit()
    db.refresh(new_record)
    return new_record

@router.get("/club/{club_id}", response_model=List[schemas.AttendanceSessionResponse])
def get_attendance_sessions_for_club(club_id: int, db: Session = Depends(get_db)):
    sessions = db.query(models.ClubAttendanceSession).filter(models.ClubAttendanceSession.club_id == club_id).all()
    return sessions

@router.get("/session/{session_id}", response_model=List[schemas.AttendanceRecordResponse])
def get_attendance_records_for_session(session_id: int, db: Session = Depends(get_db)):
    records = db.query(models.ClubAttendanceRecord).filter(models.ClubAttendanceRecord.session_id == session_id).all()
    return records

@router.get("/student/{student_id}", response_model=List[schemas.AttendanceRecordResponse])
def get_attendance_records_for_student(student_id: int, db: Session = Depends(get_db)):
    records = db.query(models.ClubAttendanceRecord).filter(models.ClubAttendanceRecord.student_id == student_id).all()
    return records

@router.delete("/{record_id}")
def delete_attendance_record(record_id: int, db: Session = Depends(get_db)):
    record = db.query(models.ClubAttendanceRecord).filter(models.ClubAttendanceRecord.id == record_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Attendance record not found")
        
    db.delete(record)
    db.commit()
    return {"message": "Attendance record deleted successfully"}
