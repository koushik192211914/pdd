//
//  PrivacySettingsView.swift
//  CLUB ANALYTICSs
//
//  ClubSphere AI – Privacy & data settings for club members.
//

import SwiftUI

// MARK: - Privacy Settings View
struct PrivacySettingsView: View {

    // MARK: – Profile visibility
    @AppStorage("privacy_profile_visible")    private var profileVisible       = true
    @AppStorage("privacy_show_attendance")    private var showAttendance       = true
    @AppStorage("privacy_show_achievements")  private var showAchievements     = true
    @AppStorage("privacy_allow_suggestions")  private var allowSuggestions     = true

    // MARK: – Data & activity
    @AppStorage("privacy_activity_status")    private var activityStatus       = true
    @AppStorage("privacy_share_analytics")    private var shareAnalytics       = false

    @State private var showClearConfirm = false

    var body: some View {
        List {

            // ── Profile Visibility ────────────────────────────────────────
            Section {
                PrivacyToggleRow(
                    icon: "person.crop.circle.fill",
                    iconColor: .purple,
                    title: "Public Profile",
                    subtitle: "Let other club members see your profile",
                    isOn: $profileVisible
                )
                PrivacyToggleRow(
                    icon: "checkmark.seal.fill",
                    iconColor: .green,
                    title: "Show Attendance Record",
                    subtitle: "Visible to club authorities",
                    isOn: $showAttendance
                )
                PrivacyToggleRow(
                    icon: "trophy.fill",
                    iconColor: .orange,
                    title: "Show Achievements",
                    subtitle: "Display badges on your profile",
                    isOn: $showAchievements
                )
            } header: {
                Text("Profile Visibility")
            }

            // ── Personalization ───────────────────────────────────────────
            Section {
                PrivacyToggleRow(
                    icon: "sparkles",
                    iconColor: .blue,
                    title: "AI Event Suggestions",
                    subtitle: "Let the AI recommend events based on your clubs",
                    isOn: $allowSuggestions
                )
                PrivacyToggleRow(
                    icon: "antenna.radiowaves.left.and.right",
                    iconColor: .indigo,
                    title: "Show Activity Status",
                    subtitle: "Let others see when you were last active",
                    isOn: $activityStatus
                )
                PrivacyToggleRow(
                    icon: "chart.bar.xaxis",
                    iconColor: .teal,
                    title: "Share Usage Analytics",
                    subtitle: "Help improve ClubSphere with anonymous data",
                    isOn: $shareAnalytics
                )
            } header: {
                Text("Personalization & Data")
            }

            // ── Account Data ──────────────────────────────────────────────
            Section {
                Button(role: .destructive) {
                    showClearConfirm = true
                } label: {
                    HStack(spacing: 14) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.red)
                                .frame(width: 32, height: 32)
                            Image(systemName: "trash.fill")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.white)
                        }
                        Text("Clear My Activity Data")
                            .foregroundColor(.red)
                    }
                }
            } header: {
                Text("Account Data")
            } footer: {
                Text("Clearing activity data removes your local notification history and cached analytics. Your club membership and attendance records are not affected.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .navigationTitle("Privacy Settings")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog(
            "Clear Activity Data?",
            isPresented: $showClearConfirm,
            titleVisibility: .visible
        ) {
            Button("Clear Data", role: .destructive) {
                // In a real app: call store / UserDefaults cleanup here
            }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("This will remove your local notification history and cached analytics. This action cannot be undone.")
        }
    }
}

// MARK: - Reusable Privacy Toggle Row
private struct PrivacyToggleRow: View {
    let icon:      String
    let iconColor: Color
    let title:     String
    let subtitle:  String
    @Binding var isOn: Bool

    var body: some View {
        Toggle(isOn: $isOn) {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(iconColor)
                        .frame(width: 32, height: 32)
                    Image(systemName: icon)
                        .font(.system(size: 15, weight: .medium))
                        .foregroundColor(.white)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.body)
                    Text(subtitle)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
        .tint(.purple)
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
    NavigationStack {
        PrivacySettingsView()
    }

    }
}
