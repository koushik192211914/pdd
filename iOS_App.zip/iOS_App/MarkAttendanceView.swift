import SwiftUI

// MARK: - Attendance Status
enum AttendanceChoice: String, CaseIterable {
    case present    = "Present"
    case absent     = "Absent"

    var color: Color {
        switch self {
        case .present:    return .green
        case .absent:     return .red
        }
    }
    var icon: String {
        switch self {
        case .present:    return "checkmark.circle.fill"
        case .absent:     return "xmark.circle.fill"
        }
    }
}

// MARK: - Main View
struct MarkAttendanceView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var authManager: AuthManager
    @EnvironmentObject var store: AttendanceNotificationStore

    let eventId: String  // empty = club session attendance
    let eventName: String
    let clubName: String

    // State
    @State private var participants: [EventParticipant] = []
    @State private var isLoading = true
    @State private var errorMessage: String?

    @State private var choices: [Int: AttendanceChoice] = [:]
    @State private var isSubmitting = false
    @State private var submitMessage: String?
    @State private var isAttendanceSubmitted = false
    
    // Substitution state
    @State private var substitutes: [Int: (id: Int, name: String)] = [:]
    @State private var pickingSubstituteFor: IdentifiableInt?
    @State private var availableSubstitutes: [ClubMemberItem] = []
    @State private var recommendedSubstitutes: [SubstituteRecommendation] = []
    @State private var isLoadingSubs = false
    @State private var noSubAvailable = false

    private var allMarked: Bool {
        participants.allSatisfy { p in
            return choices[p.id] != nil
        }
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            Color(UIColor.systemGroupedBackground).ignoresSafeArea()

            VStack(spacing: 0) {
                // Header
                EventAttendanceHeader(
                    clubName: clubName,
                    eventName: eventName.isEmpty ? (eventId.isEmpty ? "Club Attendance" : "Event Attendance") : eventName
                )

                if isLoading {
                    Spacer()
                    ProgressView("Loading participants...")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Spacer()
                } else if let err = errorMessage {
                    Spacer()
                    ErrorStateView(message: err)
                    Spacer()
                } else if participants.isEmpty {
                    Spacer()
                    EmptyParticipantsView()
                    Spacer()
                } else {
                    ScrollView {
                        VStack(spacing: 12) {
                            // Summary banner
                            AttendanceSummaryBanner(
                                total: participants.count,
                                present: choices.values.filter { $0 == .present }.count,
                                absent: choices.values.filter { $0 == .absent }.count,
                                substitute: substitutes.count
                            )
                            .padding(.horizontal)

                            ForEach(participants) { participant in
                                ParticipantAttendanceRow(
                                    participant: participant,
                                    isEvent: !eventId.isEmpty,
                                    choice: Binding(
                                        get: { choices[participant.id] },
                                        set: { newVal in
                                            choices[participant.id] = newVal
                                            if newVal == .present {
                                                substitutes.removeValue(forKey: participant.id)
                                            }
                                        }
                                    ),
                                    substituteName: substitutes[participant.id]?.name,
                                    onAssignSub: {
                                        pickingSubstituteFor = IdentifiableInt(id: participant.id)
                                        loadAvailableSubstitutes()
                                    }
                                )
                                .padding(.horizontal)
                            }
                        }
                        .padding(.top, 16)
                        .padding(.bottom, 110)
                    }
                }
            }

            // Sticky bottom submit
            VStack(spacing: 0) {
                Divider()
                VStack(spacing: 8) {
                    if let msg = submitMessage {
                        HStack(spacing: 6) {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                            Text(msg)
                                .font(.subheadline)
                                .foregroundColor(.green)
                        }
                        .transition(.opacity.combined(with: .move(edge: .bottom)))
                    }
                    Button(action: submitAttendance) {
                        HStack(spacing: 10) {
                            if isSubmitting {
                                ProgressView().tint(.white)
                            } else if isAttendanceSubmitted {
                                Image(systemName: "checkmark.seal.fill")
                                    .font(.system(size: 16, weight: .semibold))
                                Text("Attendance Submitted")
                                    .font(.headline)
                            } else {
                                Image(systemName: "checkmark.seal.fill")
                                    .font(.system(size: 16, weight: .semibold))
                                Text("Submit Attendance")
                                    .font(.headline)
                            }
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(
                            isAttendanceSubmitted ? LinearGradient(colors: [.green, .green.opacity(0.8)], startPoint: .leading, endPoint: .trailing) :
                            (allMarked
                            ? LinearGradient(colors: [.blue, .purple], startPoint: .leading, endPoint: .trailing)
                            : LinearGradient(colors: [.gray.opacity(0.5), .gray.opacity(0.4)], startPoint: .leading, endPoint: .trailing))
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .shadow(color: (allMarked && !isAttendanceSubmitted) ? .blue.opacity(0.3) : .clear, radius: 8, y: 4)
                    }
                    .disabled(!allMarked || isSubmitting || isAttendanceSubmitted)
                    .animation(.easeInOut(duration: 0.2), value: allMarked)
                }
                .padding(.horizontal)
                .padding(.vertical, 12)
                .background(Color(UIColor.systemGroupedBackground))
            }
        }
        .navigationBarHidden(true)
        .task { await loadParticipants() }
        .sheet(item: $pickingSubstituteFor) { wrapper in
            let pId = wrapper.id
            SubstitutePickerSheet(
                members: availableSubstitutes,
                recommendations: recommendedSubstitutes,
                isLoading: isLoadingSubs,
                noResults: noSubAvailable
            ) { subId, name in
                substitutes[pId] = (id: subId, name: name)
                choices[pId] = .absent
                pickingSubstituteFor = nil
            }
        }
    }

    // MARK: - Load Participants
    private func loadParticipants() async {
        isLoading = true
        defer { isLoading = false }
        guard !eventId.isEmpty, let eId = Int(eventId) else {
            // Club session — fall back to club members
            guard let clubId = authManager.clubId else {
                errorMessage = "No club assigned."; return
            }
            do {
                // Check if already marked today
                let alreadyMarked: Bool = try await APIClient.shared.request(
                    "/club-attendance/club/\(clubId)/check-today", method: "GET"
                )
                await MainActor.run { self.isAttendanceSubmitted = alreadyMarked }

                let members = try await ClubService.shared.getMembers(clubId: clubId)
                let allParticipants = members.map {
                    EventParticipant(student_id: $0.id, name: $0.name, email: $0.email, role: $0.role, status: nil)
                }
                
                // Filter if President
                if authManager.userRole == "President" {
                    participants = allParticipants.filter { $0.role == "Student" }
                } else {
                    participants = allParticipants
                }
            } catch {
                errorMessage = "Failed to load club members."
            }
            return
        }
        do {
            let fetchedParticipants = try await EventAttendanceService.shared.getEventParticipants(eventId: eId)
            
            // Filter if President
            if authManager.userRole == "President" {
                participants = fetchedParticipants.filter { $0.role == "Student" }
            } else {
                participants = fetchedParticipants
            }
            
            if participants.isEmpty {
                // Intentionally empty — show empty state
            } else {
                if let submitted = try? await EventAttendanceService.shared.hasSubmittedAttendance(eventId: eId) {
                    isAttendanceSubmitted = submitted
                }
            }
        } catch {
            errorMessage = "Failed to load participants. Check your connection."
        }
    }

    private func loadAvailableSubstitutes() {
        guard let clubId = authManager.clubId else { return }
        isLoadingSubs = true
        noSubAvailable = false
        
        Task {
            do {
                // Fetch basic members
                let members = try await ClubService.shared.getMembers(clubId: clubId)
                
                // Fetch AI recommendations if eventId exists
                var recs: [SubstituteRecommendation] = []
                if !eventId.isEmpty, let eId = Int(eventId) {
                    recs = try await RecommendationService.shared.getSubstituteRecommendations(eventId: eId)
                }
                
                // Filter out already present or already subbing
                let activeIds = Set(participants.map { $0.student_id })
                let alreadySubbingIds = Set(substitutes.values.map { $0.id })
                
                let eligible = members.filter { 
                    !activeIds.contains($0.id) && !alreadySubbingIds.contains($0.id) && $0.role == "Student"
                }
                
                let filteredRecs = recs.filter {
                    !activeIds.contains($0.student_id) && !alreadySubbingIds.contains($0.student_id)
                }
                
                await MainActor.run {
                    self.availableSubstitutes = eligible
                    self.recommendedSubstitutes = filteredRecs
                    self.noSubAvailable = eligible.isEmpty
                    self.isLoadingSubs = false
                }
            } catch {
                await MainActor.run { self.isLoadingSubs = false }
            }
        }
    }

    // MARK: - Submit
    private func submitAttendance() {
        isSubmitting = true
        Task {
            guard let eId = Int(eventId) else {
                // Handle club session submit (legacy path)
                await submitClubAttendance()
                return
            }

            var records: [EventAttendanceRequest] = []
            for p in participants {
                let choice = choices[p.id] ?? .absent
                let statusStr = choice == .present ? "Present" : "Absent"
                let subId = substitutes[p.id]?.id
                
                let rec = EventAttendanceRequest(
                    event_id: eId,
                    student_id: p.student_id,
                    status: statusStr,
                    substitute_id: subId
                )
                records.append(rec)
            }

            do {
                _ = try await EventAttendanceService.shared.markAttendance(records: records)

                await MainActor.run {
                    withAnimation { submitMessage = "Attendance submitted! ✅" }
                    isSubmitting = false
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) { dismiss() }
                }
            } catch {
                await MainActor.run {
                    submitMessage = "Submission failed. Please retry."
                    isSubmitting = false
                }
            }
        }
    }

    private func submitClubAttendance() async {
        guard let clubId = authManager.clubId else { isSubmitting = false; return }
        do {
            // Include session data (club_id and today's date)
            let dateStr = ISO8601DateFormatter().string(from: Date()).prefix(10) // YYYY-MM-DD
            let sessionData: [String: AnyEncodable] = [
                "club_id": AnyEncodable(clubId),
                "attendance_date": AnyEncodable(String(dateStr))
            ]
            
            let session: AttendanceSessionResponse = try await APIClient.shared.request(
                "/club-attendance/session", method: "POST", body: sessionData
            )
            for p in participants {
                let choice = choices[p.id] ?? .absent
                let rec = AttendanceRecordRequest(
                    session_id: session.id,
                    student_id: p.student_id,
                    status: choice == .present ? "Present" : "Absent"
                )
                let _: AttendanceRecordResponse = try await APIClient.shared.request(
                    "/club-attendance/mark", method: "POST", body: rec
                )
            }
        } catch { print("❌ Club attendance error: \(error)") }

        await MainActor.run {
            withAnimation { submitMessage = "Attendance submitted! ✅" }
            isSubmitting = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) { dismiss() }
        }
    }
}

// MARK: - Header
private struct EventAttendanceHeader: View {
    let clubName: String
    let eventName: String
    @Environment(\.dismiss) private var dismiss

    private var safeTop: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first(where: { $0.isKeyWindow })?.safeAreaInsets.top ?? 50
    }

    var body: some View {
        ZStack(alignment: .top) {
            LinearGradient(
                colors: [Color.blue, Color.purple],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            .frame(height: safeTop + 85)

            VStack(spacing: 0) {
                Color.clear.frame(height: safeTop + 8)
                HStack(alignment: .center) {
                    Button(action: { dismiss() }) {
                        ZStack {
                            Circle()
                                .fill(Color.white.opacity(0.18))
                                .frame(width: 38, height: 38)
                            Image(systemName: "chevron.left")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(.white)
                        }
                    }
                    Spacer()
                    VStack(spacing: 2) {
                        Text(clubName)
                            .font(.headline)
                            .foregroundColor(.white)
                        Text(eventName)
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.9))
                            .fontWeight(.medium)
                            .lineLimit(1)
                    }
                    Spacer()
                    // Balance the back button
                    Circle()
                        .fill(Color.clear)
                        .frame(width: 38, height: 38)
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 16)
            }
        }
    }
}

// MARK: - Summary Banner
private struct AttendanceSummaryBanner: View {
    let total: Int
    let present: Int
    let absent: Int
    let substitute: Int

    var body: some View {
        HStack(spacing: 0) {
            SummaryPill(value: present, label: "Present", color: .green)
            Divider().frame(height: 30).opacity(0.3)
            SummaryPill(value: absent, label: "Absent", color: .red)
            Divider().frame(height: 30).opacity(0.3)
            SummaryPill(value: total - present - absent, label: "Unmarked", color: .secondary)
        }
        .padding(.vertical, 10)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .shadow(color: .black.opacity(0.04), radius: 4, y: 2)
    }
}

private struct SummaryPill: View {
    let value: Int
    let label: String
    let color: Color

    var body: some View {
        VStack(spacing: 2) {
            Text("\(value)")
                .font(.title3).bold()
                .foregroundColor(color)
            Text(label)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Participant Row
private struct ParticipantAttendanceRow: View {
    let participant: EventParticipant
    let isEvent: Bool
    @Binding var choice: AttendanceChoice?
    let substituteName: String?
    let onAssignSub: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // Person info
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(LinearGradient(
                            colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.5)],
                            startPoint: .topLeading, endPoint: .bottomTrailing
                        ))
                        .frame(width: 44, height: 44)
                    Text(String(participant.name.prefix(1)).uppercased())
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.white)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(participant.name)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    Text(participant.email.isEmpty ? "Registered member" : participant.email)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
                Spacer()
                // Status indicator dot
                if let c = choice {
                    Circle()
                        .fill(c.color)
                        .frame(width: 10, height: 10)
                        .shadow(color: c.color.opacity(0.5), radius: 3)
                }
            }

            // Action buttons
            HStack(spacing: 8) {
                ForEach(AttendanceChoice.allCases, id: \.self) { opt in
                    let isSelected = choice == opt
                    Button {
                        withAnimation(.spring(response: 0.3)) {
                            choice = opt
                        }
                    } label: {
                        HStack(spacing: 5) {
                            Image(systemName: isSelected ? opt.icon : unselectedIcon(opt))
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(isSelected ? opt.color : .secondary)
                            Text(opt.rawValue)
                                .font(.caption)
                                .fontWeight(isSelected ? .bold : .medium)
                                .foregroundColor(isSelected ? opt.color : .secondary)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(
                            isSelected
                            ? opt.color.opacity(0.15)
                            : Color(UIColor.tertiarySystemFill)
                        )
                        .clipShape(Capsule())
                        .overlay(
                            Capsule()
                                .stroke(isSelected ? opt.color.opacity(0.5) : Color.clear, lineWidth: 1)
                        )
                    }
                    .buttonStyle(PlainButtonStyle())
                    .scaleEffect(isSelected ? 1.04 : 1.0)
                    .animation(.spring(response: 0.25), value: isSelected)
                }
                
                if isEvent {
                    Spacer()
                    
                    if let sub = substituteName {
                        HStack(spacing: 4) {
                            Image(systemName: "person.2.fill").font(.caption2)
                            Text("Sub: \(sub)")
                                .font(.caption2).fontWeight(.bold)
                        }
                        .foregroundColor(.orange)
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(Color.orange.opacity(0.12))
                        .clipShape(Capsule())
                    } else {
                        Button(action: onAssignSub) {
                            Text("Assign Sub")
                                .font(.caption2).fontWeight(.bold)
                                .foregroundColor(.blue)
                                .padding(.horizontal, 10).padding(.vertical, 6)
                                .background(Color.blue.opacity(0.1))
                                .clipShape(Capsule())
                        }
                    }
                }
            }
        }
        .padding(14)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.04), radius: 5, y: 2)
    }

    private func unselectedIcon(_ opt: AttendanceChoice) -> String {
        switch opt {
        case .present:    return "checkmark.circle"
        case .absent:     return "xmark.circle"
        }
    }
}

// MARK: - Substitute Picker Sheet
private struct SubstitutePickerSheet: View {
    let members: [ClubMemberItem]
    let recommendations: [SubstituteRecommendation]
    let isLoading: Bool
    let noResults: Bool
    let onSelect: (Int, String) -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if isLoading {
                    HStack {
                        Spacer(); ProgressView().padding(); Spacer()
                    }
                } else if noResults {
                    Text("No available members found").foregroundColor(.secondary)
                } else {
                    // AI RECOMMENDATIONS SECTION
                    if !recommendations.isEmpty {
                        Section {
                            ForEach(recommendations) { rec in
                                Button {
                                    onSelect(rec.student_id, rec.name)
                                    dismiss()
                                } label: {
                                    HStack {
                                        VStack(alignment: .leading, spacing: 4) {
                                            HStack(spacing: 6) {
                                                Text(rec.name).foregroundColor(.primary).fontWeight(.semibold)
                                                Text("AI SUGGESTED")
                                                    .font(.system(size: 8, weight: .bold))
                                                    .padding(.horizontal, 4).padding(.vertical, 2)
                                                    .background(Color.purple.opacity(0.15))
                                                    .foregroundColor(.purple)
                                                    .cornerRadius(4)
                                            }
                                            Text("\(rec.engagement_score)% Engagement Rate")
                                                .font(.caption2).foregroundColor(.secondary)
                                        }
                                        Spacer()
                                        Image(systemName: "sparkles").foregroundColor(.purple).font(.subheadline)
                                    }
                                }
                            }
                        } header: {
                            Label("AI Recommendations", systemImage: "sparkles").foregroundColor(.purple)
                        } footer: {
                            Text("Suggested based on historical attendance rates").font(.caption2)
                        }
                    }

                    // ALL MEMBERS SECTION
                    Section("All Available Members") {
                        ForEach(members) { member in
                            // Don't show if already in recommendations to avoid duplication
                            if !recommendations.contains(where: { $0.student_id == member.id }) {
                                Button {
                                    onSelect(member.id, member.name)
                                    dismiss()
                                } label: {
                                    HStack {
                                        Text(member.name).foregroundColor(.primary)
                                        Spacer()
                                        Text(member.role).font(.caption).foregroundColor(.secondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Select Substitute")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }
}

struct IdentifiableInt: Identifiable {
    let id: Int
}

// MARK: - Empty / Error States
private struct EmptyParticipantsView: View {
    var body: some View {
        VStack(spacing: 20) {
            ZStack {
                Circle()
                    .fill(Color.purple.opacity(0.1))
                    .frame(width: 90, height: 90)
                Image(systemName: "person.3.sequence.fill")
                    .font(.system(size: 40))
                    .foregroundColor(.purple.opacity(0.6))
            }
            Text("No Registrations Yet")
                .font(.title3)
                .fontWeight(.bold)
            Text("No students have registered for this event.\nShare the event to get members to sign up.")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
    }
}

private struct ErrorStateView: View {
    let message: String
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 40))
                .foregroundColor(.orange)
            Text(message)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
    }
}

// MARK: - Preview
#Preview {
    PreviewWrapper {
        NavigationStack {
            MarkAttendanceView(eventId: "1", eventName: "General Meeting", clubName: "Tech Club")
                .environmentObject(AttendanceNotificationStore())
        }
    }
}
