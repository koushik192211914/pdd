from pydantic import BaseModel, EmailStr, Field, computed_field
from typing import Optional, List
from datetime import datetime, date
from models import UserRole

# ── Request Schemas ──────────────────────────────────────────────────────────

class SignupRequest(BaseModel):
    name: str
    email: EmailStr
    password: str = Field(..., min_length=8)

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class ForgotPasswordRequest(BaseModel):
    email: EmailStr

class PromoteRequest(BaseModel):
    role: str

# ── Response Schemas ─────────────────────────────────────────────────────────

class UserResponse(BaseModel):
    id: int
    name: str
    email: str
    role: UserRole
    created_at: datetime
    club_id: Optional[int] = None

    class Config:
        from_attributes = True

class MessageResponse(BaseModel):
    message: str

class LoginResponse(BaseModel):
    message: str
    user: UserResponse

class ClubBase(BaseModel):
    club_name: str
    category: Optional[str] = None
    description: Optional[str] = None

    model_config = {"from_attributes": True, "populate_by_name": True}

class ClubCreate(ClubBase):
    pass

class ClubResponse(ClubBase):
    id: int
    created_by: Optional[int]
    created_at: datetime

    @computed_field
    @property
    def name(self) -> str:
        return self.club_name


# --- Event Schemas ---
class EventBase(BaseModel):
    event_name: str
    description: Optional[str] = None
    club_id: int
    event_date: datetime

    model_config = {"from_attributes": True, "populate_by_name": True}

class EventCreate(EventBase):
    pass

class EventResponse(EventBase):
    id: int
    created_by: Optional[int]
    created_at: datetime

    @computed_field
    @property
    def title(self) -> str:
        return self.event_name

    @computed_field
    @property
    def date(self) -> datetime:
        return self.event_date


class EventRegistrationCreate(BaseModel):
    event_id: int

class EventRegistrationResponse(BaseModel):
    id: int
    event_id: int
    student_id: int
    registration_date: datetime
    status: str

    class Config:
        from_attributes = True

class EventAttendanceCreate(BaseModel):
    event_id: int
    student_id: int
    status: str

class BulkAttendanceCreate(BaseModel):
    event_id: int
    attendance: dict  # student_id (str) -> is_present (bool)

class EventAttendanceResponse(BaseModel):
    id: int
    event_id: int
    student_id: int
    status: str
    marked_by: Optional[int]
    marked_at: datetime

    class Config:
        from_attributes = True

class SubstitutionCreate(BaseModel):
    event_id: int
    original_student_id: int
    substitute_student_id: int

class SubstitutionResponse(BaseModel):
    id: int
    event_id: int
    original_student_id: int
    substitute_student_id: int
    assigned_by: Optional[int]
    assigned_at: datetime

    class Config:
        from_attributes = True

class SubstituteRecommendation(BaseModel):
    student_id: int
    engagement_score: int

class AttendanceMark(BaseModel):
    event_id: int
    user_id: int
    status: str

class AttendanceSubstitute(BaseModel):
    event_id: int
    user_id: int
    status: str
    substitute_id: Optional[int] = None

class ClubMemberCreate(BaseModel):
    club_id: int
    student_id: int

class ClubMemberResponse(BaseModel):
    id: int
    club_id: int
    student_id: int
    joined_at: datetime

    class Config:
        from_attributes = True

class CreateAttendanceSession(BaseModel):
    club_id: int
    attendance_date: date

class AttendanceSessionResponse(BaseModel):
    id: int
    club_id: int
    attendance_date: date
    created_by: Optional[int]
    created_at: datetime

    class Config:
        from_attributes = True

class AttendanceRecordCreate(BaseModel):
    session_id: int
    student_id: int
    status: str

class AttendanceRecordResponse(BaseModel):
    id: int
    session_id: int
    student_id: int
    status: str
    marked_at: datetime

    class Config:
        from_attributes = True

class NotificationCreate(BaseModel):
    title: str
    message: str

class NotificationResponse(BaseModel):
    id: int
    title: str
    message: str
    created_at: datetime

    class Config:
        from_attributes = True

class DocumentCreate(BaseModel):
    club_id: int
    title: str
    file_url: str

class DocumentResponse(BaseModel):
    id: int
    club_id: int
    title: str
    file_url: str
    uploaded_by: int
    created_at: datetime

    class Config:
        from_attributes = True

class JoinRequestCreate(BaseModel):
    student_id: int
    club_id: int

class JoinRequestResponse(BaseModel):
    id: int
    student_id: int
    club_id: int
    status: str
    requested_at: datetime
    student_name: Optional[str] = None
    student_email: Optional[str] = None

    class Config:
        from_attributes = True

class ClubHealthResponse(BaseModel):
    club_id: int
    club_health_score: float
    average_engagement: float
    total_members: int
    event_participation_rate: float

class EventPrediction(BaseModel):
    event_name: str
    predicted_participation_pct: int

class AtRiskMember(BaseModel):
    name: str
    initials: str
    predicted_engagement_score: int

class FutureTrend(BaseModel):
    week_label: str
    trend_value: float

class PredictiveAnalyticsResponse(BaseModel):
    event_predictions: List[EventPrediction]
    at_risk_members: List[AtRiskMember]
    future_trend: List[FutureTrend]

class AIRecommendation(BaseModel):
    id: str
    icon: str
    color: str
    title: str
    content: str

class AIRecommendationsResponse(BaseModel):
    recommendations: List[AIRecommendation]

# Submodule imports
from .finance import *
from .announcements import *
from .member_management import *
